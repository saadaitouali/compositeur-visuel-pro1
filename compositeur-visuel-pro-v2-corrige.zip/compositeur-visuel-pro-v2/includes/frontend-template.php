<?php
/**
 * Template frontend pour le Compositeur Visuel Pro
 * Avec héritage du thème WordPress et images par défaut vides
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Rendre le template frontend
 */
function cvp_render_frontend_template($atts = array()) {
    // Fusionner avec les attributs par défaut
    $atts = shortcode_atts(array(
        'width' => 800,
        'height' => 600,
        'theme' => 'inherit', // inherit, light, dark
        'enable_upload' => 'true',
        'enable_grid' => 'false',
        'max_file_size' => '10',
        'allowed_types' => 'jpeg,jpg,png,gif,webp',
        'container_class' => '',
        'canvas_class' => ''
    ), $atts);
    
    // Générer un ID unique pour cette instance
    $instance_id = 'cvp-composer-' . uniqid();
    
    // Préparer les options JavaScript
    $js_options = array(
        'canvasWidth' => intval($atts['width']),
        'canvasHeight' => intval($atts['height']),
        'enableUpload' => $atts['enable_upload'] === 'true',
        'enableGrid' => $atts['enable_grid'] === 'true',
        'maxFileSize' => intval($atts['max_file_size']) * 1024 * 1024,
        'allowedTypes' => array_map('trim', explode(',', $atts['allowed_types'])),
        'theme' => $atts['theme']
    );
    
    // Classes CSS pour le container
    $container_classes = array('cvp-container');
    
    if ($atts['theme'] === 'inherit') {
        $container_classes[] = 'cvp-theme-inherit';
    } elseif ($atts['theme'] === 'dark') {
        $container_classes[] = 'cvp-theme-dark';
    } else {
        $container_classes[] = 'cvp-theme-light';
    }
    
    if (!empty($atts['container_class'])) {
        $container_classes[] = sanitize_html_class($atts['container_class']);
    }
    
    // Classes CSS pour le canvas
    $canvas_classes = array('cvp-canvas');
    if (!empty($atts['canvas_class'])) {
        $canvas_classes[] = sanitize_html_class($atts['canvas_class']);
    }
    
    // Récupérer les images par défaut depuis la base de données
    $image_manager = CVP_Image_Manager::get_instance();
    $background_images = $image_manager->get_frontend_images('background');
    $overlay_images = $image_manager->get_frontend_images('overlay');
    
    ob_start();
    ?>
    <div id="<?php echo esc_attr($instance_id); ?>" 
         class="<?php echo esc_attr(implode(' ', $container_classes)); ?>"
         data-options="<?php echo esc_attr(json_encode($js_options)); ?>">
        
        <!-- Container de messages -->
        <div class="cvp-message-container"></div>
        
        <!-- En-tête avec héritage du thème -->
        <div class="cvp-header">
            <h2 class="cvp-header-title"><?php _e('Compositeur Visuel', 'compositeur-visuel-pro'); ?></h2>
            <p class="cvp-header-subtitle"><?php _e('Créez vos compositions visuelles en quelques clics', 'compositeur-visuel-pro'); ?></p>
        </div>
        
        <!-- Contenu principal -->
        <div class="cvp-main-content">
            <!-- Panneau de contrôles -->
            <div class="cvp-controls-panel">
                <div class="cvp-panel-header">
                    <h3 class="cvp-panel-title">
                        <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h4a1 1 0 010 2H6.414l2.293 2.293a1 1 0 11-1.414 1.414L5 6.414V8a1 1 0 01-2 0V4zm9 1a1 1 0 010-2h4a1 1 0 011 1v4a1 1 0 01-2 0V6.414l-2.293 2.293a1 1 0 11-1.414-1.414L13.586 5H12zm-9 7a1 1 0 012 0v1.586l2.293-2.293a1 1 0 111.414 1.414L6.414 15H8a1 1 0 010 2H4a1 1 0 01-1-1v-4zm13-1a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 010-2h1.586l-2.293-2.293a1 1 0 111.414-1.414L15 13.586V12a1 1 0 011-1z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Contrôles', 'compositeur-visuel-pro'); ?>
                    </h3>
                </div>
                
                <div class="cvp-panel-content">
                    <?php if ($atts['enable_upload'] === 'true'): ?>
                    <!-- Section Upload -->
                    <div class="cvp-control-section">
                        <h4 class="cvp-section-title"><?php _e('Ajouter une Image', 'compositeur-visuel-pro'); ?></h4>
                        <div class="cvp-upload-zone">
                            <svg class="cvp-upload-icon" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                            </svg>
                            <p class="cvp-upload-text"><?php _e('Glissez votre image ici', 'compositeur-visuel-pro'); ?></p>
                            <p class="cvp-upload-hint"><?php _e('ou cliquez pour parcourir', 'compositeur-visuel-pro'); ?></p>
                            <input type="file" class="cvp-upload-input" accept="image/*" multiple>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Section Arrière-plans -->
                    <div class="cvp-control-section">
                        <h4 class="cvp-section-title"><?php _e('Arrière-plans', 'compositeur-visuel-pro'); ?></h4>
                        <div class="cvp-image-grid cvp-background-grid">
                            <?php if (empty($background_images)): ?>
                                <div class="cvp-empty-grid">
                                    <svg class="cvp-empty-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                                    </svg>
                                    <p class="cvp-empty-text"><?php _e('Aucun arrière-plan disponible', 'compositeur-visuel-pro'); ?></p>
                                    <p class="cvp-empty-hint"><?php _e('L\'administrateur peut ajouter des images via l\'interface d\'administration', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($background_images as $image): ?>
                                    <div class="cvp-image-item cvp-background-item" 
                                         data-id="<?php echo esc_attr($image->id); ?>" 
                                         data-url="<?php echo esc_url($image->file_url); ?>"
                                         data-category="<?php echo esc_attr($image->category); ?>">
                                        <img src="<?php echo esc_url($image->file_url); ?>" 
                                             alt="<?php echo esc_attr($image->alt_text); ?>" 
                                             loading="lazy">
                                        <div class="cvp-image-overlay">
                                            <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"/>
                                            </svg>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Section Éléments -->
                    <div class="cvp-control-section">
                        <h4 class="cvp-section-title"><?php _e('Éléments', 'compositeur-visuel-pro'); ?></h4>
                        <div class="cvp-image-grid cvp-overlay-grid">
                            <?php if (empty($overlay_images)): ?>
                                <div class="cvp-empty-grid">
                                    <svg class="cvp-empty-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                        <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                                    </svg>
                                    <p class="cvp-empty-text"><?php _e('Aucun élément disponible', 'compositeur-visuel-pro'); ?></p>
                                    <p class="cvp-empty-hint"><?php _e('L\'administrateur peut ajouter des éléments via l\'interface d\'administration', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($overlay_images as $image): ?>
                                    <div class="cvp-image-item cvp-overlay-item" 
                                         data-id="<?php echo esc_attr($image->id); ?>" 
                                         data-url="<?php echo esc_url($image->file_url); ?>"
                                         data-category="<?php echo esc_attr($image->category); ?>">
                                        <img src="<?php echo esc_url($image->file_url); ?>" 
                                             alt="<?php echo esc_attr($image->alt_text); ?>" 
                                             loading="lazy">
                                        <div class="cvp-image-overlay">
                                            <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                                <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                                            </svg>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Section Contrôles d'Élément -->
                    <div class="cvp-control-section">
                        <h4 class="cvp-section-title"><?php _e('Propriétés de l\'Élément', 'compositeur-visuel-pro'); ?></h4>
                        
                        <div class="cvp-control-group">
                            <label class="cvp-control-label" for="cvp-opacity-<?php echo esc_attr($instance_id); ?>">
                                <?php _e('Opacité', 'compositeur-visuel-pro'); ?>
                                <span class="cvp-range-value cvp-opacity-value">100%</span>
                            </label>
                            <input type="range" 
                                   id="cvp-opacity-<?php echo esc_attr($instance_id); ?>"
                                   class="cvp-range-slider cvp-opacity-slider" 
                                   min="0" max="100" value="100" disabled>
                        </div>
                        
                        <div class="cvp-control-group">
                            <label class="cvp-control-label" for="cvp-rotation-<?php echo esc_attr($instance_id); ?>">
                                <?php _e('Rotation', 'compositeur-visuel-pro'); ?>
                                <span class="cvp-range-value cvp-rotation-value">0°</span>
                            </label>
                            <input type="range" 
                                   id="cvp-rotation-<?php echo esc_attr($instance_id); ?>"
                                   class="cvp-range-slider cvp-rotation-slider" 
                                   min="-180" max="180" value="0" disabled>
                        </div>
                        
                        <div class="cvp-control-group">
                            <label class="cvp-control-label" for="cvp-scale-<?php echo esc_attr($instance_id); ?>">
                                <?php _e('Échelle', 'compositeur-visuel-pro'); ?>
                                <span class="cvp-range-value cvp-scale-value">100%</span>
                            </label>
                            <input type="range" 
                                   id="cvp-scale-<?php echo esc_attr($instance_id); ?>"
                                   class="cvp-range-slider cvp-scale-slider" 
                                   min="10" max="300" value="100" disabled>
                        </div>
                        
                        <div class="cvp-control-group">
                            <label class="cvp-control-label"><?php _e('Position', 'compositeur-visuel-pro'); ?></label>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--cvp-space-2);">
                                <input type="number" 
                                       class="cvp-control-input cvp-position-x" 
                                       placeholder="X" disabled>
                                <input type="number" 
                                       class="cvp-control-input cvp-position-y" 
                                       placeholder="Y" disabled>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Section Actions -->
                    <div class="cvp-control-section">
                        <h4 class="cvp-section-title"><?php _e('Actions', 'compositeur-visuel-pro'); ?></h4>
                        <div class="cvp-button-group">
                            <button class="cvp-button cvp-button-secondary cvp-undo-button" disabled>
                                <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Annuler', 'compositeur-visuel-pro'); ?>
                            </button>
                            <button class="cvp-button cvp-button-secondary cvp-redo-button" disabled>
                                <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Refaire', 'compositeur-visuel-pro'); ?>
                            </button>
                            <button class="cvp-button cvp-button-accent cvp-reset-button">
                                <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Réinitialiser', 'compositeur-visuel-pro'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Panneau de prévisualisation -->
            <div class="cvp-preview-panel">
                <div class="cvp-canvas-container">
                    <div class="<?php echo esc_attr(implode(' ', $canvas_classes)); ?>" 
                         style="width: <?php echo intval($atts['width']); ?>px; height: <?php echo intval($atts['height']); ?>px;">
                        <div class="cvp-canvas-background"></div>
                        <div class="cvp-canvas-overlays"></div>
                    </div>
                </div>
                
                <!-- Section de téléchargement -->
                <div class="cvp-download-section">
                    <h3 class="cvp-download-title"><?php _e('Télécharger votre Création', 'compositeur-visuel-pro'); ?></h3>
                    <button class="cvp-download-button" disabled>
                        <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Télécharger PNG', 'compositeur-visuel-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Styles CSS pour l'héritage du thème -->
    <style>
    /* Héritage spécifique du thème WordPress pour cette instance */
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit {
        font-family: inherit;
        color: inherit;
        background: transparent;
    }
    
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-header-title,
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-header-subtitle,
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-panel-title,
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-section-title,
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-control-label,
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-download-title {
        font-family: inherit;
        color: inherit;
    }
    
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-header-title {
        background: inherit;
        -webkit-background-clip: unset;
        -webkit-text-fill-color: inherit;
        background-clip: unset;
    }
    
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-controls-panel,
    #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-preview-panel {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(0, 0, 0, 0.1);
    }
    
    /* Mode sombre automatique si le thème le supporte */
    @media (prefers-color-scheme: dark) {
        #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-controls-panel,
        #<?php echo esc_attr($instance_id); ?>.cvp-theme-inherit .cvp-preview-panel {
            background: rgba(0, 0, 0, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    }
    
    /* Responsive pour cette instance */
    @media (max-width: 1024px) {
        #<?php echo esc_attr($instance_id); ?> .cvp-main-content {
            grid-template-columns: 1fr;
        }
        
        #<?php echo esc_attr($instance_id); ?> .cvp-controls-panel {
            order: 2;
        }
        
        #<?php echo esc_attr($instance_id); ?> .cvp-preview-panel {
            order: 1;
        }
    }
    
    /* Ajustement automatique du canvas */
    #<?php echo esc_attr($instance_id); ?> .cvp-canvas {
        max-width: 100%;
        height: auto;
        aspect-ratio: <?php echo intval($atts['width']); ?> / <?php echo intval($atts['height']); ?>;
    }
    
    @media (max-width: 768px) {
        #<?php echo esc_attr($instance_id); ?> .cvp-canvas {
            width: 100% !important;
            height: auto !important;
        }
    }
    </style>
    
    <?php
    // Ajouter les données pour JavaScript
    wp_localize_script('cvp-frontend', 'cvpInstance_' . str_replace('-', '_', $instance_id), array(
        'instanceId' => $instance_id,
        'options' => $js_options,
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('cvp_frontend_nonce'),
        'strings' => array(
            'uploadError' => __('Erreur lors de l\'upload', 'compositeur-visuel-pro'),
            'fileTooBig' => __('Fichier trop volumineux', 'compositeur-visuel-pro'),
            'invalidType' => __('Type de fichier non supporté', 'compositeur-visuel-pro'),
            'uploadSuccess' => __('Image uploadée avec succès', 'compositeur-visuel-pro'),
            'downloadSuccess' => __('Image téléchargée avec succès', 'compositeur-visuel-pro'),
            'resetConfirm' => __('Êtes-vous sûr de vouloir tout réinitialiser ?', 'compositeur-visuel-pro'),
            'elementDeleted' => __('Élément supprimé', 'compositeur-visuel-pro'),
            'undoAction' => __('Action annulée', 'compositeur-visuel-pro'),
            'redoAction' => __('Action refaite', 'compositeur-visuel-pro')
        )
    ));
    
    return ob_get_clean();
}

/**
 * Shortcode principal
 */
function cvp_shortcode($atts) {
    return cvp_render_frontend_template($atts);
}
add_shortcode('compositeur-visuel-pro', 'cvp_shortcode');

/**
 * Gérer la prévisualisation
 */
function cvp_handle_preview() {
    if (isset($_GET['cvp_preview']) && $_GET['cvp_preview'] == '1') {
        // Afficher une page de prévisualisation simple
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php _e('Aperçu - Compositeur Visuel Pro', 'compositeur-visuel-pro'); ?></title>
            <?php wp_head(); ?>
        </head>
        <body <?php body_class(); ?>>
            <div style="padding: 20px;">
                <?php echo cvp_render_frontend_template(); ?>
            </div>
            <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        exit;
    }
}
add_action('template_redirect', 'cvp_handle_preview');

/**
 * Ajouter les styles CSS personnalisés pour l'héritage du thème
 */
function cvp_add_theme_inheritance_styles() {
    // Récupérer les couleurs du thème actuel si disponibles
    $theme_colors = array();
    
    // Essayer de récupérer les couleurs du customizer
    if (function_exists('get_theme_mod')) {
        $primary_color = get_theme_mod('primary_color');
        $secondary_color = get_theme_mod('secondary_color');
        $text_color = get_theme_mod('text_color');
        $background_color = get_theme_mod('background_color');
        
        if ($primary_color) $theme_colors['primary'] = $primary_color;
        if ($secondary_color) $theme_colors['secondary'] = $secondary_color;
        if ($text_color) $theme_colors['text'] = '#' . $text_color;
        if ($background_color) $theme_colors['background'] = '#' . $background_color;
    }
    
    // Générer les styles CSS dynamiques
    if (!empty($theme_colors)) {
        $css = '<style id="cvp-theme-inheritance">';
        $css .= '.cvp-theme-inherit {';
        
        if (isset($theme_colors['text'])) {
            $css .= 'color: ' . esc_attr($theme_colors['text']) . ' !important;';
        }
        
        if (isset($theme_colors['background'])) {
            $css .= 'background-color: ' . esc_attr($theme_colors['background']) . ' !important;';
        }
        
        $css .= '}';
        
        if (isset($theme_colors['primary'])) {
            $css .= '.cvp-theme-inherit .cvp-button-primary {';
            $css .= 'background: ' . esc_attr($theme_colors['primary']) . ' !important;';
            $css .= '}';
            
            $css .= '.cvp-theme-inherit .cvp-range-slider::-webkit-slider-thumb {';
            $css .= 'background: ' . esc_attr($theme_colors['primary']) . ' !important;';
            $css .= '}';
        }
        
        $css .= '</style>';
        
        echo $css;
    }
}
add_action('wp_head', 'cvp_add_theme_inheritance_styles');

/**
 * Ajouter les classes CSS du thème au body
 */
function cvp_add_theme_body_classes($classes) {
    // Ajouter une classe pour identifier que le plugin est actif
    if (is_singular() && has_shortcode(get_post()->post_content, 'compositeur-visuel-pro')) {
        $classes[] = 'has-cvp-composer';
    }
    
    return $classes;
}
add_filter('body_class', 'cvp_add_theme_body_classes');

