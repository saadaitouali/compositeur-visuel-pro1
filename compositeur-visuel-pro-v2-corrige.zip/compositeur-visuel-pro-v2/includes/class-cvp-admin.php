<?php
/**
 * Classe d'administration du Compositeur Visuel Pro
 * Interface moderne et élégante pour la gestion du plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

class CVP_Admin {
    
    /**
     * Instance unique
     */
    private static $instance = null;
    
    /**
     * Options du plugin
     */
    private $options;
    
    /**
     * Obtenir l'instance unique
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructeur
     */
    private function __construct() {
        $this->options = get_option('cvp_options', array());
        $this->init_hooks();
    }
    
    /**
     * Initialiser les hooks
     */
    private function init_hooks() {
        add_action('admin_init', array($this, 'admin_init'));
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    /**
     * Initialisation admin
     */
    public function admin_init() {
        // Enregistrer les sections et champs de paramètres
        $this->register_settings();
    }
    
    /**
     * Enregistrer les paramètres
     */
    private function register_settings() {
        // Section générale
        add_settings_section(
            'cvp_general_section',
            __('Paramètres Généraux', 'compositeur-visuel-pro'),
            array($this, 'general_section_callback'),
            'cvp_settings'
        );
        
        // Section apparence
        add_settings_section(
            'cvp_appearance_section',
            __('Apparence et Design', 'compositeur-visuel-pro'),
            array($this, 'appearance_section_callback'),
            'cvp_settings'
        );
        
        // Section fonctionnalités
        add_settings_section(
            'cvp_features_section',
            __('Fonctionnalités', 'compositeur-visuel-pro'),
            array($this, 'features_section_callback'),
            'cvp_settings'
        );
        
        // Section intégration thème
        add_settings_section(
            'cvp_theme_section',
            __('Intégration Thème WordPress', 'compositeur-visuel-pro'),
            array($this, 'theme_section_callback'),
            'cvp_settings'
        );
    }
    
    /**
     * Callback section générale
     */
    public function general_section_callback() {
        echo '<p>' . __('Configurez les paramètres de base du compositeur visuel.', 'compositeur-visuel-pro') . '</p>';
    }
    
    /**
     * Callback section apparence
     */
    public function appearance_section_callback() {
        echo '<p>' . __('Personnalisez l\'apparence et les couleurs de l\'interface.', 'compositeur-visuel-pro') . '</p>';
    }
    
    /**
     * Callback section fonctionnalités
     */
    public function features_section_callback() {
        echo '<p>' . __('Activez ou désactivez les fonctionnalités avancées.', 'compositeur-visuel-pro') . '</p>';
    }
    
    /**
     * Callback section thème
     */
    public function theme_section_callback() {
        echo '<p>' . __('Configurez l\'intégration avec votre thème WordPress.', 'compositeur-visuel-pro') . '</p>';
    }
    
    /**
     * Afficher les notices admin
     */
    public function admin_notices() {
        if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>' . __('Paramètres sauvegardés avec succès.', 'compositeur-visuel-pro') . '</p>';
            echo '</div>';
        }
    }
    
    /**
     * Rendre le tableau de bord principal
     */
    public function render_dashboard() {
        $stats = $this->get_dashboard_stats();
        ?>
        <div class="cvp-admin-wrap">
            <!-- En-tête moderne -->
            <div class="cvp-admin-header">
                <div class="cvp-header-content">
                    <div class="cvp-header-main">
                        <h1 class="cvp-header-title">
                            <svg class="cvp-header-icon" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M4 4h7V2a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2h7a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-7v7a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-7H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/>
                            </svg>
                            <?php _e('Compositeur Visuel Pro', 'compositeur-visuel-pro'); ?>
                        </h1>
                        <p class="cvp-header-subtitle">
                            <?php _e('Créez des compositions visuelles professionnelles avec une interface moderne', 'compositeur-visuel-pro'); ?>
                        </p>
                    </div>
                    <div class="cvp-header-actions">
                        <a href="<?php echo admin_url('admin.php?page=cvp-settings'); ?>" class="cvp-btn cvp-btn-primary">
                            <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Paramètres', 'compositeur-visuel-pro'); ?>
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Contenu principal -->
            <div class="cvp-admin-content">
                <!-- Statistiques -->
                <div class="cvp-stats-grid">
                    <div class="cvp-stat-card">
                        <div class="cvp-stat-icon cvp-stat-icon-primary">
                            <svg fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div class="cvp-stat-content">
                            <div class="cvp-stat-number"><?php echo $stats['total_images']; ?></div>
                            <div class="cvp-stat-label"><?php _e('Images Totales', 'compositeur-visuel-pro'); ?></div>
                        </div>
                    </div>
                    
                    <div class="cvp-stat-card">
                        <div class="cvp-stat-icon cvp-stat-icon-success">
                            <svg fill="currentColor" viewBox="0 0 20 20">
                                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
                            </svg>
                        </div>
                        <div class="cvp-stat-content">
                            <div class="cvp-stat-number"><?php echo $stats['backgrounds']; ?></div>
                            <div class="cvp-stat-label"><?php _e('Arrière-plans', 'compositeur-visuel-pro'); ?></div>
                        </div>
                    </div>
                    
                    <div class="cvp-stat-card">
                        <div class="cvp-stat-icon cvp-stat-icon-warning">
                            <svg fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div class="cvp-stat-content">
                            <div class="cvp-stat-number"><?php echo $stats['overlays']; ?></div>
                            <div class="cvp-stat-label"><?php _e('Éléments', 'compositeur-visuel-pro'); ?></div>
                        </div>
                    </div>
                    
                    <div class="cvp-stat-card">
                        <div class="cvp-stat-icon cvp-stat-icon-info">
                            <svg fill="currentColor" viewBox="0 0 20 20">
                                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
                            </svg>
                        </div>
                        <div class="cvp-stat-content">
                            <div class="cvp-stat-number"><?php echo $this->format_file_size($stats['storage_used']); ?></div>
                            <div class="cvp-stat-label"><?php _e('Stockage Utilisé', 'compositeur-visuel-pro'); ?></div>
                        </div>
                    </div>
                </div>
                
                <!-- Grille principale -->
                <div class="cvp-main-grid">
                    <!-- Démarrage rapide -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Démarrage Rapide', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-shortcode-showcase">
                                <h3><?php _e('Shortcode Principal', 'compositeur-visuel-pro'); ?></h3>
                                <div class="cvp-shortcode-box">
                                    <code>[compositeur-visuel-pro]</code>
                                    <button class="cvp-copy-btn" onclick="copyToClipboard('[compositeur-visuel-pro]')">
                                        <svg fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z"/>
                                            <path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z"/>
                                        </svg>
                                        <?php _e('Copier', 'compositeur-visuel-pro'); ?>
                                    </button>
                                </div>
                                
                                <h4><?php _e('Options Avancées', 'compositeur-visuel-pro'); ?></h4>
                                <div class="cvp-shortcode-examples">
                                    <div class="cvp-example-item">
                                        <code>[compositeur-visuel-pro width="1000" height="800"]</code>
                                        <span class="cvp-example-desc"><?php _e('Dimensions personnalisées', 'compositeur-visuel-pro'); ?></span>
                                    </div>
                                    <div class="cvp-example-item">
                                        <code>[compositeur-visuel-pro theme="dark"]</code>
                                        <span class="cvp-example-desc"><?php _e('Thème sombre', 'compositeur-visuel-pro'); ?></span>
                                    </div>
                                    <div class="cvp-example-item">
                                        <code>[compositeur-visuel-pro enable_upload="false"]</code>
                                        <span class="cvp-example-desc"><?php _e('Désactiver l\'upload', 'compositeur-visuel-pro'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Gestion des images -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Gestion des Images', 'compositeur-visuel-pro'); ?>
                            </h2>
                            <a href="<?php echo admin_url('admin.php?page=cvp-images'); ?>" class="cvp-btn cvp-btn-secondary cvp-btn-sm">
                                <?php _e('Voir Tout', 'compositeur-visuel-pro'); ?>
                            </a>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-image-manager-preview">
                                <?php $this->render_recent_images(); ?>
                            </div>
                            <div class="cvp-quick-actions">
                                <button class="cvp-btn cvp-btn-primary" onclick="openImageUploader()">
                                    <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm5 6a1 1 0 011-1h1a1 1 0 110 2v3a1 1 0 11-2 0v-3a1 1 0 01-1-1z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Ajouter des Images', 'compositeur-visuel-pro'); ?>
                                </button>
                                <a href="<?php echo admin_url('admin.php?page=cvp-images'); ?>" class="cvp-btn cvp-btn-secondary">
                                    <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                    </svg>
                                    <?php _e('Gérer les Images', 'compositeur-visuel-pro'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Aperçu en direct -->
                    <div class="cvp-admin-card cvp-card-full">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                    <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Aperçu en Direct', 'compositeur-visuel-pro'); ?>
                            </h2>
                            <button class="cvp-btn cvp-btn-secondary cvp-btn-sm" onclick="refreshPreview()">
                                <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Actualiser', 'compositeur-visuel-pro'); ?>
                            </button>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-preview-container">
                                <iframe id="cvp-live-preview" src="<?php echo $this->get_preview_url(); ?>" frameborder="0"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Sidebar -->
                <div class="cvp-admin-sidebar">
                    <!-- Informations système -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h3 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Informations', 'compositeur-visuel-pro'); ?>
                            </h3>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-info-list">
                                <div class="cvp-info-item">
                                    <span class="cvp-info-label"><?php _e('Version', 'compositeur-visuel-pro'); ?></span>
                                    <span class="cvp-info-value"><?php echo CVP_VERSION; ?></span>
                                </div>
                                <div class="cvp-info-item">
                                    <span class="cvp-info-label"><?php _e('WordPress', 'compositeur-visuel-pro'); ?></span>
                                    <span class="cvp-info-value"><?php echo get_bloginfo('version'); ?></span>
                                </div>
                                <div class="cvp-info-item">
                                    <span class="cvp-info-label"><?php _e('PHP', 'compositeur-visuel-pro'); ?></span>
                                    <span class="cvp-info-value"><?php echo PHP_VERSION; ?></span>
                                </div>
                                <div class="cvp-info-item">
                                    <span class="cvp-info-label"><?php _e('Thème Actif', 'compositeur-visuel-pro'); ?></span>
                                    <span class="cvp-info-value"><?php echo wp_get_theme()->get('Name'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Actions rapides -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h3 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Actions Rapides', 'compositeur-visuel-pro'); ?>
                            </h3>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-quick-actions-list">
                                <button class="cvp-quick-action" onclick="clearCache()">
                                    <svg class="cvp-action-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" clip-rule="evenodd"/>
                                        <path fill-rule="evenodd" d="M4 5a2 2 0 012-2h8a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 3a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Vider le Cache', 'compositeur-visuel-pro'); ?>
                                </button>
                                
                                <button class="cvp-quick-action" onclick="exportSettings()">
                                    <svg class="cvp-action-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Exporter Paramètres', 'compositeur-visuel-pro'); ?>
                                </button>
                                
                                <button class="cvp-quick-action" onclick="importSettings()">
                                    <svg class="cvp-action-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 11-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Importer Paramètres', 'compositeur-visuel-pro'); ?>
                                </button>
                                
                                <a href="<?php echo admin_url('admin.php?page=cvp-settings'); ?>" class="cvp-quick-action">
                                    <svg class="cvp-action-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Paramètres Avancés', 'compositeur-visuel-pro'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Support -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h3 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-2 0c0 .993-.241 1.929-.668 2.754l-1.524-1.525a3.997 3.997 0 00.078-2.183l1.562-1.562C15.802 8.249 16 9.1 16 10zm-5.165 3.913l1.58 1.58A5.98 5.98 0 0110 16a5.976 5.976 0 01-2.516-.552l1.562-1.562a4.006 4.006 0 001.789.027zm-4.677-2.796a4.002 4.002 0 01-.041-2.08l-1.106-1.106A6.003 6.003 0 004 10c0 .639.1 1.255.283 1.836l1.555-1.555zM10 8a2 2 0 100 4 2 2 0 000-4z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Support & Aide', 'compositeur-visuel-pro'); ?>
                            </h3>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-support-links">
                                <a href="https://aitouali.com/compositeur-visuel-pro/documentation" target="_blank" class="cvp-support-link">
                                    <svg class="cvp-link-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Documentation', 'compositeur-visuel-pro'); ?>
                                </a>
                                
                                <a href="https://aitouali.com/support" target="_blank" class="cvp-support-link">
                                    <svg class="cvp-link-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zM7 8H5v2h2V8zm2 0h2v2H9V8zm6 0h-2v2h2V8z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Support Technique', 'compositeur-visuel-pro'); ?>
                                </a>
                                
                                <a href="https://aitouali.com" target="_blank" class="cvp-support-link">
                                    <svg class="cvp-link-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Site du Développeur', 'compositeur-visuel-pro'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Modal d'upload d'images -->
        <div id="cvp-image-upload-modal" class="cvp-modal" style="display: none;">
            <div class="cvp-modal-content">
                <div class="cvp-modal-header">
                    <h3><?php _e('Ajouter des Images', 'compositeur-visuel-pro'); ?></h3>
                    <button class="cvp-modal-close" onclick="closeImageUploader()">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                    </button>
                </div>
                <div class="cvp-modal-body">
                    <?php $this->render_image_uploader(); ?>
                </div>
            </div>
        </div>
        
        <script>
        // Fonctions JavaScript pour l'interface admin
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                showNotification('<?php _e('Shortcode copié !', 'compositeur-visuel-pro'); ?>', 'success');
            });
        }
        
        function openImageUploader() {
            document.getElementById('cvp-image-upload-modal').style.display = 'flex';
        }
        
        function closeImageUploader() {
            document.getElementById('cvp-image-upload-modal').style.display = 'none';
        }
        
        function refreshPreview() {
            const iframe = document.getElementById('cvp-live-preview');
            iframe.src = iframe.src;
        }
        
        function clearCache() {
            // Implémentation du vidage de cache
            showNotification('<?php _e('Cache vidé avec succès', 'compositeur-visuel-pro'); ?>', 'success');
        }
        
        function exportSettings() {
            // Implémentation de l'export
            window.location.href = '<?php echo admin_url('admin-ajax.php?action=cvp_export_settings&nonce=' . wp_create_nonce('cvp_admin_nonce')); ?>';
        }
        
        function importSettings() {
            // Implémentation de l'import
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = function(e) {
                // Traitement du fichier d'import
            };
            input.click();
        }
        
        function showNotification(message, type) {
            // Afficher une notification
            const notification = document.createElement('div');
            notification.className = `cvp-notification cvp-notification-${type}`;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
        </script>
        <?php
    }
    
    /**
     * Obtenir les statistiques du tableau de bord
     */
    private function get_dashboard_stats() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        // Compter les images par type
        $backgrounds = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE image_type = %s",
            'background'
        ));
        
        $overlays = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE image_type = %s",
            'overlay'
        ));
        
        $total_images = $backgrounds + $overlays;
        
        // Calculer l'espace de stockage utilisé
        $storage_used = $wpdb->get_var("SELECT SUM(file_size) FROM $table_name");
        
        return array(
            'total_images' => $total_images ?: 0,
            'backgrounds' => $backgrounds ?: 0,
            'overlays' => $overlays ?: 0,
            'storage_used' => $storage_used ?: 0
        );
    }
    
    /**
     * Formater la taille de fichier
     */
    private function format_file_size($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } else {
            return $bytes . ' B';
        }
    }
    
    /**
     * Rendre les images récentes
     */
    private function render_recent_images() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        $recent_images = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 6"
        );
        
        if (empty($recent_images)) {
            echo '<div class="cvp-empty-state">';
            echo '<svg class="cvp-empty-icon" fill="currentColor" viewBox="0 0 20 20">';
            echo '<path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>';
            echo '</svg>';
            echo '<p>' . __('Aucune image disponible', 'compositeur-visuel-pro') . '</p>';
            echo '<p class="cvp-empty-hint">' . __('Commencez par ajouter des images pour vos compositions', 'compositeur-visuel-pro') . '</p>';
            echo '</div>';
            return;
        }
        
        echo '<div class="cvp-recent-images-grid">';
        foreach ($recent_images as $image) {
            echo '<div class="cvp-recent-image-item">';
            echo '<img src="' . esc_url($image->file_url) . '" alt="' . esc_attr($image->alt_text) . '" loading="lazy">';
            echo '<div class="cvp-image-info">';
            echo '<span class="cvp-image-type cvp-type-' . esc_attr($image->image_type) . '">' . ucfirst($image->image_type) . '</span>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    }
    
    /**
     * Obtenir l'URL de prévisualisation
     */
    private function get_preview_url() {
        // Créer une page temporaire avec le shortcode pour la prévisualisation
        return home_url('?cvp_preview=1');
    }
    
    /**
     * Rendre l'uploader d'images
     */
    private function render_image_uploader() {
        ?>
        <div class="cvp-image-uploader">
            <div class="cvp-upload-tabs">
                <button class="cvp-tab-btn active" data-tab="upload"><?php _e('Upload', 'compositeur-visuel-pro'); ?></button>
                <button class="cvp-tab-btn" data-tab="media"><?php _e('Médiathèque', 'compositeur-visuel-pro'); ?></button>
            </div>
            
            <div class="cvp-tab-content" id="upload-tab">
                <div class="cvp-upload-dropzone" id="cvp-admin-dropzone">
                    <svg class="cvp-upload-icon" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                    </svg>
                    <h3><?php _e('Glissez vos images ici', 'compositeur-visuel-pro'); ?></h3>
                    <p><?php _e('ou cliquez pour parcourir vos fichiers', 'compositeur-visuel-pro'); ?></p>
                    <input type="file" id="cvp-admin-file-input" multiple accept="image/*" style="display: none;">
                </div>
                
                <div class="cvp-upload-options">
                    <div class="cvp-option-group">
                        <label for="image-type"><?php _e('Type d\'image', 'compositeur-visuel-pro'); ?></label>
                        <select id="image-type" class="cvp-select">
                            <option value="background"><?php _e('Arrière-plan', 'compositeur-visuel-pro'); ?></option>
                            <option value="overlay"><?php _e('Élément de superposition', 'compositeur-visuel-pro'); ?></option>
                        </select>
                    </div>
                    
                    <div class="cvp-option-group">
                        <label for="image-category"><?php _e('Catégorie', 'compositeur-visuel-pro'); ?></label>
                        <input type="text" id="image-category" class="cvp-input" placeholder="<?php _e('Ex: nature, business, abstract...', 'compositeur-visuel-pro'); ?>">
                    </div>
                </div>
                
                <div class="cvp-upload-progress" id="cvp-upload-progress" style="display: none;">
                    <div class="cvp-progress-bar">
                        <div class="cvp-progress-fill"></div>
                    </div>
                    <div class="cvp-progress-text">0%</div>
                </div>
            </div>
            
            <div class="cvp-tab-content" id="media-tab" style="display: none;">
                <div class="cvp-media-library">
                    <p><?php _e('Sélectionnez des images depuis votre médiathèque WordPress', 'compositeur-visuel-pro'); ?></p>
                    <button class="cvp-btn cvp-btn-primary" onclick="openMediaLibrary()">
                        <?php _e('Ouvrir la Médiathèque', 'compositeur-visuel-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Rendre la page de gestion des images
     */
    public function render_images_page() {
        $image_manager = CVP_Image_Manager::get_instance();
        $backgrounds = $image_manager->get_frontend_images('background');
        $overlays = $image_manager->get_frontend_images('overlay');
        $total_images = count($backgrounds) + count($overlays);
        
        // Calculer l'espace de stockage utilisé
        $total_size = 0;
        foreach (array_merge($backgrounds, $overlays) as $image) {
            $total_size += $image->file_size ?? 0;
        }
        $formatted_size = $this->format_file_size($total_size);
        ?>
        <div class="cvp-admin-wrap">
            <div class="cvp-admin-header">
                <div class="cvp-header-content">
                    <h1 class="cvp-admin-title">
                        <svg class="cvp-title-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Gestionnaire d\'Images', 'compositeur-visuel-pro'); ?>
                    </h1>
                    <p class="cvp-admin-subtitle"><?php _e('Gérez vos images d\'arrière-plan et éléments de superposition', 'compositeur-visuel-pro'); ?></p>
                </div>
                <div class="cvp-header-actions">
                    <button class="cvp-btn cvp-btn-primary" onclick="openUploadModal()">
                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Ajouter des Images', 'compositeur-visuel-pro'); ?>
                    </button>
                </div>
            </div>
            
            <!-- Statistiques rapides -->
            <div class="cvp-stats-grid">
                <div class="cvp-stat-card">
                    <div class="cvp-stat-icon cvp-stat-icon-primary">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="cvp-stat-content">
                        <div class="cvp-stat-number"><?php echo $total_images; ?></div>
                        <div class="cvp-stat-label"><?php _e('Images Totales', 'compositeur-visuel-pro'); ?></div>
                    </div>
                </div>
                
                <div class="cvp-stat-card">
                    <div class="cvp-stat-icon cvp-stat-icon-success">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"/>
                        </svg>
                    </div>
                    <div class="cvp-stat-content">
                        <div class="cvp-stat-number"><?php echo count($backgrounds); ?></div>
                        <div class="cvp-stat-label"><?php _e('Arrière-plans', 'compositeur-visuel-pro'); ?></div>
                    </div>
                </div>
                
                <div class="cvp-stat-card">
                    <div class="cvp-stat-icon cvp-stat-icon-warning">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                            <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="cvp-stat-content">
                        <div class="cvp-stat-number"><?php echo count($overlays); ?></div>
                        <div class="cvp-stat-label"><?php _e('Éléments', 'compositeur-visuel-pro'); ?></div>
                    </div>
                </div>
                
                <div class="cvp-stat-card">
                    <div class="cvp-stat-icon cvp-stat-icon-info">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 11-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
                        </svg>
                    </div>
                    <div class="cvp-stat-content">
                        <div class="cvp-stat-number"><?php echo $formatted_size; ?></div>
                        <div class="cvp-stat-label"><?php _e('Espace Utilisé', 'compositeur-visuel-pro'); ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Filtres et recherche -->
            <div class="cvp-admin-card">
                <div class="cvp-card-header">
                    <h2 class="cvp-card-title">
                        <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Filtres et Recherche', 'compositeur-visuel-pro'); ?>
                    </h2>
                </div>
                <div class="cvp-card-content">
                    <div class="cvp-filters-row">
                        <div class="cvp-filter-group">
                            <label for="image-search"><?php _e('Rechercher', 'compositeur-visuel-pro'); ?></label>
                            <input type="text" id="image-search" class="cvp-input" placeholder="<?php _e('Nom de fichier, catégorie...', 'compositeur-visuel-pro'); ?>">
                        </div>
                        
                        <div class="cvp-filter-group">
                            <label for="image-type-filter"><?php _e('Type', 'compositeur-visuel-pro'); ?></label>
                            <select id="image-type-filter" class="cvp-select">
                                <option value="all"><?php _e('Tous les types', 'compositeur-visuel-pro'); ?></option>
                                <option value="background"><?php _e('Arrière-plans', 'compositeur-visuel-pro'); ?></option>
                                <option value="overlay"><?php _e('Éléments', 'compositeur-visuel-pro'); ?></option>
                            </select>
                        </div>
                        
                        <div class="cvp-filter-group">
                            <label for="image-category-filter"><?php _e('Catégorie', 'compositeur-visuel-pro'); ?></label>
                            <select id="image-category-filter" class="cvp-select">
                                <option value="all"><?php _e('Toutes les catégories', 'compositeur-visuel-pro'); ?></option>
                                <option value="general"><?php _e('Général', 'compositeur-visuel-pro'); ?></option>
                                <option value="nature"><?php _e('Nature', 'compositeur-visuel-pro'); ?></option>
                                <option value="business"><?php _e('Business', 'compositeur-visuel-pro'); ?></option>
                                <option value="abstract"><?php _e('Abstrait', 'compositeur-visuel-pro'); ?></option>
                            </select>
                        </div>
                        
                        <div class="cvp-filter-actions">
                            <button class="cvp-btn cvp-btn-secondary" onclick="resetFilters()">
                                <?php _e('Réinitialiser', 'compositeur-visuel-pro'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Grille d'images -->
            <div class="cvp-admin-card">
                <div class="cvp-card-header">
                    <h2 class="cvp-card-title">
                        <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Bibliothèque d\'Images', 'compositeur-visuel-pro'); ?>
                    </h2>
                    <div class="cvp-card-actions">
                        <button class="cvp-btn cvp-btn-secondary cvp-btn-sm" onclick="toggleViewMode()">
                            <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                            </svg>
                            <?php _e('Vue', 'compositeur-visuel-pro'); ?>
                        </button>
                    </div>
                </div>
                <div class="cvp-card-content">
                    <?php if ($total_images > 0): ?>
                        <div class="cvp-images-grid" id="cvp-images-grid">
                            <?php foreach ($backgrounds as $image): ?>
                                <div class="cvp-image-card" data-type="background" data-category="<?php echo esc_attr($image->category ?? 'general'); ?>">
                                    <div class="cvp-image-preview">
                                        <img src="<?php echo esc_url($image->file_url); ?>" alt="<?php echo esc_attr($image->alt_text ?? $image->original_name); ?>" loading="lazy">
                                        <div class="cvp-image-overlay">
                                            <div class="cvp-image-actions">
                                                <button class="cvp-image-action" onclick="previewImage('<?php echo esc_js($image->file_url); ?>')" title="<?php _e('Aperçu', 'compositeur-visuel-pro'); ?>">
                                                    <svg fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                                        <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                                                    </svg>
                                                </button>
                                                <button class="cvp-image-action" onclick="editImage(<?php echo $image->id; ?>)" title="<?php _e('Modifier', 'compositeur-visuel-pro'); ?>">
                                                    <svg fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/>
                                                    </svg>
                                                </button>
                                                <button class="cvp-image-action cvp-image-action-danger" onclick="deleteImage(<?php echo $image->id; ?>)" title="<?php _e('Supprimer', 'compositeur-visuel-pro'); ?>">
                                                    <svg fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="cvp-image-info">
                                        <div class="cvp-image-title"><?php echo esc_html($image->original_name); ?></div>
                                        <div class="cvp-image-meta">
                                            <span class="cvp-image-type cvp-type-background"><?php _e('Arrière-plan', 'compositeur-visuel-pro'); ?></span>
                                            <span class="cvp-image-size"><?php echo $this->format_file_size($image->file_size ?? 0); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <?php foreach ($overlays as $image): ?>
                                <div class="cvp-image-card" data-type="overlay" data-category="<?php echo esc_attr($image->category ?? 'general'); ?>">
                                    <div class="cvp-image-preview">
                                        <img src="<?php echo esc_url($image->file_url); ?>" alt="<?php echo esc_attr($image->alt_text ?? $image->original_name); ?>" loading="lazy">
                                        <div class="cvp-image-overlay">
                                            <div class="cvp-image-actions">
                                                <button class="cvp-image-action" onclick="previewImage('<?php echo esc_js($image->file_url); ?>')" title="<?php _e('Aperçu', 'compositeur-visuel-pro'); ?>">
                                                    <svg fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                                        <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                                                    </svg>
                                                </button>
                                                <button class="cvp-image-action" onclick="editImage(<?php echo $image->id; ?>)" title="<?php _e('Modifier', 'compositeur-visuel-pro'); ?>">
                                                    <svg fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/>
                                                    </svg>
                                                </button>
                                                <button class="cvp-image-action cvp-image-action-danger" onclick="deleteImage(<?php echo $image->id; ?>)" title="<?php _e('Supprimer', 'compositeur-visuel-pro'); ?>">
                                                    <svg fill="currentColor" viewBox="0 0 20 20">
                                                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="cvp-image-info">
                                        <div class="cvp-image-title"><?php echo esc_html($image->original_name); ?></div>
                                        <div class="cvp-image-meta">
                                            <span class="cvp-image-type cvp-type-overlay"><?php _e('Élément', 'compositeur-visuel-pro'); ?></span>
                                            <span class="cvp-image-size"><?php echo $this->format_file_size($image->file_size ?? 0); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="cvp-empty-state">
                            <div class="cvp-empty-icon">
                                <svg fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                                </svg>
                            </div>
                            <h3 class="cvp-empty-title"><?php _e('Aucune image trouvée', 'compositeur-visuel-pro'); ?></h3>
                            <p class="cvp-empty-description"><?php _e('Commencez par ajouter des images d\'arrière-plan et des éléments pour vos compositions.', 'compositeur-visuel-pro'); ?></p>
                            <button class="cvp-btn cvp-btn-primary" onclick="openUploadModal()">
                                <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Ajouter des Images', 'compositeur-visuel-pro'); ?>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Modal d'upload -->
        <div id="cvp-upload-modal" class="cvp-modal" style="display: none;">
            <div class="cvp-modal-content">
                <div class="cvp-modal-header">
                    <h3 class="cvp-modal-title"><?php _e('Ajouter des Images', 'compositeur-visuel-pro'); ?></h3>
                    <button class="cvp-modal-close" onclick="closeUploadModal()">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                    </button>
                </div>
                <div class="cvp-modal-body">
                    <?php $this->render_upload_interface(); ?>
                </div>
            </div>
        </div>
        
        <!-- Modal de prévisualisation -->
        <div id="cvp-preview-modal" class="cvp-modal" style="display: none;">
            <div class="cvp-modal-content cvp-modal-large">
                <div class="cvp-modal-header">
                    <h3 class="cvp-modal-title"><?php _e('Aperçu de l\'Image', 'compositeur-visuel-pro'); ?></h3>
                    <button class="cvp-modal-close" onclick="closePreviewModal()">
                        <svg fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                    </button>
                </div>
                <div class="cvp-modal-body">
                    <div class="cvp-preview-container">
                        <img id="cvp-preview-image" src="" alt="Aperçu">
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        function openUploadModal() {
            document.getElementById('cvp-upload-modal').style.display = 'flex';
        }
        
        function closeUploadModal() {
            document.getElementById('cvp-upload-modal').style.display = 'none';
        }
        
        function previewImage(url) {
            document.getElementById('cvp-preview-image').src = url;
            document.getElementById('cvp-preview-modal').style.display = 'flex';
        }
        
        function closePreviewModal() {
            document.getElementById('cvp-preview-modal').style.display = 'none';
        }
        
        function deleteImage(imageId) {
            if (confirm('<?php _e('Êtes-vous sûr de vouloir supprimer cette image ?', 'compositeur-visuel-pro'); ?>')) {
                // Implémentation de la suppression via AJAX
                console.log('Suppression de l\'image ID:', imageId);
            }
        }
        
        function editImage(imageId) {
            // Implémentation de l'édition
            console.log('Édition de l\'image ID:', imageId);
        }
        
        function resetFilters() {
            document.getElementById('image-search').value = '';
            document.getElementById('image-type-filter').value = 'all';
            document.getElementById('image-category-filter').value = 'all';
            // Réafficher toutes les images
        }
        
        function toggleViewMode() {
            const grid = document.getElementById('cvp-images-grid');
            grid.classList.toggle('cvp-images-list');
        }
        </script>
        <?php
    }
    
    /**
     * Rendre la page des paramètres
     */
    public function render_settings_page() {
        $options = get_option('cvp_options', array());
        
        // Traitement du formulaire
        if (isset($_POST['submit']) && wp_verify_nonce($_POST['cvp_settings_nonce'], 'cvp_save_settings')) {
            $options = $this->sanitize_settings($_POST);
            update_option('cvp_options', $options);
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Paramètres sauvegardés avec succès !', 'compositeur-visuel-pro') . '</p></div>';
        }
        ?>
        <div class="cvp-admin-wrap">
            <div class="cvp-admin-header">
                <div class="cvp-header-content">
                    <h1 class="cvp-admin-title">
                        <svg class="cvp-title-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Paramètres', 'compositeur-visuel-pro'); ?>
                    </h1>
                    <p class="cvp-admin-subtitle"><?php _e('Configurez votre compositeur visuel selon vos besoins', 'compositeur-visuel-pro'); ?></p>
                </div>
                <div class="cvp-header-actions">
                    <button type="submit" form="cvp-settings-form" class="cvp-btn cvp-btn-primary">
                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Sauvegarder', 'compositeur-visuel-pro'); ?>
                    </button>
                </div>
            </div>
            
            <form id="cvp-settings-form" method="post" action="">
                <?php wp_nonce_field('cvp_save_settings', 'cvp_settings_nonce'); ?>
                
                <div class="cvp-settings-grid">
                    <!-- Paramètres généraux -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Paramètres Généraux', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-settings-section">
                                <div class="cvp-setting-group">
                                    <label for="canvas_width" class="cvp-setting-label"><?php _e('Largeur du Canvas (px)', 'compositeur-visuel-pro'); ?></label>
                                    <input type="number" id="canvas_width" name="canvas_width" class="cvp-input" value="<?php echo esc_attr($options['canvas_width'] ?? 800); ?>" min="200" max="2000">
                                    <p class="cvp-setting-description"><?php _e('Largeur par défaut du canvas de composition', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="canvas_height" class="cvp-setting-label"><?php _e('Hauteur du Canvas (px)', 'compositeur-visuel-pro'); ?></label>
                                    <input type="number" id="canvas_height" name="canvas_height" class="cvp-input" value="<?php echo esc_attr($options['canvas_height'] ?? 600); ?>" min="200" max="2000">
                                    <p class="cvp-setting-description"><?php _e('Hauteur par défaut du canvas de composition', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="max_upload_size" class="cvp-setting-label"><?php _e('Taille Max Upload (MB)', 'compositeur-visuel-pro'); ?></label>
                                    <input type="number" id="max_upload_size" name="max_upload_size" class="cvp-input" value="<?php echo esc_attr($options['max_upload_size'] ?? 10); ?>" min="1" max="50">
                                    <p class="cvp-setting-description"><?php _e('Taille maximale des fichiers uploadés', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="compression_quality" class="cvp-setting-label"><?php _e('Qualité de Compression (%)', 'compositeur-visuel-pro'); ?></label>
                                    <input type="range" id="compression_quality" name="compression_quality" class="cvp-range" value="<?php echo esc_attr($options['compression_quality'] ?? 85); ?>" min="50" max="100">
                                    <span class="cvp-range-value"><?php echo esc_attr($options['compression_quality'] ?? 85); ?>%</span>
                                    <p class="cvp-setting-description"><?php _e('Qualité de compression des images uploadées', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Apparence et couleurs -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4 2a2 2 0 00-2 2v11a3 3 0 106 0V4a2 2 0 00-2-2H4zM3 15a1 1 0 011-1h1a1 1 0 011 1v1a1 1 0 01-1 1H4a1 1 0 01-1-1v-1zm6-11a1 1 0 011-1h1a1 1 0 011 1v2H9V4zm4 11a1 1 0 011-1h1a1 1 0 011 1v1a1 1 0 01-1 1h-1a1 1 0 01-1-1v-1z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Apparence et Couleurs', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-settings-section">
                                <div class="cvp-setting-group">
                                    <label for="primary_color" class="cvp-setting-label"><?php _e('Couleur Primaire', 'compositeur-visuel-pro'); ?></label>
                                    <input type="color" id="primary_color" name="primary_color" class="cvp-color-picker" value="<?php echo esc_attr($options['primary_color'] ?? '#667eea'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Couleur principale de l\'interface', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="secondary_color" class="cvp-setting-label"><?php _e('Couleur Secondaire', 'compositeur-visuel-pro'); ?></label>
                                    <input type="color" id="secondary_color" name="secondary_color" class="cvp-color-picker" value="<?php echo esc_attr($options['secondary_color'] ?? '#764ba2'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Couleur secondaire pour les accents', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="accent_color" class="cvp-setting-label"><?php _e('Couleur d\'Accent', 'compositeur-visuel-pro'); ?></label>
                                    <input type="color" id="accent_color" name="accent_color" class="cvp-color-picker" value="<?php echo esc_attr($options['accent_color'] ?? '#f093fb'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Couleur pour les éléments d\'accent', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Intégration thème WordPress -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Intégration Thème WordPress', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-settings-section">
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="inherit_theme_colors" value="1" <?php checked($options['inherit_theme_colors'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Hériter des couleurs du thème', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Utilise automatiquement les couleurs de votre thème WordPress', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="inherit_theme_fonts" value="1" <?php checked($options['inherit_theme_fonts'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Hériter des polices du thème', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Utilise les polices définies par votre thème WordPress', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="inherit_theme_spacing" value="1" <?php checked($options['inherit_theme_spacing'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Hériter de l\'espacement du thème', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Adapte les marges et espacements selon votre thème', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Fonctionnalités -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Fonctionnalités', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-settings-section">
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="enable_drag_drop" value="1" <?php checked($options['enable_drag_drop'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Glisser-Déposer', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Permet de déplacer les éléments par glisser-déposer', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="enable_opacity_control" value="1" <?php checked($options['enable_opacity_control'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Contrôle d\'Opacité', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Affiche le curseur de contrôle d\'opacité', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="enable_rotation" value="1" <?php checked($options['enable_rotation'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Rotation des Éléments', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Permet de faire pivoter les éléments', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="enable_resize" value="1" <?php checked($options['enable_resize'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Redimensionnement', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Permet de redimensionner les éléments', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="enable_animations" value="1" <?php checked($options['enable_animations'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Animations', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Active les animations et transitions fluides', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Textes personnalisables -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zM7 8H5v2h2V8zm2 0h2v2H9V8zm6 0h-2v2h2V8z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Textes Personnalisables', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-settings-section">
                                <div class="cvp-setting-group">
                                    <label for="header_title" class="cvp-setting-label"><?php _e('Titre Principal', 'compositeur-visuel-pro'); ?></label>
                                    <input type="text" id="header_title" name="header_title" class="cvp-input" value="<?php echo esc_attr($options['header_title'] ?? 'Créez votre composition visuelle'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Titre affiché en haut du compositeur', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="header_subtitle" class="cvp-setting-label"><?php _e('Sous-titre', 'compositeur-visuel-pro'); ?></label>
                                    <input type="text" id="header_subtitle" name="header_subtitle" class="cvp-input" value="<?php echo esc_attr($options['header_subtitle'] ?? 'Glissez, ajustez et téléchargez votre création'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Sous-titre descriptif', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="upload_text" class="cvp-setting-label"><?php _e('Texte Zone Upload', 'compositeur-visuel-pro'); ?></label>
                                    <input type="text" id="upload_text" name="upload_text" class="cvp-input" value="<?php echo esc_attr($options['upload_text'] ?? 'Glissez vos images ici ou cliquez pour parcourir'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Texte affiché dans la zone d\'upload', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="download_text" class="cvp-setting-label"><?php _e('Texte Bouton Téléchargement', 'compositeur-visuel-pro'); ?></label>
                                    <input type="text" id="download_text" name="download_text" class="cvp-input" value="<?php echo esc_attr($options['download_text'] ?? 'Télécharger votre création'); ?>">
                                    <p class="cvp-setting-description"><?php _e('Texte du bouton de téléchargement', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Paramètres avancés -->
                    <div class="cvp-admin-card">
                        <div class="cvp-card-header">
                            <h2 class="cvp-card-title">
                                <svg class="cvp-card-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M3 3a1 1 0 000 2v8a2 2 0 002 2h2.586l-1.293 1.293a1 1 0 101.414 1.414L10 15.414l2.293 2.293a1 1 0 001.414-1.414L12.414 15H15a2 2 0 002-2V5a1 1 0 100-2H3zm11.707 4.707a1 1 0 00-1.414-1.414L10 9.586 8.707 8.293a1 1 0 00-1.414 0l-2 2a1 1 0 101.414 1.414L8 10.414l1.293 1.293a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                </svg>
                                <?php _e('Paramètres Avancés', 'compositeur-visuel-pro'); ?>
                            </h2>
                        </div>
                        <div class="cvp-card-content">
                            <div class="cvp-settings-section">
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="auto_save" value="1" <?php checked($options['auto_save'] ?? true); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Sauvegarde Automatique', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Sauvegarde automatiquement les compositions en cours', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="show_grid" value="1" <?php checked($options['show_grid'] ?? false); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Afficher la Grille', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Affiche une grille d\'aide au positionnement', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label class="cvp-checkbox-label">
                                        <input type="checkbox" name="snap_to_grid" value="1" <?php checked($options['snap_to_grid'] ?? false); ?>>
                                        <span class="cvp-checkbox-custom"></span>
                                        <?php _e('Aimantation à la Grille', 'compositeur-visuel-pro'); ?>
                                    </label>
                                    <p class="cvp-setting-description"><?php _e('Les éléments s\'aimantent automatiquement à la grille', 'compositeur-visuel-pro'); ?></p>
                                </div>
                                
                                <div class="cvp-setting-group">
                                    <label for="grid_size" class="cvp-setting-label"><?php _e('Taille de la Grille (px)', 'compositeur-visuel-pro'); ?></label>
                                    <input type="number" id="grid_size" name="grid_size" class="cvp-input" value="<?php echo esc_attr($options['grid_size'] ?? 20); ?>" min="5" max="50">
                                    <p class="cvp-setting-description"><?php _e('Espacement entre les lignes de la grille', 'compositeur-visuel-pro'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="cvp-settings-footer">
                    <button type="submit" name="submit" class="cvp-btn cvp-btn-primary cvp-btn-large">
                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Sauvegarder les Paramètres', 'compositeur-visuel-pro'); ?>
                    </button>
                    
                    <button type="button" class="cvp-btn cvp-btn-secondary" onclick="resetToDefaults()">
                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Réinitialiser', 'compositeur-visuel-pro'); ?>
                    </button>
                </div>
            </form>
        </div>
        
        <script>
        // Mise à jour en temps réel de la valeur du range
        document.getElementById('compression_quality').addEventListener('input', function() {
            document.querySelector('.cvp-range-value').textContent = this.value + '%';
        });
        
        function resetToDefaults() {
            if (confirm('<?php _e('Êtes-vous sûr de vouloir réinitialiser tous les paramètres aux valeurs par défaut ?', 'compositeur-visuel-pro'); ?>')) {
                // Réinitialiser les valeurs par défaut
                document.getElementById('canvas_width').value = '800';
                document.getElementById('canvas_height').value = '600';
                document.getElementById('max_upload_size').value = '10';
                document.getElementById('compression_quality').value = '85';
                document.querySelector('.cvp-range-value').textContent = '85%';
                document.getElementById('primary_color').value = '#667eea';
                document.getElementById('secondary_color').value = '#764ba2';
                document.getElementById('accent_color').value = '#f093fb';
                document.getElementById('header_title').value = 'Créez votre composition visuelle';
                document.getElementById('header_subtitle').value = 'Glissez, ajustez et téléchargez votre création';
                document.getElementById('upload_text').value = 'Glissez vos images ici ou cliquez pour parcourir';
                document.getElementById('download_text').value = 'Télécharger votre création';
                document.getElementById('grid_size').value = '20';
                
                // Réinitialiser les checkboxes
                const checkboxes = document.querySelectorAll('input[type="checkbox"]');
                checkboxes.forEach(checkbox => {
                    if (['inherit_theme_colors', 'inherit_theme_fonts', 'inherit_theme_spacing', 'enable_drag_drop', 'enable_opacity_control', 'enable_rotation', 'enable_resize', 'enable_animations', 'auto_save'].includes(checkbox.name)) {
                        checkbox.checked = true;
                    } else {
                        checkbox.checked = false;
                    }
                });
            }
        }
        </script>
        <?php
    }
    
    /**
     * Sanitiser les paramètres
     */
    private function sanitize_settings($input) {
        $sanitized = array();
        
        // Dimensions et nombres
        $sanitized['canvas_width'] = intval($input['canvas_width'] ?? 800);
        $sanitized['canvas_height'] = intval($input['canvas_height'] ?? 600);
        $sanitized['max_upload_size'] = intval($input['max_upload_size'] ?? 10);
        $sanitized['compression_quality'] = intval($input['compression_quality'] ?? 85);
        $sanitized['grid_size'] = intval($input['grid_size'] ?? 20);
        
        // Couleurs
        $sanitized['primary_color'] = sanitize_hex_color($input['primary_color'] ?? '#667eea');
        $sanitized['secondary_color'] = sanitize_hex_color($input['secondary_color'] ?? '#764ba2');
        $sanitized['accent_color'] = sanitize_hex_color($input['accent_color'] ?? '#f093fb');
        
        // Textes
        $sanitized['header_title'] = sanitize_text_field($input['header_title'] ?? 'Créez votre composition visuelle');
        $sanitized['header_subtitle'] = sanitize_text_field($input['header_subtitle'] ?? 'Glissez, ajustez et téléchargez votre création');
        $sanitized['upload_text'] = sanitize_text_field($input['upload_text'] ?? 'Glissez vos images ici ou cliquez pour parcourir');
        $sanitized['download_text'] = sanitize_text_field($input['download_text'] ?? 'Télécharger votre création');
        
        // Booléens
        $sanitized['inherit_theme_colors'] = !empty($input['inherit_theme_colors']);
        $sanitized['inherit_theme_fonts'] = !empty($input['inherit_theme_fonts']);
        $sanitized['inherit_theme_spacing'] = !empty($input['inherit_theme_spacing']);
        $sanitized['enable_drag_drop'] = !empty($input['enable_drag_drop']);
        $sanitized['enable_opacity_control'] = !empty($input['enable_opacity_control']);
        $sanitized['enable_rotation'] = !empty($input['enable_rotation']);
        $sanitized['enable_resize'] = !empty($input['enable_resize']);
        $sanitized['enable_animations'] = !empty($input['enable_animations']);
        $sanitized['auto_save'] = !empty($input['auto_save']);
        $sanitized['show_grid'] = !empty($input['show_grid']);
        $sanitized['snap_to_grid'] = !empty($input['snap_to_grid']);
        
        // Conserver les autres options existantes
        $existing_options = get_option('cvp_options', array());
        $sanitized = array_merge($existing_options, $sanitized);
        
        return $sanitized;
    }

}



