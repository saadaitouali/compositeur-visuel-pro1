<?php
/**
 * Gestionnaire de base de données pour le Compositeur Visuel Pro
 * Création et gestion des tables personnalisées
 */

if (!defined('ABSPATH')) {
    exit;
}

class CVP_Database {
    
    /**
     * Version de la base de données
     */
    const DB_VERSION = '1.0.0';
    
    /**
     * Instance unique
     */
    private static $instance = null;
    
    /**
     * Obtenir l'instance unique
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructeur
     */
    private function __construct() {
        // Hook d'activation du plugin
        register_activation_hook(CVP_PLUGIN_FILE, array($this, 'create_tables'));
        
        // Hook de mise à jour
        add_action('plugins_loaded', array($this, 'check_database_version'));
    }
    
    /**
     * Créer les tables de la base de données
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Table des images
        $table_images = $wpdb->prefix . 'cvp_images';
        
        $sql_images = "CREATE TABLE $table_images (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            filename varchar(255) NOT NULL,
            original_name varchar(255) NOT NULL,
            file_path text NOT NULL,
            file_url text NOT NULL,
            file_size bigint(20) unsigned NOT NULL DEFAULT 0,
            mime_type varchar(100) NOT NULL,
            image_type enum('background', 'overlay') NOT NULL DEFAULT 'overlay',
            category varchar(100) NOT NULL DEFAULT 'general',
            alt_text text,
            description text,
            tags text,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            sort_order int(11) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_image_type (image_type),
            KEY idx_category (category),
            KEY idx_is_active (is_active),
            KEY idx_created_at (created_at),
            KEY idx_sort_order (sort_order)
        ) $charset_collate;";
        
        // Table des compositions sauvegardées
        $table_compositions = $wpdb->prefix . 'cvp_compositions';
        
        $sql_compositions = "CREATE TABLE $table_compositions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL,
            description text,
            composition_data longtext NOT NULL,
            canvas_width int(11) NOT NULL DEFAULT 800,
            canvas_height int(11) NOT NULL DEFAULT 600,
            preview_url text,
            is_public tinyint(1) NOT NULL DEFAULT 0,
            view_count bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_user_id (user_id),
            KEY idx_is_public (is_public),
            KEY idx_created_at (created_at),
            KEY idx_view_count (view_count)
        ) $charset_collate;";
        
        // Table des catégories personnalisées
        $table_categories = $wpdb->prefix . 'cvp_categories';
        
        $sql_categories = "CREATE TABLE $table_categories (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            slug varchar(100) NOT NULL,
            description text,
            color varchar(7) DEFAULT '#667eea',
            icon varchar(50),
            image_type enum('background', 'overlay', 'both') NOT NULL DEFAULT 'both',
            sort_order int(11) NOT NULL DEFAULT 0,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY idx_slug (slug),
            KEY idx_image_type (image_type),
            KEY idx_is_active (is_active),
            KEY idx_sort_order (sort_order)
        ) $charset_collate;";
        
        // Table des statistiques d'utilisation
        $table_stats = $wpdb->prefix . 'cvp_usage_stats';
        
        $sql_stats = "CREATE TABLE $table_stats (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            action_type varchar(50) NOT NULL,
            action_data text,
            ip_address varchar(45),
            user_agent text,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_user_id (user_id),
            KEY idx_action_type (action_type),
            KEY idx_created_at (created_at),
            KEY idx_ip_address (ip_address)
        ) $charset_collate;";
        
        // Inclure le fichier de mise à niveau de WordPress
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        // Créer les tables
        dbDelta($sql_images);
        dbDelta($sql_compositions);
        dbDelta($sql_categories);
        dbDelta($sql_stats);
        
        // Insérer les catégories par défaut
        $this->insert_default_categories();
        
        // Mettre à jour la version de la base de données
        update_option('cvp_db_version', self::DB_VERSION);
        
        // Créer les dossiers d'upload
        $this->create_upload_directories();
        
        // Programmer les tâches cron
        $this->schedule_cron_jobs();
    }
    
    /**
     * Vérifier la version de la base de données
     */
    public function check_database_version() {
        $installed_version = get_option('cvp_db_version', '0.0.0');
        
        if (version_compare($installed_version, self::DB_VERSION, '<')) {
            $this->upgrade_database($installed_version);
        }
    }
    
    /**
     * Mettre à niveau la base de données
     */
    private function upgrade_database($from_version) {
        global $wpdb;
        
        // Migrations basées sur la version
        if (version_compare($from_version, '1.0.0', '<')) {
            // Première installation ou mise à niveau majeure
            $this->create_tables();
        }
        
        // Ajouter d'autres migrations ici pour les futures versions
        
        // Mettre à jour la version
        update_option('cvp_db_version', self::DB_VERSION);
    }
    
    /**
     * Insérer les catégories par défaut
     */
    private function insert_default_categories() {
        global $wpdb;
        
        $table_categories = $wpdb->prefix . 'cvp_categories';
        
        // Vérifier si des catégories existent déjà
        $existing_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_categories");
        
        if ($existing_count > 0) {
            return; // Les catégories existent déjà
        }
        
        $default_categories = array(
            array(
                'name' => __('Général', 'compositeur-visuel-pro'),
                'slug' => 'general',
                'description' => __('Catégorie générale pour tous types d\'images', 'compositeur-visuel-pro'),
                'color' => '#667eea',
                'icon' => 'folder',
                'image_type' => 'both',
                'sort_order' => 1
            ),
            array(
                'name' => __('Nature', 'compositeur-visuel-pro'),
                'slug' => 'nature',
                'description' => __('Images de paysages, animaux et nature', 'compositeur-visuel-pro'),
                'color' => '#48bb78',
                'icon' => 'tree',
                'image_type' => 'background',
                'sort_order' => 2
            ),
            array(
                'name' => __('Business', 'compositeur-visuel-pro'),
                'slug' => 'business',
                'description' => __('Images professionnelles et business', 'compositeur-visuel-pro'),
                'color' => '#4299e1',
                'icon' => 'briefcase',
                'image_type' => 'background',
                'sort_order' => 3
            ),
            array(
                'name' => __('Abstrait', 'compositeur-visuel-pro'),
                'slug' => 'abstract',
                'description' => __('Formes et motifs abstraits', 'compositeur-visuel-pro'),
                'color' => '#ed8936',
                'icon' => 'palette',
                'image_type' => 'both',
                'sort_order' => 4
            ),
            array(
                'name' => __('Logos', 'compositeur-visuel-pro'),
                'slug' => 'logos',
                'description' => __('Logos et éléments de marque', 'compositeur-visuel-pro'),
                'color' => '#f093fb',
                'icon' => 'star',
                'image_type' => 'overlay',
                'sort_order' => 5
            ),
            array(
                'name' => __('Textures', 'compositeur-visuel-pro'),
                'slug' => 'textures',
                'description' => __('Textures et motifs de fond', 'compositeur-visuel-pro'),
                'color' => '#764ba2',
                'icon' => 'grid',
                'image_type' => 'background',
                'sort_order' => 6
            ),
            array(
                'name' => __('Icônes', 'compositeur-visuel-pro'),
                'slug' => 'icons',
                'description' => __('Icônes et symboles', 'compositeur-visuel-pro'),
                'color' => '#f56565',
                'icon' => 'heart',
                'image_type' => 'overlay',
                'sort_order' => 7
            )
        );
        
        foreach ($default_categories as $category) {
            $wpdb->insert(
                $table_categories,
                $category,
                array('%s', '%s', '%s', '%s', '%s', '%s', '%d')
            );
        }
    }
    
    /**
     * Créer les dossiers d'upload
     */
    private function create_upload_directories() {
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/compositeur-visuel-pro';
        
        $directories = array(
            $base_dir,
            $base_dir . '/backgrounds',
            $base_dir . '/overlays',
            $base_dir . '/temp',
            $base_dir . '/exports'
        );
        
        foreach ($directories as $dir) {
            if (!file_exists($dir)) {
                wp_mkdir_p($dir);
                
                // Créer un fichier .htaccess pour la sécurité
                $htaccess_content = "Options -Indexes\n";
                $htaccess_content .= "<Files *.php>\n";
                $htaccess_content .= "deny from all\n";
                $htaccess_content .= "</Files>\n";
                
                file_put_contents($dir . '/.htaccess', $htaccess_content);
                
                // Créer un fichier index.php vide
                file_put_contents($dir . '/index.php', '<?php // Silence is golden');
            }
        }
    }
    
    /**
     * Programmer les tâches cron
     */
    private function schedule_cron_jobs() {
        // Nettoyage quotidien des fichiers temporaires
        if (!wp_next_scheduled('cvp_cleanup_temp_files')) {
            wp_schedule_event(time(), 'daily', 'cvp_cleanup_temp_files');
        }
        
        // Nettoyage hebdomadaire des fichiers orphelins
        if (!wp_next_scheduled('cvp_cleanup_orphaned_files')) {
            wp_schedule_event(time(), 'weekly', 'cvp_cleanup_orphaned_files');
        }
        
        // Optimisation mensuelle de la base de données
        if (!wp_next_scheduled('cvp_optimize_database')) {
            wp_schedule_event(time(), 'monthly', 'cvp_optimize_database');
        }
    }
    
    /**
     * Supprimer les tables lors de la désinstallation
     */
    public static function drop_tables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'cvp_images',
            $wpdb->prefix . 'cvp_compositions',
            $wpdb->prefix . 'cvp_categories',
            $wpdb->prefix . 'cvp_usage_stats'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        // Supprimer les options
        delete_option('cvp_db_version');
        delete_option('cvp_options');
        
        // Supprimer les tâches cron
        wp_clear_scheduled_hook('cvp_cleanup_temp_files');
        wp_clear_scheduled_hook('cvp_cleanup_orphaned_files');
        wp_clear_scheduled_hook('cvp_optimize_database');
    }
    
    /**
     * Nettoyer les fichiers temporaires
     */
    public static function cleanup_temp_files() {
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/compositeur-visuel-pro/temp';
        
        if (!is_dir($temp_dir)) {
            return;
        }
        
        $files = glob($temp_dir . '/*');
        $deleted_count = 0;
        
        foreach ($files as $file) {
            if (is_file($file)) {
                // Supprimer les fichiers de plus de 24 heures
                if (filemtime($file) < (time() - 24 * 3600)) {
                    if (unlink($file)) {
                        $deleted_count++;
                    }
                }
            }
        }
        
        if ($deleted_count > 0) {
            error_log("CVP: Nettoyage automatique - {$deleted_count} fichier(s) temporaire(s) supprimé(s)");
        }
    }
    
    /**
     * Optimiser la base de données
     */
    public static function optimize_database() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'cvp_images',
            $wpdb->prefix . 'cvp_compositions',
            $wpdb->prefix . 'cvp_categories',
            $wpdb->prefix . 'cvp_usage_stats'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("OPTIMIZE TABLE $table");
        }
        
        // Nettoyer les anciennes statistiques (plus de 6 mois)
        $stats_table = $wpdb->prefix . 'cvp_usage_stats';
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM $stats_table WHERE created_at < %s",
            date('Y-m-d H:i:s', strtotime('-6 months'))
        ));
        
        if ($deleted > 0) {
            error_log("CVP: Optimisation - {$deleted} ancienne(s) statistique(s) supprimée(s)");
        }
    }
    
    /**
     * Obtenir les informations de la base de données
     */
    public function get_database_info() {
        global $wpdb;
        
        $info = array(
            'version' => get_option('cvp_db_version', '0.0.0'),
            'tables' => array()
        );
        
        $tables = array(
            'images' => $wpdb->prefix . 'cvp_images',
            'compositions' => $wpdb->prefix . 'cvp_compositions',
            'categories' => $wpdb->prefix . 'cvp_categories',
            'stats' => $wpdb->prefix . 'cvp_usage_stats'
        );
        
        foreach ($tables as $key => $table) {
            $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
            $size = $wpdb->get_var("SELECT ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'size' FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name = '$table'");
            
            $info['tables'][$key] = array(
                'name' => $table,
                'count' => intval($count),
                'size' => floatval($size) . ' MB'
            );
        }
        
        return $info;
    }
    
    /**
     * Vérifier l'intégrité de la base de données
     */
    public function check_database_integrity() {
        global $wpdb;
        
        $issues = array();
        
        // Vérifier l'existence des tables
        $required_tables = array(
            $wpdb->prefix . 'cvp_images',
            $wpdb->prefix . 'cvp_compositions',
            $wpdb->prefix . 'cvp_categories',
            $wpdb->prefix . 'cvp_usage_stats'
        );
        
        foreach ($required_tables as $table) {
            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
            if (!$exists) {
                $issues[] = sprintf(__('Table manquante: %s', 'compositeur-visuel-pro'), $table);
            }
        }
        
        // Vérifier les fichiers orphelins
        $images_table = $wpdb->prefix . 'cvp_images';
        $images = $wpdb->get_results("SELECT file_path FROM $images_table");
        
        $missing_files = 0;
        foreach ($images as $image) {
            if (!file_exists($image->file_path)) {
                $missing_files++;
            }
        }
        
        if ($missing_files > 0) {
            $issues[] = sprintf(__('%d fichier(s) image(s) manquant(s)', 'compositeur-visuel-pro'), $missing_files);
        }
        
        return $issues;
    }
    
    /**
     * Réparer la base de données
     */
    public function repair_database() {
        global $wpdb;
        
        $repaired = array();
        
        // Recréer les tables manquantes
        $this->create_tables();
        $repaired[] = __('Tables vérifiées et créées si nécessaire', 'compositeur-visuel-pro');
        
        // Nettoyer les entrées avec des fichiers manquants
        $images_table = $wpdb->prefix . 'cvp_images';
        $images = $wpdb->get_results("SELECT id, file_path FROM $images_table");
        
        $deleted_entries = 0;
        foreach ($images as $image) {
            if (!file_exists($image->file_path)) {
                $wpdb->delete($images_table, array('id' => $image->id), array('%d'));
                $deleted_entries++;
            }
        }
        
        if ($deleted_entries > 0) {
            $repaired[] = sprintf(__('%d entrée(s) avec fichier(s) manquant(s) supprimée(s)', 'compositeur-visuel-pro'), $deleted_entries);
        }
        
        // Optimiser les tables
        self::optimize_database();
        $repaired[] = __('Tables optimisées', 'compositeur-visuel-pro');
        
        return $repaired;
    }
}

