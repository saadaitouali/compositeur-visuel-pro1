<?php
/**
 * Classe Frontend du Compositeur Visuel Pro
 * Gère l'affichage frontend et les interactions JavaScript
 */

if (!defined('ABSPATH')) {
    exit;
}

class CVP_Frontend {
    
    /**
     * Instance unique
     */
    private static $instance = null;
    
    /**
     * Obtenir l'instance unique
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructeur
     */
    private function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Initialiser les hooks
     */
    private function init_hooks() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_cvp_get_images', array($this, 'handle_get_images'));
        add_action('wp_ajax_nopriv_cvp_get_images', array($this, 'handle_get_images'));
        add_action('wp_ajax_cvp_upload_image', array($this, 'handle_frontend_upload'));
        add_action('wp_ajax_nopriv_cvp_upload_image', array($this, 'handle_frontend_upload'));
        add_action('wp_ajax_cvp_save_composition', array($this, 'handle_save_composition'));
        add_action('wp_ajax_nopriv_cvp_save_composition', array($this, 'handle_save_composition'));
    }
    
    /**
     * Enqueue les scripts et styles frontend
     */
    public function enqueue_scripts() {
        // Enqueue CSS
        wp_enqueue_style('cvp-frontend-styles', CVP_PLUGIN_URL . 'assets/css/frontend.css', array(), CVP_VERSION, 'all');
        
        // Enqueue JS
        wp_enqueue_script('jquery'); // Dépendance jQuery
        wp_enqueue_script('jquery-ui-draggable'); // Pour le glisser-déposer
        
        // html2canvas pour la capture d'écran du canvas
        wp_enqueue_script('html2canvas', 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js', array(), '1.4.1', true);
        
        wp_enqueue_script('cvp-frontend-script', CVP_PLUGIN_URL . 'assets/js/frontend.js', array('jquery', 'jquery-ui-draggable', 'html2canvas'), CVP_VERSION, true);
        
        // Localiser les scripts avec les données nécessaires
        wp_localize_script('cvp-frontend-script', 'cvpFrontend', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cvp_frontend_nonce'),
            'strings' => array(
                'uploadError' => __('Erreur lors de l\'upload', 'compositeur-visuel-pro'),
                'fileTooBig' => __('Fichier trop volumineux', 'compositeur-visuel-pro'),
                'invalidType' => __('Type de fichier non supporté', 'compositeur-visuel-pro'),
                'uploadSuccess' => __('Image uploadée avec succès', 'compositeur-visuel-pro'),
                'downloadSuccess' => __('Image téléchargée avec succès', 'compositeur-visuel-pro'),
                'resetConfirm' => __('Êtes-vous sûr de vouloir tout réinitialiser ?', 'compositeur-visuel-pro'),
                'elementDeleted' => __('Élément supprimé', 'compositeur-visuel-pro'),
                'undoAction' => __('Action annulée', 'compositeur-visuel-pro'),
                'redoAction' => __('Action refaite', 'compositeur-visuel-pro')
            )
        ));
    }
    
    /**
     * Rendre le compositeur visuel (shortcode)
     */
    public function render_composer($atts) {
        // Fusionner avec les attributs par défaut
        $atts = shortcode_atts(array(
            'width' => 800,
            'height' => 600,
            'theme' => 'inherit',
            'enable_upload' => 'true',
            'enable_grid' => 'false',
            'max_file_size' => '10',
            'allowed_types' => 'jpeg,jpg,png,gif,webp',
            'container_class' => '',
            'canvas_class' => ''
        ), $atts);
        
        // Générer un ID unique pour cette instance
        $instance_id = 'cvp-composer-' . uniqid();
        
        // Préparer les options JavaScript
        $js_options = array(
            'canvasWidth' => intval($atts['width']),
            'canvasHeight' => intval($atts['height']),
            'enableUpload' => $atts['enable_upload'] === 'true',
            'enableGrid' => $atts['enable_grid'] === 'true',
            'maxFileSize' => intval($atts['max_file_size']) * 1024 * 1024,
            'allowedTypes' => array_map('trim', explode(',', $atts['allowed_types'])),
            'theme' => $atts['theme']
        );
        
        // Classes CSS pour le container
        $container_classes = array('cvp-container');
        
        if ($atts['theme'] === 'inherit') {
            $container_classes[] = 'cvp-theme-inherit';
        } elseif ($atts['theme'] === 'dark') {
            $container_classes[] = 'cvp-theme-dark';
        } else {
            $container_classes[] = 'cvp-theme-light';
        }
        
        if (!empty($atts['container_class'])) {
            $container_classes[] = sanitize_html_class($atts['container_class']);
        }
        
        // Classes CSS pour le canvas
        $canvas_classes = array('cvp-canvas');
        if (!empty($atts['canvas_class'])) {
            $canvas_classes[] = sanitize_html_class($atts['canvas_class']);
        }
        
        // Récupérer les images par défaut depuis la base de données
        $image_manager = CVP_Image_Manager::get_instance();
        $background_images = $image_manager->get_frontend_images('background');
        $overlay_images = $image_manager->get_frontend_images('overlay');
        
        ob_start();
        ?>
        <div id="<?php echo esc_attr($instance_id); ?>" 
             class="<?php echo esc_attr(implode(' ', $container_classes)); ?>"
             data-options="<?php echo esc_attr(json_encode($js_options)); ?>">
            
            <!-- Container de messages -->
            <div class="cvp-message-container"></div>
            
            <!-- En-tête avec héritage du thème -->
            <div class="cvp-header">
                <h2 class="cvp-header-title"><?php _e('Compositeur Visuel', 'compositeur-visuel-pro'); ?></h2>
                <p class="cvp-header-subtitle"><?php _e('Créez vos compositions visuelles en quelques clics', 'compositeur-visuel-pro'); ?></p>
            </div>
            
            <!-- Contenu principal -->
            <div class="cvp-main-content">
                <!-- Panneau de contrôles -->
                <div class="cvp-controls-panel">
                    <div class="cvp-panel-header">
                        <h3 class="cvp-panel-title">
                            <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M3 4a1 1 0 011-1h4a1 1 0 010 2H6.414l2.293 2.293a1 1 0 11-1.414 1.414L5 6.414V8a1 1 0 01-2 0V4zm9 1a1 1 0 010-2h4a1 1 0 011 1v4a1 1 0 01-2 0V6.414l-2.293 2.293a1 1 0 11-1.414-1.414L13.586 5H12zm-9 7a1 1 0 012 0v1.586l2.293-2.293a1 1 0 111.414 1.414L6.414 15H8a1 1 0 010 2H4a1 1 0 01-1-1v-4zm13-1a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 010-2h1.586l-2.293-2.293a1 1 0 111.414-1.414L15 13.586V12a1 1 0 011-1z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Contrôles', 'compositeur-visuel-pro'); ?>
                        </h3>
                    </div>
                    
                    <div class="cvp-panel-content">
                        <?php if ($atts['enable_upload'] === 'true'): ?>
                        <!-- Section Upload -->
                        <div class="cvp-control-section">
                            <h4 class="cvp-section-title"><?php _e('Ajouter une Image', 'compositeur-visuel-pro'); ?></h4>
                            <div class="cvp-upload-area" id="cvp-upload-area">
                                <div class="cvp-upload-dropzone">
                                    <svg class="cvp-upload-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                    </svg>
                                    <p class="cvp-upload-text"><?php _e('Glissez vos images ici', 'compositeur-visuel-pro'); ?></p>
                                    <p class="cvp-upload-hint"><?php _e('ou cliquez pour parcourir', 'compositeur-visuel-pro'); ?></p>
                                    <input type="file" id="cvp-file-input" accept="image/*" multiple style="display: none;">
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Section Images par défaut -->
                        <?php if (!empty($background_images) || !empty($overlay_images)): ?>
                        <div class="cvp-control-section">
                            <h4 class="cvp-section-title"><?php _e('Images Disponibles', 'compositeur-visuel-pro'); ?></h4>
                            
                            <?php if (!empty($background_images)): ?>
                            <div class="cvp-image-category">
                                <h5 class="cvp-category-title"><?php _e('Arrière-plans', 'compositeur-visuel-pro'); ?></h5>
                                <div class="cvp-image-grid">
                                    <?php foreach ($background_images as $image): ?>
                                    <div class="cvp-image-item" data-type="background" data-url="<?php echo esc_url($image->file_url); ?>">
                                        <img src="<?php echo esc_url($image->file_url); ?>" alt="<?php echo esc_attr($image->alt_text); ?>" loading="lazy">
                                        <div class="cvp-image-overlay">
                                            <button class="cvp-add-image-btn" title="<?php _e('Ajouter au canvas', 'compositeur-visuel-pro'); ?>">
                                                <svg fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($overlay_images)): ?>
                            <div class="cvp-image-category">
                                <h5 class="cvp-category-title"><?php _e('Éléments', 'compositeur-visuel-pro'); ?></h5>
                                <div class="cvp-image-grid">
                                    <?php foreach ($overlay_images as $image): ?>
                                    <div class="cvp-image-item" data-type="overlay" data-url="<?php echo esc_url($image->file_url); ?>">
                                        <img src="<?php echo esc_url($image->file_url); ?>" alt="<?php echo esc_attr($image->alt_text); ?>" loading="lazy">
                                        <div class="cvp-image-overlay">
                                            <button class="cvp-add-image-btn" title="<?php _e('Ajouter au canvas', 'compositeur-visuel-pro'); ?>">
                                                <svg fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Section Contrôles d'élément -->
                        <div class="cvp-control-section" id="cvp-element-controls" style="display: none;">
                            <h4 class="cvp-section-title"><?php _e('Contrôles de l\'Élément', 'compositeur-visuel-pro'); ?></h4>
                            
                            <!-- Opacité -->
                            <div class="cvp-control-group">
                                <label for="cvp-opacity-slider"><?php _e('Opacité', 'compositeur-visuel-pro'); ?></label>
                                <input type="range" id="cvp-opacity-slider" min="0" max="100" value="100" class="cvp-slider">
                                <span class="cvp-slider-value">100%</span>
                            </div>
                            
                            <!-- Rotation -->
                            <div class="cvp-control-group">
                                <label for="cvp-rotation-slider"><?php _e('Rotation', 'compositeur-visuel-pro'); ?></label>
                                <input type="range" id="cvp-rotation-slider" min="0" max="360" value="0" class="cvp-slider">
                                <span class="cvp-slider-value">0°</span>
                            </div>
                            
                            <!-- Taille -->
                            <div class="cvp-control-group">
                                <label for="cvp-scale-slider"><?php _e('Taille', 'compositeur-visuel-pro'); ?></label>
                                <input type="range" id="cvp-scale-slider" min="10" max="200" value="100" class="cvp-slider">
                                <span class="cvp-slider-value">100%</span>
                            </div>
                            
                            <!-- Position -->
                            <div class="cvp-control-group">
                                <label><?php _e('Position', 'compositeur-visuel-pro'); ?></label>
                                <div class="cvp-position-controls">
                                    <div class="cvp-input-group">
                                        <label for="cvp-pos-x">X:</label>
                                        <input type="number" id="cvp-pos-x" min="0" value="0" class="cvp-number-input">
                                    </div>
                                    <div class="cvp-input-group">
                                        <label for="cvp-pos-y">Y:</label>
                                        <input type="number" id="cvp-pos-y" min="0" value="0" class="cvp-number-input">
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Actions -->
                            <div class="cvp-control-group">
                                <div class="cvp-action-buttons">
                                    <button id="cvp-delete-element" class="cvp-btn cvp-btn-danger">
                                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                        </svg>
                                        <?php _e('Supprimer', 'compositeur-visuel-pro'); ?>
                                    </button>
                                    <button id="cvp-duplicate-element" class="cvp-btn cvp-btn-secondary">
                                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z"/>
                                            <path d="M5 3a2 2 0 00-2 2v6a2 2 0 002 2V5h8a2 2 0 00-2-2H5z"/>
                                        </svg>
                                        <?php _e('Dupliquer', 'compositeur-visuel-pro'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Section Actions générales -->
                        <div class="cvp-control-section">
                            <h4 class="cvp-section-title"><?php _e('Actions', 'compositeur-visuel-pro'); ?></h4>
                            <div class="cvp-action-buttons">
                                <button id="cvp-undo-btn" class="cvp-btn cvp-btn-secondary" disabled>
                                    <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Annuler', 'compositeur-visuel-pro'); ?>
                                </button>
                                <button id="cvp-redo-btn" class="cvp-btn cvp-btn-secondary" disabled>
                                    <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Refaire', 'compositeur-visuel-pro'); ?>
                                </button>
                                <button id="cvp-reset-btn" class="cvp-btn cvp-btn-warning">
                                    <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Réinitialiser', 'compositeur-visuel-pro'); ?>
                                </button>
                                <button id="cvp-download-btn" class="cvp-btn cvp-btn-primary">
                                    <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                    </svg>
                                    <?php _e('Télécharger', 'compositeur-visuel-pro'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Canvas principal -->
                <div class="cvp-canvas-container">
                    <div class="<?php echo esc_attr(implode(' ', $canvas_classes)); ?>" 
                         id="cvp-canvas"
                         style="width: <?php echo intval($atts['width']); ?>px; height: <?php echo intval($atts['height']); ?>px;">
                        
                        <!-- Grille optionnelle -->
                        <?php if ($atts['enable_grid'] === 'true'): ?>
                        <div class="cvp-grid" id="cvp-grid"></div>
                        <?php endif; ?>
                        
                        <!-- Zone de drop pour les images -->
                        <div class="cvp-canvas-dropzone">
                            <div class="cvp-dropzone-content">
                                <svg class="cvp-dropzone-icon" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                                </svg>
                                <p class="cvp-dropzone-text"><?php _e('Glissez vos images ici pour commencer', 'compositeur-visuel-pro'); ?></p>
                            </div>
                        </div>
                        
                        <!-- Les éléments seront ajoutés ici dynamiquement -->
                    </div>
                    
                    <!-- Informations du canvas -->
                    <div class="cvp-canvas-info">
                        <span class="cvp-canvas-dimensions"><?php echo intval($atts['width']); ?> × <?php echo intval($atts['height']); ?>px</span>
                        <span class="cvp-canvas-elements">0 <?php _e('éléments', 'compositeur-visuel-pro'); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        // Initialiser le compositeur pour cette instance
        jQuery(document).ready(function($) {
            if (typeof CVPComposer !== 'undefined') {
                new CVPComposer('<?php echo esc_js($instance_id); ?>');
            }
        });
        </script>
        <?php
        
        return ob_get_clean();
    }
    
    /**
     * Gérer la requête AJAX pour obtenir les images (frontend)
     */
    public function handle_get_images() {
        // Pas de vérification de nonce pour cette action car elle est publique
        // if (!wp_verify_nonce($_POST['nonce'], 'cvp_frontend_nonce')) {
        //     wp_send_json_error('Nonce invalide');
        // }
        
        $image_manager = CVP_Image_Manager::get_instance();
        $backgrounds = $image_manager->get_frontend_images('background');
        $overlays = $image_manager->get_frontend_images('overlay');
        
        if (empty($backgrounds) && empty($overlays)) {
            wp_send_json_error('Aucune image disponible');
        } else {
            wp_send_json_success(array(
                'backgrounds' => $backgrounds,
                'overlays' => $overlays
            ));
        }
    }
    
    /**
     * Gérer l'upload d'images depuis le frontend
     */
    public function handle_frontend_upload() {
        if (!wp_verify_nonce($_POST['nonce'], 'cvp_frontend_nonce')) {
            wp_send_json_error('Nonce invalide');
        }
        
        if (!current_user_can('upload_files')) {
            wp_send_json_error('Vous n\'avez pas les permissions pour uploader des fichiers.');
        }
        
        if (empty($_FILES['file'])) {
            wp_send_json_error('Aucun fichier reçu.');
        }
        
        $file = $_FILES['file'];
        $image_type = 'overlay'; // Les uploads frontend sont toujours des overlays
        $category = 'user-upload'; // Catégorie pour les uploads utilisateur
        
        $image_manager = CVP_Image_Manager::get_instance();
        $result = $image_manager->process_uploaded_file($file, $image_type, $category);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success(array(
                'url' => $result['file_url'],
                'id' => $result['id']
            ));
        }
    }
    
    /**
     * Gérer la sauvegarde de composition (frontend)
     */
    public function handle_save_composition() {
        if (!wp_verify_nonce($_POST['nonce'], 'cvp_frontend_nonce')) {
            wp_send_json_error('Nonce invalide');
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Vous devez être connecté pour sauvegarder une composition.');
        }
        
        $composition_data = json_decode(stripslashes($_POST['composition']), true);
        
        if (empty($composition_data)) {
            wp_send_json_error('Données de composition invalides.');
        }
        
        // Ici, vous pouvez sauvegarder la composition dans la base de données
        // Pour l'instant, nous allons juste simuler une sauvegarde
        
        // Exemple de sauvegarde dans la table cvp_compositions
        global $wpdb;
        $table_name = $wpdb->prefix . 'cvp_compositions';
        
        $title = 'Composition du ' . date('Y-m-d H:i:s');
        $user_id = get_current_user_id();
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'title' => $title,
                'composition_data' => json_encode($composition_data),
                'canvas_width' => $composition_data['canvas']['width'] ?? 800,
                'canvas_height' => $composition_data['canvas']['height'] ?? 600,
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%d', '%d', '%s')
        );
        
        if ($result) {
            wp_send_json_success('Composition sauvegardée avec succès !');
        } else {
            wp_send_json_error('Erreur lors de la sauvegarde de la composition.');
        }
    }
}

