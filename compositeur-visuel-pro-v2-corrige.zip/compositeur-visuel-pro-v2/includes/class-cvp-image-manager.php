<?php
/**
 * Gestionnaire d'images pour le Compositeur Visuel Pro
 * Gère l'upload, le stockage et la récupération des images
 */

if (!defined('ABSPATH')) {
    exit;
}

class CVP_Image_Manager {
    
    /**
     * Instance unique
     */
    private static $instance = null;
    
    /**
     * Dossier d'upload
     */
    private $upload_dir;
    
    /**
     * URL d'upload
     */
    private $upload_url;
    
    /**
     * Obtenir l'instance unique
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructeur
     */
    private function __construct() {
        $this->init_upload_dirs();
        $this->init_hooks();
    }
    
    /**
     * Initialiser les dossiers d'upload
     */
    private function init_upload_dirs() {
        $wp_upload_dir = wp_upload_dir();
        $this->upload_dir = $wp_upload_dir['basedir'] . '/compositeur-visuel-pro';
        $this->upload_url = $wp_upload_dir['baseurl'] . '/compositeur-visuel-pro';
        
        // Créer les dossiers si nécessaire
        if (!file_exists($this->upload_dir)) {
            wp_mkdir_p($this->upload_dir);
            wp_mkdir_p($this->upload_dir . '/backgrounds');
            wp_mkdir_p($this->upload_dir . '/overlays');
            wp_mkdir_p($this->upload_dir . '/compositions');
        }
    }
    
    /**
     * Initialiser les hooks
     */
    private function init_hooks() {
        add_action('wp_ajax_cvp_admin_upload', array($this, 'handle_admin_upload'));
        add_action('wp_ajax_cvp_admin_delete', array($this, 'handle_admin_delete'));
        add_action('wp_ajax_cvp_admin_get_images', array($this, 'handle_admin_get_images'));
    }
    
    /**
     * Traiter un fichier uploadé
     */
    public function process_uploaded_file($file, $image_type = 'overlay', $category = 'general') {
        // Vérifications de sécurité
        if (!$this->is_valid_image($file)) {
            return new WP_Error('invalid_file', __('Fichier image invalide', 'compositeur-visuel-pro'));
        }
        
        // Vérifier la taille
        $max_size = cvp_get_option('max_upload_size', 10) * 1024 * 1024; // MB en bytes
        if ($file['size'] > $max_size) {
            return new WP_Error('file_too_large', __('Fichier trop volumineux', 'compositeur-visuel-pro'));
        }
        
        // Générer un nom de fichier unique
        $file_info = pathinfo($file['name']);
        $filename = sanitize_file_name($file_info['filename']) . '_' . uniqid() . '.' . $file_info['extension'];
        
        // Déterminer le dossier de destination
        $subfolder = ($image_type === 'background') ? 'backgrounds' : 'overlays';
        $destination_dir = $this->upload_dir . '/' . $subfolder;
        $destination_path = $destination_dir . '/' . $filename;
        $destination_url = $this->upload_url . '/' . $subfolder . '/' . $filename;
        
        // Créer le dossier si nécessaire
        if (!file_exists($destination_dir)) {
            wp_mkdir_p($destination_dir);
        }
        
        // Déplacer le fichier
        if (!move_uploaded_file($file['tmp_name'], $destination_path)) {
            return new WP_Error('upload_failed', __('Échec de l\'upload du fichier', 'compositeur-visuel-pro'));
        }
        
        // Optimiser l'image si nécessaire
        $this->optimize_image($destination_path);
        
        // Enregistrer en base de données
        $image_data = array(
            'filename' => $filename,
            'original_name' => $file['name'],
            'file_path' => $destination_path,
            'file_url' => $destination_url,
            'file_size' => filesize($destination_path),
            'mime_type' => $file['type'],
            'image_type' => $image_type,
            'category' => $category,
            'alt_text' => sanitize_text_field($file_info['filename'])
        );
        
        $image_id = $this->save_image_to_db($image_data);
        
        if (!$image_id) {
            // Supprimer le fichier en cas d'erreur de base de données
            unlink($destination_path);
            return new WP_Error('db_error', __('Erreur lors de la sauvegarde en base de données', 'compositeur-visuel-pro'));
        }
        
        $image_data['id'] = $image_id;
        return $image_data;
    }
    
    /**
     * Vérifier si le fichier est une image valide
     */
    private function is_valid_image($file) {
        // Vérifier le type MIME
        $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp');
        if (!in_array($file['type'], $allowed_types)) {
            return false;
        }
        
        // Vérifier l'extension
        $file_info = pathinfo($file['name']);
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif', 'webp');
        if (!in_array(strtolower($file_info['extension']), $allowed_extensions)) {
            return false;
        }
        
        // Vérifier que c'est vraiment une image
        $image_info = getimagesize($file['tmp_name']);
        if (!$image_info) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Optimiser une image
     */
    private function optimize_image($file_path) {
        $quality = cvp_get_option('compression_quality', 85);
        $image_info = getimagesize($file_path);
        
        if (!$image_info) {
            return false;
        }
        
        $mime_type = $image_info['mime'];
        
        switch ($mime_type) {
            case 'image/jpeg':
                $image = imagecreatefromjpeg($file_path);
                if ($image) {
                    imagejpeg($image, $file_path, $quality);
                    imagedestroy($image);
                }
                break;
                
            case 'image/png':
                $image = imagecreatefrompng($file_path);
                if ($image) {
                    // PNG utilise un niveau de compression différent (0-9)
                    $png_quality = floor((100 - $quality) / 10);
                    imagepng($image, $file_path, $png_quality);
                    imagedestroy($image);
                }
                break;
                
            case 'image/webp':
                if (function_exists('imagecreatefromwebp')) {
                    $image = imagecreatefromwebp($file_path);
                    if ($image) {
                        imagewebp($image, $file_path, $quality);
                        imagedestroy($image);
                    }
                }
                break;
        }
        
        return true;
    }
    
    /**
     * Sauvegarder les données d'image en base
     */
    private function save_image_to_db($image_data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        $result = $wpdb->insert(
            $table_name,
            $image_data,
            array('%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            return false;
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Récupérer les images pour le frontend
     */
    public function get_frontend_images($type = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        $sql = "SELECT * FROM $table_name";
        $params = array();
        
        if ($type) {
            $sql .= " WHERE image_type = %s";
            $params[] = $type;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        if (!empty($params)) {
            return $wpdb->get_results($wpdb->prepare($sql, $params));
        } else {
            return $wpdb->get_results($sql);
        }
    }
    
    /**
     * Récupérer les images pour l'admin
     */
    public function get_admin_images($type = null, $category = null, $limit = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        $sql = "SELECT * FROM $table_name";
        $where_conditions = array();
        $params = array();
        
        if ($type) {
            $where_conditions[] = "image_type = %s";
            $params[] = $type;
        }
        
        if ($category) {
            $where_conditions[] = "category = %s";
            $params[] = $category;
        }
        
        if (!empty($where_conditions)) {
            $sql .= " WHERE " . implode(' AND ', $where_conditions);
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        if ($limit) {
            $sql .= " LIMIT %d";
            $params[] = $limit;
        }
        
        if (!empty($params)) {
            return $wpdb->get_results($wpdb->prepare($sql, $params));
        } else {
            return $wpdb->get_results($sql);
        }
    }
    
    /**
     * Supprimer une image
     */
    public function delete_image($image_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        // Récupérer les informations de l'image
        $image = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $image_id
        ));
        
        if (!$image) {
            return new WP_Error('image_not_found', __('Image non trouvée', 'compositeur-visuel-pro'));
        }
        
        // Supprimer le fichier physique
        if (file_exists($image->file_path)) {
            unlink($image->file_path);
        }
        
        // Supprimer de la base de données
        $result = $wpdb->delete(
            $table_name,
            array('id' => $image_id),
            array('%d')
        );
        
        if ($result === false) {
            return new WP_Error('db_error', __('Erreur lors de la suppression de la base de données', 'compositeur-visuel-pro'));
        }
        
        return true;
    }
    
    /**
     * Gérer l'upload depuis l'admin
     */
    public function handle_admin_upload() {
        if (!wp_verify_nonce($_POST['nonce'], 'cvp_admin_nonce')) {
            wp_send_json_error('Nonce invalide');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permissions insuffisantes');
        }
        
        if (empty($_FILES['file'])) {
            wp_send_json_error('Aucun fichier reçu');
        }
        
        $file = $_FILES['file'];
        $image_type = sanitize_text_field($_POST['image_type'] ?? 'overlay');
        $category = sanitize_text_field($_POST['category'] ?? 'general');
        
        $result = $this->process_uploaded_file($file, $image_type, $category);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success($result);
        }
    }
    
    /**
     * Gérer la suppression depuis l'admin
     */
    public function handle_admin_delete() {
        if (!wp_verify_nonce($_POST['nonce'], 'cvp_admin_nonce')) {
            wp_send_json_error('Nonce invalide');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permissions insuffisantes');
        }
        
        $image_id = intval($_POST['image_id']);
        
        if (!$image_id) {
            wp_send_json_error('ID d\'image invalide');
        }
        
        $result = $this->delete_image($image_id);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success('Image supprimée avec succès');
        }
    }
    
    /**
     * Gérer la récupération d'images depuis l'admin
     */
    public function handle_admin_get_images() {
        if (!wp_verify_nonce($_POST['nonce'], 'cvp_admin_nonce')) {
            wp_send_json_error('Nonce invalide');
        }
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permissions insuffisantes');
        }
        
        $type = sanitize_text_field($_POST['type'] ?? '');
        $category = sanitize_text_field($_POST['category'] ?? '');
        $limit = intval($_POST['limit'] ?? 0);
        
        $images = $this->get_admin_images($type ?: null, $category ?: null, $limit ?: null);
        
        wp_send_json_success($images);
    }
    
    /**
     * Obtenir les statistiques des images
     */
    public function get_image_stats() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        $stats = array();
        
        // Nombre total d'images
        $stats['total'] = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        
        // Nombre d'arrière-plans
        $stats['backgrounds'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE image_type = %s",
            'background'
        ));
        
        // Nombre d'éléments
        $stats['overlays'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE image_type = %s",
            'overlay'
        ));
        
        // Espace de stockage utilisé
        $stats['storage_used'] = $wpdb->get_var("SELECT SUM(file_size) FROM $table_name") ?: 0;
        
        return $stats;
    }
    
    /**
     * Nettoyer les fichiers orphelins
     */
    public function cleanup_orphaned_files() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        // Récupérer tous les fichiers de la base de données
        $db_files = $wpdb->get_col("SELECT file_path FROM $table_name");
        
        // Scanner les dossiers d'upload
        $folders = array('backgrounds', 'overlays');
        $orphaned_files = array();
        
        foreach ($folders as $folder) {
            $folder_path = $this->upload_dir . '/' . $folder;
            
            if (is_dir($folder_path)) {
                $files = glob($folder_path . '/*');
                
                foreach ($files as $file) {
                    if (is_file($file) && !in_array($file, $db_files)) {
                        $orphaned_files[] = $file;
                        unlink($file); // Supprimer le fichier orphelin
                    }
                }
            }
        }
        
        return count($orphaned_files);
    }
    
    /**
     * Rendre l'interface d'upload pour l'admin
     */
    public function render_upload_interface() {
        ?>
        <div class="cvp-upload-interface">
            <div class="cvp-upload-tabs">
                <button class="cvp-tab-btn active" data-tab="upload"><?php _e('Upload Fichier', 'compositeur-visuel-pro'); ?></button>
                <button class="cvp-tab-btn" data-tab="media"><?php _e('Médiathèque', 'compositeur-visuel-pro'); ?></button>
            </div>
            
            <div class="cvp-tab-content" id="upload-tab">
                <form id="cvp-upload-form" enctype="multipart/form-data">
                    <div class="cvp-upload-dropzone" id="cvp-admin-dropzone">
                        <svg class="cvp-upload-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                        </svg>
                        <h3><?php _e('Glissez vos images ici', 'compositeur-visuel-pro'); ?></h3>
                        <p><?php _e('ou cliquez pour parcourir vos fichiers', 'compositeur-visuel-pro'); ?></p>
                        <input type="file" id="cvp-admin-file-input" name="files[]" multiple accept="image/*" style="display: none;">
                    </div>
                    
                    <div class="cvp-upload-options">
                        <div class="cvp-option-group">
                            <label for="image-type"><?php _e('Type d\'image', 'compositeur-visuel-pro'); ?></label>
                            <select id="image-type" name="image_type" class="cvp-select">
                                <option value="background"><?php _e('Arrière-plan', 'compositeur-visuel-pro'); ?></option>
                                <option value="overlay"><?php _e('Élément de superposition', 'compositeur-visuel-pro'); ?></option>
                            </select>
                        </div>
                        
                        <div class="cvp-option-group">
                            <label for="image-category"><?php _e('Catégorie', 'compositeur-visuel-pro'); ?></label>
                            <select id="image-category" name="category" class="cvp-select">
                                <option value="general"><?php _e('Général', 'compositeur-visuel-pro'); ?></option>
                                <option value="nature"><?php _e('Nature', 'compositeur-visuel-pro'); ?></option>
                                <option value="business"><?php _e('Business', 'compositeur-visuel-pro'); ?></option>
                                <option value="abstract"><?php _e('Abstrait', 'compositeur-visuel-pro'); ?></option>
                                <option value="technology"><?php _e('Technologie', 'compositeur-visuel-pro'); ?></option>
                                <option value="people"><?php _e('Personnes', 'compositeur-visuel-pro'); ?></option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="cvp-upload-progress" id="cvp-upload-progress" style="display: none;">
                        <div class="cvp-progress-bar">
                            <div class="cvp-progress-fill"></div>
                        </div>
                        <div class="cvp-progress-text">0%</div>
                    </div>
                    
                    <div class="cvp-upload-actions">
                        <button type="button" id="cvp-start-upload" class="cvp-btn cvp-btn-primary" disabled>
                            <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clip-rule="evenodd"/>
                            </svg>
                            <?php _e('Commencer l\'Upload', 'compositeur-visuel-pro'); ?>
                        </button>
                        <button type="button" id="cvp-cancel-upload" class="cvp-btn cvp-btn-secondary">
                            <?php _e('Annuler', 'compositeur-visuel-pro'); ?>
                        </button>
                    </div>
                </form>
            </div>
            
            <div class="cvp-tab-content" id="media-tab" style="display: none;">
                <div class="cvp-media-library">
                    <p><?php _e('Sélectionnez des images depuis votre médiathèque WordPress', 'compositeur-visuel-pro'); ?></p>
                    <button class="cvp-btn cvp-btn-primary" id="cvp-open-media-library">
                        <svg class="cvp-btn-icon" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                        </svg>
                        <?php _e('Ouvrir la Médiathèque', 'compositeur-visuel-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Gestion des onglets
            $('.cvp-tab-btn').on('click', function() {
                const tab = $(this).data('tab');
                $('.cvp-tab-btn').removeClass('active');
                $(this).addClass('active');
                $('.cvp-tab-content').hide();
                $('#' + tab + '-tab').show();
            });
            
            // Gestion du glisser-déposer
            const dropzone = $('#cvp-admin-dropzone');
            const fileInput = $('#cvp-admin-file-input');
            
            dropzone.on('click', function() {
                fileInput.click();
            });
            
            dropzone.on('dragover', function(e) {
                e.preventDefault();
                $(this).addClass('cvp-dragover');
            });
            
            dropzone.on('dragleave', function(e) {
                e.preventDefault();
                $(this).removeClass('cvp-dragover');
            });
            
            dropzone.on('drop', function(e) {
                e.preventDefault();
                $(this).removeClass('cvp-dragover');
                
                const files = e.originalEvent.dataTransfer.files;
                handleFiles(files);
            });
            
            fileInput.on('change', function() {
                const files = this.files;
                handleFiles(files);
            });
            
            function handleFiles(files) {
                if (files.length > 0) {
                    $('#cvp-start-upload').prop('disabled', false);
                    // Afficher la liste des fichiers sélectionnés
                    let fileList = '<div class="cvp-file-list"><h4>Fichiers sélectionnés:</h4>';
                    for (let i = 0; i < files.length; i++) {
                        fileList += '<div class="cvp-file-item">' + files[i].name + ' (' + formatFileSize(files[i].size) + ')</div>';
                    }
                    fileList += '</div>';
                    dropzone.after(fileList);
                }
            }
            
            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            }
            
            // Gestion de l'upload
            $('#cvp-start-upload').on('click', function() {
                const files = fileInput[0].files;
                const imageType = $('#image-type').val();
                const category = $('#image-category').val();
                
                if (files.length === 0) {
                    alert('<?php _e('Veuillez sélectionner au moins un fichier', 'compositeur-visuel-pro'); ?>');
                    return;
                }
                
                uploadFiles(files, imageType, category);
            });
            
            function uploadFiles(files, imageType, category) {
                const progressContainer = $('#cvp-upload-progress');
                const progressBar = $('.cvp-progress-fill');
                const progressText = $('.cvp-progress-text');
                
                progressContainer.show();
                
                let uploadedCount = 0;
                const totalFiles = files.length;
                
                for (let i = 0; i < files.length; i++) {
                    const formData = new FormData();
                    formData.append('action', 'cvp_admin_upload');
                    formData.append('nonce', cvpAdmin.nonce);
                    formData.append('file', files[i]);
                    formData.append('image_type', imageType);
                    formData.append('category', category);
                    
                    $.ajax({
                        url: cvpAdmin.ajaxUrl,
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            uploadedCount++;
                            const progress = Math.round((uploadedCount / totalFiles) * 100);
                            progressBar.css('width', progress + '%');
                            progressText.text(progress + '%');
                            
                            if (uploadedCount === totalFiles) {
                                setTimeout(function() {
                                    progressContainer.hide();
                                    alert(cvpAdmin.strings.uploadSuccess);
                                    location.reload(); // Recharger la page pour voir les nouvelles images
                                }, 1000);
                            }
                        },
                        error: function() {
                            alert(cvpAdmin.strings.uploadError);
                        }
                    });
                }
            }
            
            // Médiathèque WordPress
            $('#cvp-open-media-library').on('click', function() {
                const mediaUploader = wp.media({
                    title: '<?php _e('Sélectionner des images', 'compositeur-visuel-pro'); ?>',
                    button: {
                        text: '<?php _e('Utiliser ces images', 'compositeur-visuel-pro'); ?>'
                    },
                    multiple: true,
                    library: {
                        type: 'image'
                    }
                });
                
                mediaUploader.on('select', function() {
                    const attachments = mediaUploader.state().get('selection').toJSON();
                    // Traiter les images sélectionnées depuis la médiathèque
                    console.log('Images sélectionnées:', attachments);
                });
                
                mediaUploader.open();
            });
        });
        </script>
        <?php
    }
}

