/**
 * Compositeur Visuel Pro - Frontend JavaScript v2.0
 * Interface moderne avec aperçu fonctionnel et fonctionnalités avancées
 */

(function($) {
    'use strict';

    /**
     * Classe principale du compositeur visuel
     */
    class CVPComposer {
        constructor(containerId, options = {}) {
            this.containerId = containerId;
            this.container = $(`#${containerId}`);
            this.options = $.extend({}, this.getDefaultOptions(), options);
            
            // État de l'application
            this.state = {
                selectedBackground: null,
                selectedOverlay: null,
                overlayElements: [],
                isDragging: false,
                isResizing: false,
                activeElement: null,
                canvasScale: 1,
                history: [],
                historyIndex: -1
            };
            
            // Éléments DOM
            this.elements = {};
            
            this.init();
        }
        
        /**
         * Options par défaut
         */
        getDefaultOptions() {
            return {
                canvasWidth: 800,
                canvasHeight: 600,
                maxFileSize: 10 * 1024 * 1024, // 10MB
                allowedTypes: ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'],
                enableAnimations: true,
                enableGrid: false,
                gridSize: 20,
                snapToGrid: false,
                autoSave: true,
                quality: 0.9
            };
        }
        
        /**
         * Initialisation
         */
        init() {
            this.initElements();
            this.bindEvents();
            this.setupCanvas();
            this.loadDefaultImages();
            this.initializeState();
            
            if (this.options.enableAnimations) {
                this.initAnimations();
            }
            
            console.log('CVP Composer initialized:', this.containerId);
        }
        
        /**
         * Initialiser les références aux éléments DOM
         */
        initElements() {
            const container = this.container;
            
            this.elements = {
                // Zones principales
                canvas: container.find('#cvp-canvas'),
                canvasContainer: container.find('.cvp-canvas-container'),
                controlsPanel: container.find('.cvp-controls-panel'),
                previewPanel: container.find('.cvp-preview-panel'),
                
                // Upload
                uploadZone: container.find('#cvp-upload-area'),
                uploadInput: container.find('#cvp-file-input'),
                
                // Grilles d'images
                backgroundGrid: container.find('.cvp-image-grid').first(),
                overlayGrid: container.find('.cvp-image-grid').last(),
                
                // Contrôles
                opacitySlider: container.find('#cvp-opacity-slider'),
                rotationSlider: container.find('#cvp-rotation-slider'),
                scaleSlider: container.find('#cvp-scale-slider'),
                positionX: container.find('#cvp-pos-x'),
                positionY: container.find('#cvp-pos-y'),
                
                // Boutons
                downloadBtn: container.find('#cvp-download-btn'),
                resetBtn: container.find('#cvp-reset-btn'),
                undoBtn: container.find('#cvp-undo-btn'),
                redoBtn: container.find('#cvp-redo-btn'),
                
                // Messages
                messageContainer: container.find('.cvp-message-container')
            };
            
            // Créer les éléments manquants
            this.createMissingElements();
        }
        
        /**
         * Créer les éléments DOM manquants
         */
        createMissingElements() {
            // Container de messages si absent
            if (this.elements.messageContainer.length === 0) {
                this.elements.messageContainer = $('<div class="cvp-message-container"></div>');
                this.container.prepend(this.elements.messageContainer);
            }
            
            // Canvas si absent
            if (this.elements.canvas.length === 0) {
                const canvasHtml = `
                    <div class="cvp-canvas-container">
                        <div class="cvp-canvas" style="width: ${this.options.canvasWidth}px; height: ${this.options.canvasHeight}px;">
                            <div class="cvp-canvas-background"></div>
                            <div class="cvp-canvas-overlays"></div>
                        </div>
                    </div>
                `;
                this.container.find('.cvp-preview-panel').append(canvasHtml);
                this.elements.canvas = this.container.find('.cvp-canvas');
                this.elements.canvasContainer = this.container.find('.cvp-canvas-container');
            }
        }
        
        /**
         * Lier les événements
         */
        bindEvents() {
            // Upload par glisser-déposer
            this.bindDragDropEvents();
            
            // Upload par clic
            this.elements.uploadZone.on('click', () => {
                this.elements.uploadInput.click();
            });
            
            this.elements.uploadInput.on('change', (e) => {
                this.handleFileUpload(e.target.files);
            });
            
            // Sélection d'images prédéfinies
            this.container.on('click', '.cvp-image-item[data-type="background"]', (e) => {
                this.selectBackground($(e.currentTarget));
            });
            
            this.container.on('click', '.cvp-image-item[data-type="overlay"]', (e) => {
                this.selectOverlay($(e.currentTarget));
            });
            
            this.container.on('click', '.cvp-add-image-btn', (e) => {
                e.stopPropagation();
                const imageItem = $(e.currentTarget).closest('.cvp-image-item');
                const imageType = imageItem.data('type');
                if (imageType === 'background') {
                    this.selectBackground(imageItem);
                } else {
                    this.selectOverlay(imageItem);
                }
            });
            
            // Contrôles
            this.elements.opacitySlider.on('input', (e) => {
                this.updateActiveElementProperty('opacity', e.target.value / 100);
            });
            
            this.elements.rotationSlider.on('input', (e) => {
                this.updateActiveElementProperty('rotation', e.target.value);
            });
            
            this.elements.scaleSlider.on('input', (e) => {
                this.updateActiveElementProperty('scale', e.target.value / 100);
            });
            
            this.elements.positionX.on('input', (e) => {
                this.updateActiveElementPosition('x', e.target.value);
            });
            
            this.elements.positionY.on('input', (e) => {
                this.updateActiveElementPosition('y', e.target.value);
            });
            
            // Boutons d'action
            this.elements.downloadBtn.on('click', () => {
                this.downloadComposition();
            });
            
            this.elements.resetBtn.on('click', () => {
                this.resetCanvas();
            });
            
            this.elements.undoBtn.on('click', () => {
                this.undo();
            });
            
            this.elements.redoBtn.on('click', () => {
                this.redo();
            });
            
            // Raccourcis clavier
            $(document).on('keydown', (e) => {
                if (e.ctrlKey || e.metaKey) {
                    switch(e.key) {
                        case 'z':
                            e.preventDefault();
                            if (e.shiftKey) {
                                this.redo();
                            } else {
                                this.undo();
                            }
                            break;
                        case 's':
                            e.preventDefault();
                            this.saveComposition();
                            break;
                    }
                }
                
                if (this.state.activeElement) {
                    switch(e.key) {
                        case 'Delete':
                        case 'Backspace':
                            e.preventDefault();
                            this.removeActiveElement();
                            break;
                        case 'ArrowUp':
                            e.preventDefault();
                            this.moveActiveElement(0, e.shiftKey ? -10 : -1);
                            break;
                        case 'ArrowDown':
                            e.preventDefault();
                            this.moveActiveElement(0, e.shiftKey ? 10 : 1);
                            break;
                        case 'ArrowLeft':
                            e.preventDefault();
                            this.moveActiveElement(e.shiftKey ? -10 : -1, 0);
                            break;
                        case 'ArrowRight':
                            e.preventDefault();
                            this.moveActiveElement(e.shiftKey ? 10 : 1, 0);
                            break;
                    }
                }
            });
        }
        
        /**
         * Configurer les événements de glisser-déposer
         */
        bindDragDropEvents() {
            const uploadZone = this.elements.uploadZone[0];
            
            if (!uploadZone) return;
            
            // Prévenir les comportements par défaut
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                uploadZone.addEventListener(eventName, (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                }, false);
            });
            
            // Effets visuels
            ['dragenter', 'dragover'].forEach(eventName => {
                uploadZone.addEventListener(eventName, () => {
                    this.elements.uploadZone.addClass('cvp-dragover');
                }, false);
            });
            
            ['dragleave', 'drop'].forEach(eventName => {
                uploadZone.addEventListener(eventName, () => {
                    this.elements.uploadZone.removeClass('cvp-dragover');
                }, false);
            });
            
            // Gestion du drop
            uploadZone.addEventListener('drop', (e) => {
                const files = e.dataTransfer.files;
                this.handleFileUpload(files);
            }, false);
        }
        
        /**
         * Configurer le canvas
         */
        setupCanvas() {
            const canvas = this.elements.canvas;
            
            // Rendre le canvas interactif
            canvas.on('click', (e) => {
                // Désélectionner si on clique sur le canvas vide
                if (e.target === canvas[0]) {
                    this.deselectAllElements();
                }
            });
            
            // Configurer la grille si activée
            if (this.options.enableGrid) {
                canvas.addClass('cvp-show-grid');
                canvas.css('background-size', `${this.options.gridSize}px ${this.options.gridSize}px`);
            }
        }
        
        /**
         * Charger les images par défaut depuis l'API
         */
        async loadDefaultImages() {
            try {
                const response = await $.ajax({
                    url: cvpFrontend.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'cvp_get_images',
                        nonce: cvpFrontend.nonce
                    }
                });
                
                if (response.success) {
                    this.renderImageGrids(response.data);
                } else {
                    console.warn('Aucune image par défaut trouvée');
                    this.renderEmptyGrids();
                }
            } catch (error) {
                console.error('Erreur lors du chargement des images:', error);
                this.renderEmptyGrids();
            }
        }
        
        /**
         * Rendre les grilles d'images
         */
        renderImageGrids(data) {
            const { backgrounds = [], overlays = [] } = data;
            
            // Rendre les arrière-plans
            if (backgrounds.length > 0) {
                const backgroundHtml = backgrounds.map(img => `
                    <div class="cvp-image-item" data-type="background" data-id="${img.id}" data-url="${img.file_url}">
                        <img src="${img.file_url}" alt="${img.alt_text || 'Arrière-plan'}" loading="lazy">
                        <div class="cvp-image-overlay">
                            <button class="cvp-add-image-btn" title="Ajouter au canvas">
                                <svg fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `).join('');
                
                this.elements.backgroundGrid.html(backgroundHtml);
            } else {
                this.renderEmptyGrid(this.elements.backgroundGrid, 'Aucun arrière-plan disponible');
            }
            
            // Rendre les superpositions
            if (overlays.length > 0) {
                const overlayHtml = overlays.map(img => `
                    <div class="cvp-image-item" data-type="overlay" data-id="${img.id}" data-url="${img.file_url}">
                        <img src="${img.file_url}" alt="${img.alt_text || 'Élément'}" loading="lazy">
                        <div class="cvp-image-overlay">
                            <button class="cvp-add-image-btn" title="Ajouter au canvas">
                                <svg fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clip-rule="evenodd"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `).join('');
                
                this.elements.overlayGrid.html(overlayHtml);
            } else {
                this.renderEmptyGrid(this.elements.overlayGrid, 'Aucun élément disponible');
            }
        }
        
        /**
         * Rendre les grilles vides
         */
        renderEmptyGrids() {
            this.renderEmptyGrid(this.elements.backgroundGrid, 'Aucun arrière-plan disponible');
            this.renderEmptyGrid(this.elements.overlayGrid, 'Aucun élément disponible');
        }
        
        /**
         * Rendre une grille vide
         */
        renderEmptyGrid(container, message) {
            const emptyHtml = `
                <div class="cvp-empty-grid">
                    <svg class="cvp-empty-icon" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"/>
                    </svg>
                    <p class="cvp-empty-text">${message}</p>
                    <p class="cvp-empty-hint">Utilisez l'interface d'administration pour ajouter des images</p>
                </div>
            `;
            container.html(emptyHtml);
        }
        
        /**
         * Initialiser l'état
         */
        initializeState() {
            this.saveState();
            this.updateUI();
        }
        
        /**
         * Gérer l'upload de fichiers
         */
        async handleFileUpload(files) {
            if (!files || files.length === 0) return;
            
            const file = files[0];
            
            // Validation
            if (!this.validateFile(file)) {
                return;
            }
            
            this.showMessage('info', 'Upload en cours...', true);
            
            try {
                const formData = new FormData();
                formData.append('file', file);
                formData.append('action', 'cvp_upload_image');
                formData.append('nonce', cvpFrontend.nonce);
                
                const response = await $.ajax({
                    url: cvpFrontend.ajaxUrl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false
                });
                
                if (response.success) {
                    this.addOverlayToCanvas(response.data.url, file.name);
                    this.showMessage('success', 'Image uploadée avec succès');
                } else {
                    this.showMessage('error', response.data || 'Erreur lors de l\'upload');
                }
            } catch (error) {
                console.error('Erreur upload:', error);
                this.showMessage('error', 'Erreur de connexion');
            }
        }
        
        /**
         * Valider un fichier
         */
        validateFile(file) {
            // Vérifier le type
            if (!this.options.allowedTypes.includes(file.type)) {
                this.showMessage('error', 'Format de fichier non supporté');
                return false;
            }
            
            // Vérifier la taille
            if (file.size > this.options.maxFileSize) {
                this.showMessage('error', 'Fichier trop volumineux');
                return false;
            }
            
            return true;
        }
        
        /**
         * Sélectionner un arrière-plan
         */
        selectBackground(element) {
            // Désélectionner les autres
            this.container.find('.cvp-image-item[data-type="background"]').removeClass('cvp-selected');
            element.addClass('cvp-selected');
            
            const imageUrl = element.data('url');
            this.setCanvasBackground(imageUrl);
            
            this.state.selectedBackground = {
                id: element.data('id'),
                url: imageUrl
            };
            
            this.saveState();
            this.showMessage('success', 'Arrière-plan sélectionné');
        }
        
        /**
         * Sélectionner un élément de superposition
         */
        selectOverlay(element) {
            const imageUrl = element.data('url');
            const imageName = element.find('img').attr('alt') || 'Élément';
            
            this.addOverlayToCanvas(imageUrl, imageName);
            this.showMessage('success', 'Élément ajouté au canvas');
        }
        
        /**
         * Définir l'arrière-plan du canvas
         */
        setCanvasBackground(imageUrl) {
            const canvas = this.elements.canvas;
            
            // Créer ou mettre à jour l'arrière-plan
            let backgroundDiv = canvas.find('.cvp-canvas-background');
            if (backgroundDiv.length === 0) {
                canvas.prepend('<div class="cvp-canvas-background"></div>');
                backgroundDiv = canvas.find('.cvp-canvas-background');
            }
            
            backgroundDiv.css({
                'background-image': `url(${imageUrl})`,
                'background-size': 'cover',
                'background-position': 'center',
                'background-repeat': 'no-repeat',
                'position': 'absolute',
                'top': 0,
                'left': 0,
                'width': '100%',
                'height': '100%',
                'z-index': 1
            });
        }
        
        /**
         * Ajouter un élément de superposition au canvas
         */
        addOverlayToCanvas(imageUrl, imageName) {
            const canvas = this.elements.canvas;
            
            // Créer le conteneur d'overlays s'il n'existe pas
            let overlaysContainer = canvas.find('.cvp-canvas-overlays');
            if (overlaysContainer.length === 0) {
                canvas.append('<div class="cvp-canvas-overlays"></div>');
                overlaysContainer = canvas.find('.cvp-canvas-overlays');
            }
            
            const elementId = 'cvp-overlay-' + Date.now();
            const centerX = canvas.width() / 2 - 75; // 150px de largeur par défaut
            const centerY = canvas.height() / 2 - 75;
            
            const overlayElement = $(`
                <div class="cvp-overlay-element" id="${elementId}" data-name="${imageName}">
                    <img src="${imageUrl}" alt="${imageName}" draggable="false">
                    <div class="cvp-resize-handles">
                        <div class="cvp-resize-handle cvp-nw"></div>
                        <div class="cvp-resize-handle cvp-ne"></div>
                        <div class="cvp-resize-handle cvp-sw"></div>
                        <div class="cvp-resize-handle cvp-se"></div>
                    </div>
                </div>
            `);
            
            // Styles initiaux
            overlayElement.css({
                position: 'absolute',
                left: centerX + 'px',
                top: centerY + 'px',
                width: '150px',
                height: 'auto',
                cursor: 'move',
                zIndex: 10 + this.state.overlayElements.length,
                opacity: 1,
                transform: 'rotate(0deg) scale(1)'
            });
            
            overlaysContainer.append(overlayElement);
            
            // Ajouter à l'état
            const elementData = {
                id: elementId,
                name: imageName,
                url: imageUrl,
                x: centerX,
                y: centerY,
                width: 150,
                height: 'auto',
                opacity: 1,
                rotation: 0,
                scale: 1,
                zIndex: 10 + this.state.overlayElements.length
            };
            
            this.state.overlayElements.push(elementData);
            
            // Rendre l'élément interactif
            this.makeElementInteractive(overlayElement, elementData);
            
            // Sélectionner automatiquement le nouvel élément
            this.selectElement(overlayElement);
            
            this.saveState();
        }
        
        /**
         * Rendre un élément interactif
         */
        makeElementInteractive(element, elementData) {
            // Sélection
            element.on('click', (e) => {
                e.stopPropagation();
                this.selectElement(element);
            });
            
            // Glisser-déposer
            element.draggable({
                containment: this.elements.canvas,
                start: (e, ui) => {
                    this.state.isDragging = true;
                    element.addClass('cvp-dragging');
                },
                drag: (e, ui) => {
                    elementData.x = ui.position.left;
                    elementData.y = ui.position.top;
                    this.updateControlsFromElement(elementData);
                },
                stop: (e, ui) => {
                    this.state.isDragging = false;
                    element.removeClass('cvp-dragging');
                    elementData.x = ui.position.left;
                    elementData.y = ui.position.top;
                    this.saveState();
                }
            });
            
            // Redimensionnement
            element.find('.cvp-resize-handle').on('mousedown', (e) => {
                e.stopPropagation();
                this.startResize(e, element, elementData);
            });
        }
        
        /**
         * Sélectionner un élément
         */
        selectElement(element) {
            // Désélectionner tous les autres
            this.elements.canvas.find('.cvp-overlay-element').removeClass('cvp-selected');
            
            // Sélectionner l'élément
            element.addClass('cvp-selected');
            
            // Mettre à jour l'état
            this.state.activeElement = element;
            
            // Trouver les données de l'élément
            const elementId = element.attr('id');
            const elementData = this.state.overlayElements.find(el => el.id === elementId);
            
            if (elementData) {
                this.updateControlsFromElement(elementData);
            }
            
            this.updateUI();
        }
        
        /**
         * Désélectionner tous les éléments
         */
        deselectAllElements() {
            this.elements.canvas.find('.cvp-overlay-element').removeClass('cvp-selected');
            this.state.activeElement = null;
            this.updateUI();
        }
        
        /**
         * Mettre à jour les contrôles depuis un élément
         */
        updateControlsFromElement(elementData) {
            this.elements.opacitySlider.val(elementData.opacity * 100);
            this.elements.rotationSlider.val(elementData.rotation);
            this.elements.scaleSlider.val(elementData.scale * 100);
            this.elements.positionX.val(Math.round(elementData.x));
            this.elements.positionY.val(Math.round(elementData.y));
            
            // Mettre à jour les affichages de valeurs
            this.container.find('.cvp-opacity-value').text(Math.round(elementData.opacity * 100) + '%');
            this.container.find('.cvp-rotation-value').text(elementData.rotation + '°');
            this.container.find('.cvp-scale-value').text(Math.round(elementData.scale * 100) + '%');
        }
        
        /**
         * Mettre à jour une propriété de l'élément actif
         */
        updateActiveElementProperty(property, value) {
            if (!this.state.activeElement) return;
            
            const elementId = this.state.activeElement.attr('id');
            const elementData = this.state.overlayElements.find(el => el.id === elementId);
            
            if (!elementData) return;
            
            elementData[property] = parseFloat(value);
            
            // Appliquer visuellement
            this.applyElementStyles(this.state.activeElement, elementData);
            
            // Mettre à jour l'affichage de la valeur
            this.updateValueDisplay(property, value);
        }
        
        /**
         * Mettre à jour la position de l'élément actif
         */
        updateActiveElementPosition(axis, value) {
            if (!this.state.activeElement) return;
            
            const elementId = this.state.activeElement.attr('id');
            const elementData = this.state.overlayElements.find(el => el.id === elementId);
            
            if (!elementData) return;
            
            elementData[axis] = parseFloat(value);
            
            // Appliquer visuellement
            this.state.activeElement.css({
                left: elementData.x + 'px',
                top: elementData.y + 'px'
            });
        }
        
        /**
         * Appliquer les styles à un élément
         */
        applyElementStyles(element, elementData) {
            element.css({
                opacity: elementData.opacity,
                transform: `rotate(${elementData.rotation}deg) scale(${elementData.scale})`
            });
        }
        
        /**
         * Mettre à jour l'affichage d'une valeur
         */
        updateValueDisplay(property, value) {
            const displays = {
                opacity: Math.round(value * 100) + '%',
                rotation: value + '°',
                scale: Math.round(value * 100) + '%'
            };
            
            if (displays[property]) {
                this.container.find(`.cvp-${property}-value`).text(displays[property]);
            }
        }
        
        /**
         * Déplacer l'élément actif
         */
        moveActiveElement(deltaX, deltaY) {
            if (!this.state.activeElement) return;
            
            const elementId = this.state.activeElement.attr('id');
            const elementData = this.state.overlayElements.find(el => el.id === elementId);
            
            if (!elementData) return;
            
            elementData.x += deltaX;
            elementData.y += deltaY;
            
            // Contraindre dans le canvas
            const canvas = this.elements.canvas;
            const maxX = canvas.width() - this.state.activeElement.width();
            const maxY = canvas.height() - this.state.activeElement.height();
            
            elementData.x = Math.max(0, Math.min(maxX, elementData.x));
            elementData.y = Math.max(0, Math.min(maxY, elementData.y));
            
            // Appliquer
            this.state.activeElement.css({
                left: elementData.x + 'px',
                top: elementData.y + 'px'
            });
            
            this.updateControlsFromElement(elementData);
        }
        
        /**
         * Supprimer l'élément actif
         */
        removeActiveElement() {
            if (!this.state.activeElement) return;
            
            const elementId = this.state.activeElement.attr('id');
            
            // Supprimer de l'état
            this.state.overlayElements = this.state.overlayElements.filter(el => el.id !== elementId);
            
            // Supprimer du DOM
            this.state.activeElement.remove();
            this.state.activeElement = null;
            
            this.updateUI();
            this.saveState();
            this.showMessage('info', 'Élément supprimé');
        }
        
        /**
         * Télécharger la composition
         */
        async downloadComposition() {
            if (!window.html2canvas) {
                this.showMessage('error', 'Bibliothèque de génération d\'image non disponible');
                return;
            }
            
            this.showMessage('info', 'Génération de l\'image...', true);
            
            try {
                // Masquer temporairement les contrôles
                this.elements.canvas.find('.cvp-resize-handles').hide();
                this.elements.canvas.find('.cvp-overlay-element').removeClass('cvp-selected');
                
                const canvas = await html2canvas(this.elements.canvas[0], {
                    useCORS: true,
                    scale: 2,
                    backgroundColor: '#ffffff',
                    width: this.options.canvasWidth,
                    height: this.options.canvasHeight
                });
                
                // Restaurer les contrôles
                this.elements.canvas.find('.cvp-resize-handles').show();
                if (this.state.activeElement) {
                    this.state.activeElement.addClass('cvp-selected');
                }
                
                // Télécharger
                const link = document.createElement('a');
                link.download = `composition-${Date.now()}.png`;
                link.href = canvas.toDataURL('image/png', this.options.quality);
                link.click();
                
                this.showMessage('success', 'Image téléchargée avec succès');
                
            } catch (error) {
                console.error('Erreur génération:', error);
                this.showMessage('error', 'Erreur lors de la génération de l\'image');
            }
        }
        
        /**
         * Réinitialiser le canvas
         */
        resetCanvas() {
            if (!confirm('Êtes-vous sûr de vouloir tout réinitialiser ?')) {
                return;
            }
            
            // Vider le canvas
            this.elements.canvas.find('.cvp-canvas-background').css('background-image', 'none');
            this.elements.canvas.find('.cvp-canvas-overlays').empty();
            
            // Réinitialiser l'état
            this.state.selectedBackground = null;
            this.state.overlayElements = [];
            this.state.activeElement = null;
            
            // Désélectionner les images
            this.elements.backgroundGrid.find('.cvp-background-item').removeClass('cvp-selected');
            
            this.updateUI();
            this.saveState();
            this.showMessage('info', 'Canvas réinitialisé');
        }
        
        /**
         * Sauvegarder l'état pour l'historique
         */
        saveState() {
            const state = {
                selectedBackground: this.state.selectedBackground,
                overlayElements: JSON.parse(JSON.stringify(this.state.overlayElements)),
                timestamp: Date.now()
            };
            
            // Limiter l'historique
            if (this.state.history.length > 50) {
                this.state.history.shift();
            }
            
            // Ajouter le nouvel état
            this.state.history = this.state.history.slice(0, this.state.historyIndex + 1);
            this.state.history.push(state);
            this.state.historyIndex = this.state.history.length - 1;
            
            this.updateUI();
        }
        
        /**
         * Annuler (Undo)
         */
        undo() {
            if (this.state.historyIndex > 0) {
                this.state.historyIndex--;
                this.restoreState(this.state.history[this.state.historyIndex]);
                this.showMessage('info', 'Action annulée');
            }
        }
        
        /**
         * Refaire (Redo)
         */
        redo() {
            if (this.state.historyIndex < this.state.history.length - 1) {
                this.state.historyIndex++;
                this.restoreState(this.state.history[this.state.historyIndex]);
                this.showMessage('info', 'Action refaite');
            }
        }
        
        /**
         * Restaurer un état
         */
        restoreState(state) {
            // Restaurer l'arrière-plan
            if (state.selectedBackground) {
                this.setCanvasBackground(state.selectedBackground.url);
                this.state.selectedBackground = state.selectedBackground;
            }
            
            // Restaurer les éléments
            this.elements.canvas.find('.cvp-canvas-overlays').empty();
            this.state.overlayElements = [];
            
            state.overlayElements.forEach(elementData => {
                this.restoreOverlayElement(elementData);
            });
            
            this.updateUI();
        }
        
        /**
         * Restaurer un élément de superposition
         */
        restoreOverlayElement(elementData) {
            const overlayElement = $(`
                <div class="cvp-overlay-element" id="${elementData.id}" data-name="${elementData.name}">
                    <img src="${elementData.url}" alt="${elementData.name}" draggable="false">
                    <div class="cvp-resize-handles">
                        <div class="cvp-resize-handle cvp-nw"></div>
                        <div class="cvp-resize-handle cvp-ne"></div>
                        <div class="cvp-resize-handle cvp-sw"></div>
                        <div class="cvp-resize-handle cvp-se"></div>
                    </div>
                </div>
            `);
            
            // Appliquer les styles
            overlayElement.css({
                position: 'absolute',
                left: elementData.x + 'px',
                top: elementData.y + 'px',
                width: elementData.width + 'px',
                height: elementData.height,
                cursor: 'move',
                zIndex: elementData.zIndex,
                opacity: elementData.opacity,
                transform: `rotate(${elementData.rotation}deg) scale(${elementData.scale})`
            });
            
            this.elements.canvas.find('.cvp-canvas-overlays').append(overlayElement);
            this.state.overlayElements.push(elementData);
            this.makeElementInteractive(overlayElement, elementData);
        }
        
        /**
         * Mettre à jour l'interface utilisateur
         */
        updateUI() {
            // Boutons undo/redo
            this.elements.undoBtn.prop('disabled', this.state.historyIndex <= 0);
            this.elements.redoBtn.prop('disabled', this.state.historyIndex >= this.state.history.length - 1);
            
            // Contrôles d'élément
            const hasActiveElement = this.state.activeElement !== null;
            this.elements.opacitySlider.prop('disabled', !hasActiveElement);
            this.elements.rotationSlider.prop('disabled', !hasActiveElement);
            this.elements.scaleSlider.prop('disabled', !hasActiveElement);
            this.elements.positionX.prop('disabled', !hasActiveElement);
            this.elements.positionY.prop('disabled', !hasActiveElement);
            
            // Bouton de téléchargement
            const hasContent = this.state.selectedBackground || this.state.overlayElements.length > 0;
            this.elements.downloadBtn.prop('disabled', !hasContent);
        }
        
        /**
         * Afficher un message
         */
        showMessage(type, message, persistent = false) {
            const messageElement = $(`
                <div class="cvp-message cvp-message-${type}">
                    <svg class="cvp-icon" fill="currentColor" viewBox="0 0 20 20">
                        ${this.getMessageIcon(type)}
                    </svg>
                    <span>${message}</span>
                </div>
            `);
            
            this.elements.messageContainer.empty().append(messageElement);
            
            if (!persistent) {
                setTimeout(() => {
                    messageElement.fadeOut(300, () => messageElement.remove());
                }, 4000);
            }
        }
        
        /**
         * Obtenir l'icône pour un type de message
         */
        getMessageIcon(type) {
            const icons = {
                info: '<path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/>',
                success: '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>',
                warning: '<path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>',
                error: '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>'
            };
            return icons[type] || icons.info;
        }
        
        /**
         * Initialiser les animations
         */
        initAnimations() {
            // Animation d'entrée pour les éléments
            this.container.find('.cvp-controls-panel, .cvp-preview-panel').each(function(index) {
                $(this).css({
                    opacity: 0,
                    transform: 'translateY(20px)'
                }).delay(index * 100).animate({
                    opacity: 1
                }, 600, function() {
                    $(this).css('transform', 'translateY(0)');
                });
            });
        }
        
        /**
         * Sauvegarder la composition
         */
        async saveComposition() {
            if (this.options.autoSave) {
                try {
                    const compositionData = {
                        background: this.state.selectedBackground,
                        elements: this.state.overlayElements,
                        canvas: {
                            width: this.options.canvasWidth,
                            height: this.options.canvasHeight
                        },
                        timestamp: Date.now()
                    };
                    
                    await $.ajax({
                        url: cvpFrontend.ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'cvp_save_composition',
                            nonce: cvpFrontend.nonce,
                            composition: JSON.stringify(compositionData)
                        }
                    });
                    
                    this.showMessage('success', 'Composition sauvegardée');
                } catch (error) {
                    console.error('Erreur sauvegarde:', error);
                }
            }
        }
    }
    
    /**
     * Initialisation automatique
     */
    $(document).ready(function() {
        $('.cvp-container').each(function() {
            const containerId = $(this).attr('id');
            if (containerId) {
                const options = $(this).data('options') || {};
                new CVPComposer(containerId, options);
            }
        });
    });
    
    // Exposer la classe globalement
    window.CVPComposer = CVPComposer;
    
})(jQuery);

