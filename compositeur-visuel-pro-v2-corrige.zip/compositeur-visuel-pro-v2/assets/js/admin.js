/**
 * Compositeur Visuel Pro - Admin JavaScript v2.0
 * Interface d'administration moderne et fonctionnelle
 */

(function($) {
    'use strict';

    /**
     * Classe principale de l'administration
     */
    class CVPAdmin {
        constructor() {
            this.init();
        }
        
        /**
         * Initialisation
         */
        init() {
            this.bindEvents();
            this.initColorPickers();
            this.initImageManager();
            this.initShortcodeGenerator();
            this.initNotifications();
            
            console.log('CVP Admin initialized');
        }
        
        /**
         * Lier les événements
         */
        bindEvents() {
            // Gestion des onglets
            $(document).on('click', '.cvp-tab-btn', this.handleTabClick.bind(this));
            
            // Gestion des boutons de copie
            $(document).on('click', '.cvp-copy-btn', this.handleCopyClick.bind(this));
            
            // Gestion de l'upload d'images
            $(document).on('click', '#cvp-open-media-library', this.openMediaLibrary.bind(this));
            
            // Gestion des actions rapides
            $(document).on('click', '.cvp-quick-action', this.handleQuickAction.bind(this));
            
            // Sauvegarde automatique des paramètres
            $(document).on('change', '.cvp-setting-input', this.autoSaveSettings.bind(this));
            
            // Gestion des modals
            $(document).on('click', '[data-modal]', this.openModal.bind(this));
            $(document).on('click', '.cvp-modal-close', this.closeModal.bind(this));
            $(document).on('click', '.cvp-modal', this.handleModalBackdropClick.bind(this));
        }
        
        /**
         * Gestion des clics sur les onglets
         */
        handleTabClick(e) {
            e.preventDefault();
            
            const $tab = $(e.currentTarget);
            const tabId = $tab.data('tab');
            
            // Désactiver tous les onglets
            $('.cvp-tab-btn').removeClass('active');
            $('.cvp-tab-content').hide();
            
            // Activer l'onglet sélectionné
            $tab.addClass('active');
            $('#' + tabId + '-tab').show();
        }
        
        /**
         * Gestion des clics sur les boutons de copie
         */
        handleCopyClick(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const $codeElement = $btn.siblings('code');
            const textToCopy = $codeElement.text();
            
            // Copier dans le presse-papiers
            navigator.clipboard.writeText(textToCopy).then(() => {
                this.showNotification('success', 'Shortcode copié dans le presse-papiers');
                
                // Animation du bouton
                const originalText = $btn.text();
                $btn.text('Copié !').addClass('copied');
                
                setTimeout(() => {
                    $btn.text(originalText).removeClass('copied');
                }, 2000);
            }).catch(() => {
                this.showNotification('error', 'Erreur lors de la copie');
            });
        }
        
        /**
         * Ouvrir la médiathèque WordPress
         */
        openMediaLibrary(e) {
            e.preventDefault();
            
            if (typeof wp === 'undefined' || !wp.media) {
                this.showNotification('error', 'Médiathèque WordPress non disponible');
                return;
            }
            
            const mediaUploader = wp.media({
                title: 'Sélectionner des images',
                button: {
                    text: 'Utiliser ces images'
                },
                multiple: true,
                library: {
                    type: 'image'
                }
            });
            
            mediaUploader.on('select', () => {
                const attachments = mediaUploader.state().get('selection').toJSON();
                this.processMediaLibrarySelection(attachments);
            });
            
            mediaUploader.open();
        }
        
        /**
         * Traiter la sélection de la médiathèque
         */
        processMediaLibrarySelection(attachments) {
            if (!attachments.length) {
                return;
            }
            
            this.showNotification('info', `${attachments.length} image(s) sélectionnée(s)`);
            
            // Traiter chaque image sélectionnée
            attachments.forEach(attachment => {
                this.importImageFromMediaLibrary(attachment);
            });
        }
        
        /**
         * Importer une image depuis la médiathèque
         */
        importImageFromMediaLibrary(attachment) {
            const data = {
                action: 'cvp_import_from_media',
                nonce: cvpAdmin.nonce,
                attachment_id: attachment.id,
                image_type: $('#image-type').val() || 'overlay',
                category: $('#image-category').val() || 'general'
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Image importée avec succès');
                        this.refreshImageGrid();
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors de l\'importation');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Gestion des actions rapides
         */
        handleQuickAction(e) {
            e.preventDefault();
            
            const $action = $(e.currentTarget);
            const actionType = $action.data('action');
            
            switch (actionType) {
                case 'clear-cache':
                    this.clearCache();
                    break;
                case 'export-settings':
                    this.exportSettings();
                    break;
                case 'import-settings':
                    this.importSettings();
                    break;
                case 'reset-settings':
                    this.resetSettings();
                    break;
                default:
                    console.log('Action non reconnue:', actionType);
            }
        }
        
        /**
         * Vider le cache
         */
        clearCache() {
            const data = {
                action: 'cvp_clear_cache',
                nonce: cvpAdmin.nonce
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Cache vidé avec succès');
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors du vidage du cache');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Exporter les paramètres
         */
        exportSettings() {
            const data = {
                action: 'cvp_export_settings',
                nonce: cvpAdmin.nonce
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        // Créer un fichier de téléchargement
                        const blob = new Blob([JSON.stringify(response.data, null, 2)], {
                            type: 'application/json'
                        });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'cvp-settings-' + new Date().toISOString().split('T')[0] + '.json';
                        a.click();
                        URL.revokeObjectURL(url);
                        
                        this.showNotification('success', 'Paramètres exportés avec succès');
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors de l\'exportation');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Importer les paramètres
         */
        importSettings() {
            // Créer un input file temporaire
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const settings = JSON.parse(e.target.result);
                        this.processImportedSettings(settings);
                    } catch (error) {
                        this.showNotification('error', 'Fichier JSON invalide');
                    }
                };
                reader.readAsText(file);
            };
            
            input.click();
        }
        
        /**
         * Traiter les paramètres importés
         */
        processImportedSettings(settings) {
            const data = {
                action: 'cvp_import_settings',
                nonce: cvpAdmin.nonce,
                settings: JSON.stringify(settings)
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Paramètres importés avec succès');
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors de l\'importation');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Réinitialiser les paramètres
         */
        resetSettings() {
            if (!confirm('Êtes-vous sûr de vouloir réinitialiser tous les paramètres ?')) {
                return;
            }
            
            const data = {
                action: 'cvp_reset_settings',
                nonce: cvpAdmin.nonce
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Paramètres réinitialisés avec succès');
                        setTimeout(() => {
                            location.reload();
                        }, 1500);
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors de la réinitialisation');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Sauvegarde automatique des paramètres
         */
        autoSaveSettings(e) {
            const $input = $(e.currentTarget);
            const settingName = $input.attr('name');
            const settingValue = $input.val();
            
            // Débounce pour éviter trop de requêtes
            clearTimeout(this.saveTimeout);
            this.saveTimeout = setTimeout(() => {
                this.saveSetting(settingName, settingValue);
            }, 1000);
        }
        
        /**
         * Sauvegarder un paramètre
         */
        saveSetting(name, value) {
            const data = {
                action: 'cvp_save_setting',
                nonce: cvpAdmin.nonce,
                setting_name: name,
                setting_value: value
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Paramètre sauvegardé', 2000);
                    }
                }
            });
        }
        
        /**
         * Initialiser les sélecteurs de couleur
         */
        initColorPickers() {
            if ($.fn.wpColorPicker) {
                $('.cvp-color-picker').wpColorPicker({
                    change: (event, ui) => {
                        const $input = $(event.target);
                        $input.trigger('change');
                    }
                });
            }
        }
        
        /**
         * Initialiser le gestionnaire d'images
         */
        initImageManager() {
            this.initImageUpload();
            this.initImageGrid();
        }
        
        /**
         * Initialiser l'upload d'images
         */
        initImageUpload() {
            // Gestion du glisser-déposer
            const $dropzone = $('#cvp-admin-dropzone');
            
            if ($dropzone.length) {
                $dropzone.on('dragover', (e) => {
                    e.preventDefault();
                    $dropzone.addClass('dragover');
                });
                
                $dropzone.on('dragleave', (e) => {
                    e.preventDefault();
                    $dropzone.removeClass('dragover');
                });
                
                $dropzone.on('drop', (e) => {
                    e.preventDefault();
                    $dropzone.removeClass('dragover');
                    
                    const files = e.originalEvent.dataTransfer.files;
                    this.handleFileUpload(files);
                });
                
                $dropzone.on('click', () => {
                    $('#cvp-admin-file-input').click();
                });
            }
            
            // Gestion de l'input file
            $(document).on('change', '#cvp-admin-file-input', (e) => {
                const files = e.target.files;
                this.handleFileUpload(files);
            });
            
            // Bouton de démarrage d'upload
            $(document).on('click', '#cvp-start-upload', () => {
                this.startUpload();
            });
        }
        
        /**
         * Gérer l'upload de fichiers
         */
        handleFileUpload(files) {
            if (!files.length) return;
            
            this.uploadFiles = Array.from(files);
            this.displaySelectedFiles();
            $('#cvp-start-upload').prop('disabled', false);
        }
        
        /**
         * Afficher les fichiers sélectionnés
         */
        displaySelectedFiles() {
            const $container = $('#cvp-admin-dropzone').parent();
            let html = '<div class="cvp-file-list"><h4>Fichiers sélectionnés:</h4>';
            
            this.uploadFiles.forEach(file => {
                html += `<div class="cvp-file-item">${file.name} (${this.formatFileSize(file.size)})</div>`;
            });
            
            html += '</div>';
            
            $container.find('.cvp-file-list').remove();
            $container.append(html);
        }
        
        /**
         * Formater la taille de fichier
         */
        formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
        
        /**
         * Démarrer l'upload
         */
        startUpload() {
            if (!this.uploadFiles || !this.uploadFiles.length) return;
            
            const $progress = $('#cvp-upload-progress');
            const $progressBar = $('.cvp-progress-fill');
            const $progressText = $('.cvp-progress-text');
            
            $progress.show();
            
            let uploadedCount = 0;
            const totalFiles = this.uploadFiles.length;
            
            this.uploadFiles.forEach(file => {
                this.uploadSingleFile(file).then(() => {
                    uploadedCount++;
                    const progress = Math.round((uploadedCount / totalFiles) * 100);
                    $progressBar.css('width', progress + '%');
                    $progressText.text(progress + '%');
                    
                    if (uploadedCount === totalFiles) {
                        setTimeout(() => {
                            $progress.hide();
                            this.showNotification('success', 'Tous les fichiers ont été uploadés');
                            this.refreshImageGrid();
                            this.resetUploadForm();
                        }, 1000);
                    }
                }).catch(error => {
                    this.showNotification('error', `Erreur upload ${file.name}: ${error}`);
                });
            });
        }
        
        /**
         * Uploader un fichier unique
         */
        uploadSingleFile(file) {
            return new Promise((resolve, reject) => {
                const formData = new FormData();
                formData.append('action', 'cvp_admin_upload');
                formData.append('nonce', cvpAdmin.nonce);
                formData.append('file', file);
                formData.append('image_type', $('#image-type').val());
                formData.append('category', $('#image-category').val());
                
                $.ajax({
                    url: cvpAdmin.ajaxUrl,
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: (response) => {
                        if (response.success) {
                            resolve(response.data);
                        } else {
                            reject(response.data || 'Erreur inconnue');
                        }
                    },
                    error: () => {
                        reject('Erreur de connexion');
                    }
                });
            });
        }
        
        /**
         * Réinitialiser le formulaire d'upload
         */
        resetUploadForm() {
            $('#cvp-admin-file-input').val('');
            $('.cvp-file-list').remove();
            $('#cvp-start-upload').prop('disabled', true);
            this.uploadFiles = [];
        }
        
        /**
         * Initialiser la grille d'images
         */
        initImageGrid() {
            // Gestion de la suppression d'images
            $(document).on('click', '.cvp-delete-image', this.handleImageDelete.bind(this));
            
            // Gestion de l'édition d'images
            $(document).on('click', '.cvp-edit-image', this.handleImageEdit.bind(this));
        }
        
        /**
         * Gérer la suppression d'image
         */
        handleImageDelete(e) {
            e.preventDefault();
            
            if (!confirm(cvpAdmin.strings.confirmDelete)) {
                return;
            }
            
            const $btn = $(e.currentTarget);
            const imageId = $btn.data('image-id');
            
            const data = {
                action: 'cvp_admin_delete',
                nonce: cvpAdmin.nonce,
                image_id: imageId
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Image supprimée avec succès');
                        $btn.closest('.cvp-image-item').fadeOut(() => {
                            $btn.closest('.cvp-image-item').remove();
                        });
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors de la suppression');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Gérer l'édition d'image
         */
        handleImageEdit(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const imageId = $btn.data('image-id');
            
            // Ouvrir un modal d'édition
            this.openImageEditModal(imageId);
        }
        
        /**
         * Ouvrir le modal d'édition d'image
         */
        openImageEditModal(imageId) {
            // Récupérer les données de l'image
            const data = {
                action: 'cvp_get_image_data',
                nonce: cvpAdmin.nonce,
                image_id: imageId
            };
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: data,
                success: (response) => {
                    if (response.success) {
                        this.renderImageEditModal(response.data);
                    } else {
                        this.showNotification('error', 'Impossible de charger les données de l\'image');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Rendre le modal d'édition d'image
         */
        renderImageEditModal(imageData) {
            const modalHtml = `
                <div class="cvp-modal" id="cvp-image-edit-modal">
                    <div class="cvp-modal-content">
                        <div class="cvp-modal-header">
                            <h3>Éditer l'image</h3>
                            <button class="cvp-modal-close">
                                <svg fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"/>
                                </svg>
                            </button>
                        </div>
                        <div class="cvp-modal-body">
                            <form id="cvp-image-edit-form">
                                <input type="hidden" name="image_id" value="${imageData.id}">
                                
                                <div class="cvp-option-group">
                                    <label for="edit-alt-text">Texte alternatif</label>
                                    <input type="text" id="edit-alt-text" name="alt_text" value="${imageData.alt_text || ''}" class="cvp-input">
                                </div>
                                
                                <div class="cvp-option-group">
                                    <label for="edit-image-type">Type d'image</label>
                                    <select id="edit-image-type" name="image_type" class="cvp-select">
                                        <option value="background" ${imageData.image_type === 'background' ? 'selected' : ''}>Arrière-plan</option>
                                        <option value="overlay" ${imageData.image_type === 'overlay' ? 'selected' : ''}>Élément de superposition</option>
                                    </select>
                                </div>
                                
                                <div class="cvp-option-group">
                                    <label for="edit-category">Catégorie</label>
                                    <select id="edit-category" name="category" class="cvp-select">
                                        <option value="general" ${imageData.category === 'general' ? 'selected' : ''}>Général</option>
                                        <option value="nature" ${imageData.category === 'nature' ? 'selected' : ''}>Nature</option>
                                        <option value="business" ${imageData.category === 'business' ? 'selected' : ''}>Business</option>
                                        <option value="abstract" ${imageData.category === 'abstract' ? 'selected' : ''}>Abstrait</option>
                                        <option value="technology" ${imageData.category === 'technology' ? 'selected' : ''}>Technologie</option>
                                        <option value="people" ${imageData.category === 'people' ? 'selected' : ''}>Personnes</option>
                                    </select>
                                </div>
                                
                                <div class="cvp-modal-actions">
                                    <button type="submit" class="cvp-btn cvp-btn-primary">Sauvegarder</button>
                                    <button type="button" class="cvp-btn cvp-btn-secondary cvp-modal-close">Annuler</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHtml);
            
            // Gérer la soumission du formulaire
            $('#cvp-image-edit-form').on('submit', this.handleImageEditSubmit.bind(this));
        }
        
        /**
         * Gérer la soumission du formulaire d'édition
         */
        handleImageEditSubmit(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'cvp_update_image');
            formData.append('nonce', cvpAdmin.nonce);
            
            $.ajax({
                url: cvpAdmin.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: (response) => {
                    if (response.success) {
                        this.showNotification('success', 'Image mise à jour avec succès');
                        this.closeModal();
                        this.refreshImageGrid();
                    } else {
                        this.showNotification('error', response.data || 'Erreur lors de la mise à jour');
                    }
                },
                error: () => {
                    this.showNotification('error', 'Erreur de connexion');
                }
            });
        }
        
        /**
         * Rafraîchir la grille d'images
         */
        refreshImageGrid() {
            // Recharger la page pour simplifier
            location.reload();
        }
        
        /**
         * Initialiser le générateur de shortcode
         */
        initShortcodeGenerator() {
            // Gestion des changements dans le générateur
            $(document).on('change', '.cvp-shortcode-option', this.updateShortcodePreview.bind(this));
        }
        
        /**
         * Mettre à jour l'aperçu du shortcode
         */
        updateShortcodePreview() {
            const width = $('#shortcode-width').val() || '800';
            const height = $('#shortcode-height').val() || '600';
            const theme = $('#shortcode-theme').val() || 'default';
            const enableUpload = $('#shortcode-enable-upload').is(':checked') ? 'true' : 'false';
            
            const shortcode = `[compositeur-visuel-pro width="${width}" height="${height}" theme="${theme}" enable_upload="${enableUpload}"]`;
            
            $('#shortcode-preview code').text(shortcode);
        }
        
        /**
         * Gestion des modals
         */
        openModal(e) {
            e.preventDefault();
            
            const modalId = $(e.currentTarget).data('modal');
            const $modal = $('#' + modalId);
            
            if ($modal.length) {
                $modal.fadeIn(300);
                $('body').addClass('cvp-modal-open');
            }
        }
        
        /**
         * Fermer le modal
         */
        closeModal() {
            $('.cvp-modal').fadeOut(300, function() {
                $(this).remove();
            });
            $('body').removeClass('cvp-modal-open');
        }
        
        /**
         * Gérer le clic sur le backdrop du modal
         */
        handleModalBackdropClick(e) {
            if (e.target === e.currentTarget) {
                this.closeModal();
            }
        }
        
        /**
         * Initialiser les notifications
         */
        initNotifications() {
            // Supprimer automatiquement les notifications après 5 secondes
            $(document).on('click', '.cvp-notification', function() {
                $(this).fadeOut(300, function() {
                    $(this).remove();
                });
            });
        }
        
        /**
         * Afficher une notification
         */
        showNotification(type, message, duration = 5000) {
            const notificationHtml = `
                <div class="cvp-notification cvp-notification-${type}">
                    ${message}
                </div>
            `;
            
            const $notification = $(notificationHtml);
            $('body').append($notification);
            
            // Animation d'entrée
            $notification.css({
                opacity: 0,
                transform: 'translateX(100%)'
            }).animate({
                opacity: 1,
                transform: 'translateX(0)'
            }, 300);
            
            // Suppression automatique
            setTimeout(() => {
                $notification.fadeOut(300, function() {
                    $(this).remove();
                });
            }, duration);
        }
    }
    
    /**
     * Initialisation au chargement du DOM
     */
    $(document).ready(function() {
        new CVPAdmin();
    });
    
})(jQuery);

