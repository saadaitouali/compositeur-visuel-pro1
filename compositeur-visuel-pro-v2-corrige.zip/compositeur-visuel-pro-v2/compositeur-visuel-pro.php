<?php
/**
 * Plugin Name: Compositeur Visuel Pro
 * Plugin URI: https://aitouali.com/compositeur-visuel-pro
 * Description: Plugin WordPress professionnel pour créer des compositions visuelles modernes avec interface élégante et fonctionnalités avancées.
 * Version: 2.0.0
 * Author: AI Touali
 * Author URI: https://aitouali.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: compositeur-visuel-pro
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Empêcher l'accès direct
if (!defined('ABSPATH')) {
    exit;
}

// Définir les constantes du plugin
define('CVP_VERSION', '2.0.0');
define('CVP_PLUGIN_FILE', __FILE__);
define('CVP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CVP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CVP_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Classe principale du plugin Compositeur Visuel Pro
 */
class CompositeurVisuelPro {
    
    /**
     * Instance unique du plugin (Singleton)
     */
    private static $instance = null;
    
    /**
     * Options du plugin
     */
    private $options;
    
    /**
     * Obtenir l'instance unique du plugin
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructeur privé (Singleton)
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialiser les hooks WordPress
     */
    private function init_hooks() {
        // Hooks d'activation/désactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Hooks d'initialisation
        add_action('init', array($this, 'init'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        
        // Hooks admin
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'admin_init'));
        
        // Hooks frontend
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_shortcode('compositeur-visuel-pro', array($this, 'render_shortcode'));
        
        // Hooks AJAX
        add_action('wp_ajax_cvp_upload_image', array($this, 'handle_image_upload'));
        add_action('wp_ajax_nopriv_cvp_upload_image', array($this, 'handle_image_upload'));
        add_action('wp_ajax_cvp_delete_image', array($this, 'handle_image_delete'));
        add_action('wp_ajax_cvp_get_images', array($this, 'handle_get_images'));
        add_action('wp_ajax_cvp_save_composition', array($this, 'handle_save_composition'));
        
        // Hook pour ajouter les styles du thème
        add_action('wp_head', array($this, 'add_theme_integration_styles'));
    }
    
    /**
     * Charger les dépendances
     */
    private function load_dependencies() {
        require_once CVP_PLUGIN_DIR . 'includes/class-cvp-admin.php';
        require_once CVP_PLUGIN_DIR . 'includes/class-cvp-frontend.php';
        require_once CVP_PLUGIN_DIR . 'includes/class-cvp-image-manager.php';
        require_once CVP_PLUGIN_DIR . 'includes/class-cvp-database.php'; // Added this line
    }
    
    /**
     * Activation du plugin
     */
    public function activate() {
        // Créer les options par défaut
        $default_options = array(
            'canvas_width' => 800,
            'canvas_height' => 600,
            'max_upload_size' => 10,
            'allowed_formats' => array('jpeg', 'jpg', 'png', 'gif', 'webp'),
            'compression_quality' => 85,
            
            // Couleurs modernes
            'primary_color' => '#667eea',
            'secondary_color' => '#764ba2',
            'accent_color' => '#f093fb',
            'background_color' => '#ffffff',
            'text_color' => '#2d3748',
            'border_color' => '#e2e8f0',
            
            // Textes personnalisables
            'header_title' => 'Créez votre composition visuelle',
            'header_subtitle' => 'Glissez, ajustez et téléchargez votre création',
            'upload_text' => 'Glissez vos images ici ou cliquez pour parcourir',
            'download_text' => 'Télécharger votre création',
            
            // Fonctionnalités
            'enable_drag_drop' => true,
            'enable_opacity_control' => true,
            'enable_rotation' => true,
            'enable_resize' => true,
            'enable_filters' => true,
            'enable_animations' => true,
            
            // Thème WordPress
            'inherit_theme_colors' => true,
            'inherit_theme_fonts' => true,
            'inherit_theme_spacing' => true,
            
            // Images par défaut (vides au départ)
            'default_backgrounds' => array(),
            'default_overlays' => array(),
            
            // Paramètres avancés
            'auto_save' => true,
            'show_grid' => false,
            'snap_to_grid' => false,
            'grid_size' => 20
        );
        
        add_option('cvp_options', $default_options);
        
        // Créer le dossier d'uploads
        $upload_dir = wp_upload_dir();
        $cvp_dir = $upload_dir['basedir'] . '/compositeur-visuel-pro';
        
        if (!file_exists($cvp_dir)) {
            wp_mkdir_p($cvp_dir);
            wp_mkdir_p($cvp_dir . '/backgrounds');
            wp_mkdir_p($cvp_dir . '/overlays');
            wp_mkdir_p($cvp_dir . '/compositions');
        }
        
        // Créer la table pour les images si nécessaire
        $this->create_images_table();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Désactivation du plugin
     */
    public function deactivate() {
        // Nettoyer les tâches cron si nécessaire
        wp_clear_scheduled_hook('cvp_cleanup_temp_files');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Créer la table pour les images
     */
    private function create_images_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'cvp_images';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            filename varchar(255) NOT NULL,
            original_name varchar(255) NOT NULL,
            file_path varchar(500) NOT NULL,
            file_url varchar(500) NOT NULL,
            file_size int(11) NOT NULL,
            mime_type varchar(100) NOT NULL,
            image_type enum('background', 'overlay') NOT NULL,
            category varchar(100) DEFAULT 'general',
            alt_text varchar(255) DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY image_type (image_type),
            KEY category (category),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Initialisation du plugin
     */
    public function init() {
        $this->options = get_option('cvp_options', array());
        
        // Initialiser les classes
        CVP_Admin::get_instance();
        CVP_Frontend::get_instance();
        CVP_Image_Manager::get_instance();
        // CVP_Ajax_Handler::get_instance(); // Removed this line, as CVP_Frontend handles AJAX
    }
    
    /**
     * Charger les traductions
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'compositeur-visuel-pro',
            false,
            dirname(CVP_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Ajouter le menu d'administration
     */
    public function add_admin_menu() {
        // Menu principal
        add_menu_page(
            __('Compositeur Visuel Pro', 'compositeur-visuel-pro'),
            __('Compositeur Visuel', 'compositeur-visuel-pro'),
            'manage_options',
            'compositeur-visuel-pro',
            array($this, 'admin_page'),
            'dashicons-format-image',
            30
        );
        
        // Sous-menus
        add_submenu_page(
            'compositeur-visuel-pro',
            __('Tableau de bord', 'compositeur-visuel-pro'),
            __('Tableau de bord', 'compositeur-visuel-pro'),
            'manage_options',
            'compositeur-visuel-pro',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'compositeur-visuel-pro',
            __('Gestionnaire d\'images', 'compositeur-visuel-pro'),
            __('Images', 'compositeur-visuel-pro'),
            'manage_options',
            'cvp-images',
            array($this, 'images_page')
        );
        
        add_submenu_page(
            'compositeur-visuel-pro',
            __('Paramètres', 'compositeur-visuel-pro'),
            __('Paramètres', 'compositeur-visuel-pro'),
            'manage_options',
            'cvp-settings',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Initialisation admin
     */
    public function admin_init() {
        // Enregistrer les paramètres
        register_setting('cvp_settings', 'cvp_options', array($this, 'sanitize_options'));
    }
    
    /**
     * Charger les assets admin
     */
    public function enqueue_admin_assets($hook) {
        // Charger seulement sur les pages du plugin
        if (strpos($hook, 'compositeur-visuel') === false && strpos($hook, 'cvp-') === false) {
            return;
        }
        
        // CSS admin moderne
        wp_enqueue_style(
            'cvp-admin-style',
            CVP_PLUGIN_URL . 'assets/css/admin.css',
            array('wp-color-picker'),
            CVP_VERSION
        );
        
        // JavaScript admin
        wp_enqueue_script(
            'cvp-admin-script',
            CVP_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'wp-color-picker', 'jquery-ui-sortable', 'jquery-ui-draggable'),
            CVP_VERSION,
            true
        );
        
        // Localisation
        wp_localize_script('cvp-admin-script', 'cvpAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cvp_admin_nonce'),
            'strings' => array(
                'confirmDelete' => __('Êtes-vous sûr de vouloir supprimer cette image ?', 'compositeur-visuel-pro'),
                'uploadSuccess' => __('Image uploadée avec succès', 'compositeur-visuel-pro'),
                'uploadError' => __('Erreur lors de l\'upload', 'compositeur-visuel-pro'),
                'saving' => __('Sauvegarde...', 'compositeur-visuel-pro'),
                'saved' => __('Sauvegardé', 'compositeur-visuel-pro')
            )
        ));
        
        // Media uploader
        wp_enqueue_media();
    }
    
    /**
     * Charger les assets frontend
     */
    public function enqueue_frontend_assets() {
        // CSS frontend moderne avec héritage du thème
        wp_enqueue_style(
            'cvp-frontend-style',
            CVP_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            CVP_VERSION
        );
        
        // JavaScript frontend
        wp_enqueue_script(
            'cvp-frontend-script',
            CVP_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery', 'jquery-ui-draggable', 'jquery-ui-resizable'),
            CVP_VERSION,
            true
        );
        
        // html2canvas pour la génération d'images
        wp_enqueue_script(
            'html2canvas',
            'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
            array(),
            '1.4.1',
            true
        );
        
        // Localisation
        wp_localize_script('cvp-frontend-script', 'cvpFrontend', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cvp_frontend_nonce'),
            'options' => $this->options,
            'strings' => array(
                'uploadError' => __('Erreur lors de l\'upload', 'compositeur-visuel-pro'),
                'invalidFile' => __('Format de fichier non supporté', 'compositeur-visuel-pro'),
                'fileTooLarge' => __('Fichier trop volumineux', 'compositeur-visuel-pro'),
                'generating' => __('Génération en cours...', 'compositeur-visuel-pro'),
                'downloadReady' => __('Téléchargement prêt', 'compositeur-visuel-pro')
            )
        ));
    }
    
    /**
     * Ajouter les styles d'intégration du thème
     */
    public function add_theme_integration_styles() {
        if (!$this->options['inherit_theme_colors'] && !$this->options['inherit_theme_fonts']) {
            return;
        }
        
        echo '<style id="cvp-theme-integration">';
        
        if ($this->options['inherit_theme_colors']) {
            // Récupérer les couleurs du thème actuel
            $theme_colors = $this->get_theme_colors();
            
            echo '.cvp-container {';
            if (!empty($theme_colors['primary'])) {
                echo '--cvp-theme-primary: ' . esc_attr($theme_colors['primary']) . ';';
            }
            if (!empty($theme_colors['secondary'])) {
                echo '--cvp-theme-secondary: ' . esc_attr($theme_colors['secondary']) . ';';
            }
            if (!empty($theme_colors['text'])) {
                echo '--cvp-theme-text: ' . esc_attr($theme_colors['text']) . ';';
            }
            echo '}';
        }
        
        if ($this->options['inherit_theme_fonts']) {
            // Récupérer les polices du thème
            $theme_fonts = $this->get_theme_fonts();
            
            echo '.cvp-container {';
            if (!empty($theme_fonts['body'])) {
                echo 'font-family: ' . esc_attr($theme_fonts['body']) . ';';
            }
            echo '}';
            
            echo '.cvp-container h1, .cvp-container h2, .cvp-container h3 {';
            if (!empty($theme_fonts['heading'])) {
                echo 'font-family: ' . esc_attr($theme_fonts['heading']) . ';';
            }
            echo '}';
        }
        
        echo '</style>';
    }
    
    /**
     * Obtenir les couleurs du thème
     */
    private function get_theme_colors() {
        $colors = array();
        
        // Essayer de récupérer les couleurs du customizer
        $primary = get_theme_mod('primary_color');
        $secondary = get_theme_mod('secondary_color');
        $text = get_theme_mod('text_color');
        
        if ($primary) $colors['primary'] = $primary;
        if ($secondary) $colors['secondary'] = $secondary;
        if ($text) $colors['text'] = '#' . $text;
        
        return $colors;
    }
    
    /**
     * Obtenir les polices du thème
     */
    private function get_theme_fonts() {
        $fonts = array();
        
        // Essayer de récupérer les polices du thème
        $body_font = get_theme_mod('body_font_family');
        $heading_font = get_theme_mod('heading_font_family');
        
        if ($body_font) $fonts['body'] = $body_font;
        if ($heading_font) $fonts['heading'] = $heading_font;
        
        return $fonts;
    }
    
    /**
     * Rendu du shortcode
     */
    public function render_shortcode($atts) {
        $atts = shortcode_atts(array(
            'width' => $this->options['canvas_width'],
            'height' => $this->options['canvas_height'],
            'theme' => 'default',
            'show_controls' => 'true',
            'enable_upload' => 'true'
        ), $atts, 'compositeur-visuel-pro');
        
        return CVP_Frontend::get_instance()->render_composer($atts);
    }
    
    /**
     * Gérer l'upload d'images
     */
    public function handle_image_upload() {
        CVP_Frontend::get_instance()->handle_frontend_upload();
    }
    
    /**
     * Gérer la suppression d'images
     */
    public function handle_image_delete() {
        // CVP_Ajax_Handler::get_instance()->handle_image_delete(); // This was handled by CVP_Image_Manager
    }
    
    /**
     * Récupérer les images
     */
    public function handle_get_images() {
        CVP_Frontend::get_instance()->handle_get_images();
    }
    
    /**
     * Sauvegarder une composition
     */
    public function handle_save_composition() {
        CVP_Frontend::get_instance()->handle_save_composition();
    }
    
    /**
     * Page d'administration principale
     */
    public function admin_page() {
        CVP_Admin::get_instance()->render_dashboard();
    }
    
    /**
     * Page de gestion des images
     */
    public function images_page() {
        CVP_Admin::get_instance()->render_images_page();
    }
    
    /**
     * Page des paramètres
     */
    public function settings_page() {
        CVP_Admin::get_instance()->render_settings_page();
    }
    
    /**
     * Sanitiser les options
     */
    public function sanitize_options($options) {
        $sanitized = array();
        
        // Dimensions
        $sanitized['canvas_width'] = intval($options['canvas_width']);
        $sanitized['canvas_height'] = intval($options['canvas_height']);
        $sanitized['max_upload_size'] = intval($options['max_upload_size']);
        $sanitized['compression_quality'] = intval($options['compression_quality']);
        
        // Couleurs
        $sanitized['primary_color'] = sanitize_hex_color($options['primary_color']);
        $sanitized['secondary_color'] = sanitize_hex_color($options['secondary_color']);
        $sanitized['accent_color'] = sanitize_hex_color($options['accent_color']);
        $sanitized['background_color'] = sanitize_hex_color($options['background_color']);
        $sanitized['text_color'] = sanitize_hex_color($options['text_color']);
        $sanitized['border_color'] = sanitize_hex_color($options['border_color']);
        
        // Textes
        $sanitized['header_title'] = sanitize_text_field($options['header_title']);
        $sanitized['header_subtitle'] = sanitize_text_field($options['header_subtitle']);
        $sanitized['upload_text'] = sanitize_text_field($options['upload_text']);
        $sanitized['download_text'] = sanitize_text_field($options['download_text']);
        
        // Booléens
        $sanitized['enable_drag_drop'] = !empty($options['enable_drag_drop']);
        $sanitized['enable_opacity_control'] = !empty($options['enable_opacity_control']);
        $sanitized['enable_rotation'] = !empty($options['enable_rotation']);
        $sanitized['enable_resize'] = !empty($options['enable_resize']);
        $sanitized['enable_filters'] = !empty($options['enable_filters']);
        $sanitized['enable_animations'] = !empty($options['enable_animations']);
        $sanitized['inherit_theme_colors'] = !empty($options['inherit_theme_colors']);
        $sanitized['inherit_theme_fonts'] = !empty($options['inherit_theme_fonts']);
        $sanitized['inherit_theme_spacing'] = !empty($options['inherit_theme_spacing']);
        $sanitized['auto_save'] = !empty($options['auto_save']);
        $sanitized['show_grid'] = !empty($options['show_grid']);
        $sanitized['snap_to_grid'] = !empty($options['snap_to_grid']);
        
        // Tableaux
        $sanitized['allowed_formats'] = array_map('sanitize_text_field', (array) $options['allowed_formats']);
        $sanitized['default_backgrounds'] = array_map('intval', (array) $options['default_backgrounds']);
        $sanitized['default_overlays'] = array_map('intval', (array) $options['default_overlays']);
        
        // Autres
        $sanitized['grid_size'] = intval($options['grid_size']);
        
        return $sanitized;
    }
    
    /**
     * Obtenir les options du plugin
     */
    public function get_options() {
        return $this->options;
    }
    
    /**
     * Mettre à jour une option
     */
    public function update_option($key, $value) {
        $this->options[$key] = $value;
        update_option('cvp_options', $this->options);
    }
}

// Initialiser le plugin
function cvp_init() {
    return CompositeurVisuelPro::get_instance();
}

// Démarrer le plugin
cvp_init();

// Fonctions utilitaires globales
function cvp_get_option($key, $default = null) {
    $options = get_option('cvp_options', array());
    return isset($options[$key]) ? $options[$key] : $default;
}

function cvp_update_option($key, $value) {
    $options = get_option('cvp_options', array());
    $options[$key] = $value;
    update_option('cvp_options', $options);
}

function cvp_get_upload_dir() {
    $upload_dir = wp_upload_dir();
    return $upload_dir['basedir'] . '/compositeur-visuel-pro';
}

function cvp_get_upload_url() {
    $upload_dir = wp_upload_dir();
    return $upload_dir['baseurl'] . '/compositeur-visuel-pro';
}



