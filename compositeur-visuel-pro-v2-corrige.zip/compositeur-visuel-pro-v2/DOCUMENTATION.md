# Documentation Technique - Compositeur Visuel Pro v2.0

## Table des Matières

1. [Introduction](#introduction)
2. [Architecture du Plugin](#architecture-du-plugin)
3. [Installation et Configuration](#installation-et-configuration)
4. [Interface d'Administration](#interface-dadministration)
5. [Utilisation Frontend](#utilisation-frontend)
6. [API et Hooks](#api-et-hooks)
7. [Base de Données](#base-de-données)
8. [Sécurité](#sécurité)
9. [Performance et Optimisation](#performance-et-optimisation)
10. [Dépannage](#dépannage)
11. [Développement et Personnalisation](#développement-et-personnalisation)

## Introduction

Le Compositeur Visuel Pro est un plugin WordPress avancé qui permet aux utilisateurs de créer des compositions visuelles interactives directement depuis leur site web. Cette version 2.0 représente une refactorisation complète du plugin original, avec un accent particulier sur le design moderne, l'intégration avec les thèmes WordPress, et une expérience utilisateur optimisée.

### Nouveautés de la Version 2.0

La version 2.0 apporte des améliorations significatives par rapport à la version précédente :

**Design et Interface Utilisateur :**
- Interface d'administration complètement repensée avec un design moderne et élégant
- Frontend avec héritage automatique du thème WordPress actif
- Animations fluides et transitions CSS avancées
- Design responsive optimisé pour tous les appareils (desktop, tablette, mobile)
- Palette de couleurs harmonieuse avec support du mode sombre

**Fonctionnalités Techniques :**
- Aperçu en direct entièrement fonctionnel
- Système de glisser-déposer amélioré avec validation en temps réel
- Contrôles précis d'opacité, rotation, redimensionnement et positionnement
- Historique complet avec fonctions undo/redo
- Gestion avancée des images par défaut via l'interface d'administration

**Architecture et Performance :**
- Code JavaScript moderne utilisant les classes ES6
- Base de données personnalisée pour une gestion optimisée des ressources
- Système de cache intelligent pour les images
- Optimisation automatique des images uploadées
- Nettoyage automatique des fichiers temporaires

## Architecture du Plugin

### Structure des Fichiers

Le plugin suit une architecture modulaire bien organisée :

```
compositeur-visuel-pro/
├── compositeur-visuel-pro.php          # Fichier principal du plugin
├── readme.txt                          # Documentation WordPress
├── DOCUMENTATION.md                     # Documentation technique
├── assets/                             # Ressources statiques
│   ├── css/
│   │   ├── frontend.css                # Styles frontend
│   │   └── admin.css                   # Styles administration
│   ├── js/
│   │   ├── frontend.js                 # JavaScript frontend
│   │   └── admin.js                    # JavaScript administration
│   └── images/                         # Images par défaut
│       ├── backgrounds/                # Arrière-plans
│       └── overlays/                   # Éléments de superposition
├── includes/                           # Classes PHP
│   ├── class-cvp-admin.php            # Interface d'administration
│   ├── class-cvp-image-manager.php     # Gestionnaire d'images
│   ├── class-cvp-database.php         # Gestionnaire de base de données
│   └── frontend-template.php          # Template frontend
└── languages/                         # Fichiers de traduction
    └── compositeur-visuel-pro.pot      # Template de traduction
```

### Classes Principales

**CVP_Admin :** Gère l'interface d'administration, les pages de configuration, et les statistiques d'utilisation.

**CVP_Image_Manager :** Responsable de la gestion des images (upload, validation, optimisation, suppression) et de l'interaction avec la médiathèque WordPress.

**CVP_Database :** Gère la création, la mise à jour et l'optimisation des tables de base de données personnalisées.

### Flux de Données

Le plugin utilise un flux de données unidirectionnel pour assurer la cohérence :

1. **Administration :** L'administrateur ajoute des images via l'interface d'administration
2. **Stockage :** Les images sont validées, optimisées et stockées dans la base de données
3. **Frontend :** Le shortcode récupère les images disponibles et les affiche dans l'interface utilisateur
4. **Interaction :** L'utilisateur manipule les éléments via JavaScript
5. **Export :** La composition finale est générée et téléchargée

## Installation et Configuration

### Prérequis Système

- **WordPress :** Version 5.0 ou supérieure
- **PHP :** Version 7.4 ou supérieure (recommandé : 8.0+)
- **MySQL :** Version 5.6 ou supérieure (recommandé : 8.0+)
- **Extensions PHP requises :**
  - GD ou ImageMagick pour le traitement d'images
  - JSON pour la sérialisation des données
  - cURL pour les requêtes HTTP
- **Espace disque :** Minimum 50 MB pour l'installation, plus l'espace pour les images uploadées
- **Mémoire PHP :** Minimum 128 MB (recommandé : 256 MB ou plus)

### Installation Standard

1. **Téléchargement :** Téléchargez l'archive du plugin depuis votre source
2. **Upload :** Uploadez le dossier `compositeur-visuel-pro` dans `/wp-content/plugins/`
3. **Activation :** Activez le plugin depuis le menu 'Extensions' de WordPress
4. **Configuration :** Accédez à 'Compositeur Visuel Pro' dans le menu d'administration

### Installation via WP-CLI

Pour les utilisateurs avancés, l'installation peut être effectuée via WP-CLI :

```bash
# Télécharger et installer le plugin
wp plugin install compositeur-visuel-pro.zip

# Activer le plugin
wp plugin activate compositeur-visuel-pro

# Vérifier l'installation
wp plugin status compositeur-visuel-pro
```

### Configuration Initiale

Après l'activation, le plugin crée automatiquement :

- **Tables de base de données :** Quatre tables personnalisées pour gérer les images, compositions, catégories et statistiques
- **Dossiers d'upload :** Structure de dossiers sécurisée dans `/wp-content/uploads/compositeur-visuel-pro/`
- **Tâches cron :** Programmation automatique des tâches de maintenance
- **Options par défaut :** Configuration initiale avec des valeurs optimisées

### Vérification de l'Installation

Pour vérifier que l'installation s'est déroulée correctement :

1. Accédez au tableau de bord du plugin dans l'administration WordPress
2. Vérifiez que les statistiques s'affichent correctement
3. Testez l'upload d'une image via l'interface d'administration
4. Créez une page de test avec le shortcode `[compositeur-visuel-pro]`
5. Vérifiez que l'interface frontend se charge sans erreur

## Interface d'Administration

### Tableau de Bord Principal

Le tableau de bord offre une vue d'ensemble complète de l'utilisation du plugin :

**Statistiques en Temps Réel :**
- Nombre total d'images gérées
- Répartition entre arrière-plans et éléments de superposition
- Espace de stockage utilisé avec formatage automatique
- Graphiques de tendance d'utilisation

**Aperçu en Direct :**
Une iframe intégrée permet de visualiser le compositeur en action sans quitter l'interface d'administration. Cette fonctionnalité utilise une page de prévisualisation dédiée qui charge le shortcode avec les paramètres par défaut.

**Actions Rapides :**
- Vidage du cache des images
- Export/import des paramètres de configuration
- Accès direct aux paramètres avancés
- Liens vers la documentation et le support

### Gestionnaire d'Images

Le gestionnaire d'images constitue le cœur du système de gestion de contenu :

**Upload Multiple :**
- Interface de glisser-déposer moderne avec indicateur de progression
- Validation en temps réel des formats et tailles de fichiers
- Optimisation automatique des images (compression, redimensionnement)
- Catégorisation automatique ou manuelle

**Organisation et Filtrage :**
- Système de catégories personnalisables avec codes couleur
- Filtres par type (arrière-plan/superposition), catégorie, et date
- Recherche textuelle dans les noms et descriptions
- Tri par nom, date, taille ou popularité

**Édition en Lot :**
- Sélection multiple avec cases à cocher
- Suppression en masse avec confirmation
- Modification des catégories par lot
- Export de métadonnées au format CSV

### Paramètres Avancés

La page de paramètres permet une configuration fine du plugin :

**Paramètres Généraux :**
- Dimensions par défaut du canvas (largeur/hauteur)
- Qualité de compression des images (1-100)
- Taille maximale des fichiers uploadés
- Formats de fichiers autorisés

**Apparence et Intégration :**
- Mode d'héritage du thème (automatique/forcé/désactivé)
- Couleurs personnalisées pour l'interface
- Polices et tailles de texte
- Animations et transitions (activées/désactivées)

**Performance et Sécurité :**
- Cache des images (durée de vie, taille maximale)
- Restrictions d'accès par rôle utilisateur
- Validation avancée des fichiers uploadés
- Logs d'activité et audit trail

## Utilisation Frontend

### Shortcode Principal

Le shortcode `[compositeur-visuel-pro]` est l'élément central pour afficher le compositeur sur le frontend. Il accepte de nombreux paramètres pour personnaliser l'expérience :

**Paramètres de Base :**
```
[compositeur-visuel-pro width="800" height="600" theme="inherit"]
```

**Paramètres Avancés :**
```
[compositeur-visuel-pro 
    width="1200" 
    height="800" 
    theme="dark" 
    enable_upload="true" 
    enable_grid="false" 
    max_file_size="10" 
    allowed_types="jpeg,png,webp"
    container_class="custom-composer"
    canvas_class="custom-canvas"
]
```

### Interface Utilisateur

L'interface frontend est divisée en deux panneaux principaux :

**Panneau de Contrôles (Gauche) :**
- Zone d'upload par glisser-déposer
- Grille d'images d'arrière-plan disponibles
- Grille d'éléments de superposition
- Contrôles de propriétés (opacité, rotation, échelle, position)
- Boutons d'action (annuler, refaire, réinitialiser)

**Panneau de Prévisualisation (Droite) :**
- Canvas interactif avec aperçu en temps réel
- Poignées de redimensionnement sur les éléments sélectionnés
- Indicateurs visuels de position et d'alignement
- Bouton de téléchargement de la composition finale

### Interactions Utilisateur

**Manipulation des Éléments :**
- **Sélection :** Clic simple sur un élément pour le sélectionner
- **Déplacement :** Glisser-déposer pour repositionner
- **Redimensionnement :** Poignées aux coins pour ajuster la taille
- **Rotation :** Curseur dédié ou raccourcis clavier
- **Suppression :** Touche Suppr ou Backspace

**Raccourcis Clavier :**
- `Ctrl+Z` / `Cmd+Z` : Annuler la dernière action
- `Ctrl+Y` / `Cmd+Y` : Refaire l'action annulée
- `Ctrl+S` / `Cmd+S` : Sauvegarder la composition
- `Flèches` : Déplacement précis de l'élément sélectionné
- `Shift+Flèches` : Déplacement rapide (10 pixels)
- `Suppr` / `Backspace` : Supprimer l'élément sélectionné

### Responsive Design

L'interface s'adapte automatiquement aux différentes tailles d'écran :

**Desktop (>1024px) :**
- Layout en deux colonnes avec panneau de contrôles fixe
- Canvas à taille réelle avec zoom possible
- Tous les contrôles visibles simultanément

**Tablette (768px-1024px) :**
- Layout en une colonne avec panneau de contrôles repliable
- Canvas adaptatif maintenant les proportions
- Navigation par onglets pour les différentes sections

**Mobile (<768px) :**
- Interface simplifiée avec navigation par étapes
- Canvas pleine largeur avec contrôles en overlay
- Gestes tactiles optimisés pour la manipulation

## API et Hooks

### Hooks d'Action

Le plugin fournit plusieurs hooks d'action pour permettre aux développeurs d'étendre ses fonctionnalités :

**cvp_image_uploaded :**
```php
do_action('cvp_image_uploaded', $image_id, $image_data, $user_id);
```
Déclenché après l'upload réussi d'une image. Permet d'ajouter des traitements personnalisés.

**cvp_composition_saved :**
```php
do_action('cvp_composition_saved', $composition_id, $composition_data, $user_id);
```
Déclenché lors de la sauvegarde d'une composition. Utile pour les notifications ou l'intégration avec d'autres plugins.

**cvp_image_deleted :**
```php
do_action('cvp_image_deleted', $image_id, $image_data);
```
Déclenché avant la suppression d'une image. Permet de nettoyer les données associées.

### Hooks de Filtre

**cvp_allowed_file_types :**
```php
$allowed_types = apply_filters('cvp_allowed_file_types', array('jpeg', 'jpg', 'png', 'gif', 'webp'));
```
Permet de modifier la liste des types de fichiers autorisés.

**cvp_max_file_size :**
```php
$max_size = apply_filters('cvp_max_file_size', 10 * 1024 * 1024); // 10MB par défaut
```
Permet de personnaliser la taille maximale des fichiers uploadés.

**cvp_canvas_options :**
```php
$options = apply_filters('cvp_canvas_options', $default_options, $shortcode_atts);
```
Permet de modifier les options du canvas avant l'affichage.

### API REST

Le plugin expose une API REST pour l'intégration avec des applications externes :

**Endpoints Disponibles :**

`GET /wp-json/cvp/v1/images` - Récupérer la liste des images
`POST /wp-json/cvp/v1/images` - Uploader une nouvelle image
`DELETE /wp-json/cvp/v1/images/{id}` - Supprimer une image
`GET /wp-json/cvp/v1/compositions` - Récupérer les compositions sauvegardées
`POST /wp-json/cvp/v1/compositions` - Sauvegarder une nouvelle composition

**Authentification :**
L'API utilise le système d'authentification WordPress standard avec support des nonces pour les requêtes AJAX et des tokens JWT pour les applications externes.

### Fonctions Utilitaires

**cvp_get_images($type = 'all', $category = 'all') :**
Récupère les images disponibles avec filtrage optionnel par type et catégorie.

**cvp_optimize_image($file_path, $quality = 85) :**
Optimise une image en ajustant sa qualité et ses dimensions.

**cvp_generate_thumbnail($image_path, $width, $height) :**
Génère une miniature d'une image aux dimensions spécifiées.

## Base de Données

### Structure des Tables

Le plugin utilise quatre tables personnalisées pour gérer ses données :

**wp_cvp_images :**
Table principale pour stocker les métadonnées des images.

```sql
CREATE TABLE wp_cvp_images (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    filename varchar(255) NOT NULL,
    original_name varchar(255) NOT NULL,
    file_path text NOT NULL,
    file_url text NOT NULL,
    file_size bigint(20) unsigned NOT NULL DEFAULT 0,
    mime_type varchar(100) NOT NULL,
    image_type enum('background', 'overlay') NOT NULL DEFAULT 'overlay',
    category varchar(100) NOT NULL DEFAULT 'general',
    alt_text text,
    description text,
    tags text,
    is_active tinyint(1) NOT NULL DEFAULT 1,
    sort_order int(11) NOT NULL DEFAULT 0,
    created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_image_type (image_type),
    KEY idx_category (category),
    KEY idx_is_active (is_active)
);
```

**wp_cvp_compositions :**
Stocke les compositions sauvegardées par les utilisateurs.

```sql
CREATE TABLE wp_cvp_compositions (
    id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
    user_id bigint(20) unsigned NOT NULL DEFAULT 0,
    title varchar(255) NOT NULL,
    description text,
    composition_data longtext NOT NULL,
    canvas_width int(11) NOT NULL DEFAULT 800,
    canvas_height int(11) NOT NULL DEFAULT 600,
    preview_url text,
    is_public tinyint(1) NOT NULL DEFAULT 0,
    view_count bigint(20) unsigned NOT NULL DEFAULT 0,
    created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user_id (user_id),
    KEY idx_is_public (is_public)
);
```

**wp_cvp_categories :**
Gère les catégories personnalisées pour l'organisation des images.

**wp_cvp_usage_stats :**
Collecte les statistiques d'utilisation pour l'analyse et l'optimisation.

### Migrations et Mises à Jour

Le système de migration automatique gère les mises à jour de la structure de base de données :

```php
class CVP_Database {
    const DB_VERSION = '1.0.0';
    
    public function check_database_version() {
        $installed_version = get_option('cvp_db_version', '0.0.0');
        
        if (version_compare($installed_version, self::DB_VERSION, '<')) {
            $this->upgrade_database($installed_version);
        }
    }
}
```

### Optimisation et Maintenance

**Nettoyage Automatique :**
- Suppression des fichiers temporaires (quotidien)
- Nettoyage des fichiers orphelins (hebdomadaire)
- Optimisation des tables (mensuel)
- Archivage des anciennes statistiques (trimestriel)

**Indexation :**
Les tables utilisent des index optimisés pour les requêtes fréquentes :
- Index composites pour les filtres multiples
- Index de texte intégral pour la recherche
- Index de date pour les tris chronologiques

## Sécurité

### Validation des Fichiers

Le plugin implémente plusieurs couches de validation pour les fichiers uploadés :

**Validation du Type MIME :**
```php
private function validate_image_file($file) {
    $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp');
    
    if (!in_array($file['type'], $allowed_types)) {
        return new WP_Error('invalid_type', __('Type de fichier non autorisé'));
    }
    
    // Vérification supplémentaire avec getimagesize()
    $image_info = getimagesize($file['tmp_name']);
    if (!$image_info) {
        return new WP_Error('invalid_image', __('Le fichier n\'est pas une image valide'));
    }
    
    return true;
}
```

**Validation de la Taille :**
- Vérification de la taille du fichier (configurable, 10MB par défaut)
- Vérification des dimensions minimales (100x100 pixels)
- Limitation de la résolution maximale pour éviter les attaques par déni de service

**Sanitisation des Noms de Fichiers :**
```php
private function generate_unique_filename($basename, $extension, $image_type) {
    $basename = sanitize_file_name($basename);
    $extension = strtolower($extension);
    
    // Ajouter un préfixe et un timestamp pour l'unicité
    $prefix = $image_type === 'background' ? 'bg_' : 'el_';
    $timestamp = time();
    
    return $prefix . $basename . '_' . $timestamp . '.' . $extension;
}
```

### Protection des Dossiers

Les dossiers d'upload sont protégés par des fichiers `.htaccess` :

```apache
Options -Indexes
<Files *.php>
deny from all
</Files>
```

### Nonces et Authentification

Toutes les requêtes AJAX utilisent des nonces WordPress pour prévenir les attaques CSRF :

```php
// Génération du nonce
wp_localize_script('cvp-frontend', 'cvpFrontend', array(
    'ajaxUrl' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('cvp_frontend_nonce')
));

// Vérification du nonce
if (!wp_verify_nonce($_POST['nonce'], 'cvp_frontend_nonce')) {
    wp_die(__('Permissions insuffisantes'));
}
```

### Contrôle d'Accès

Le plugin respecte les capacités WordPress pour contrôler l'accès aux fonctionnalités :

```php
// Vérification des permissions pour l'administration
if (!current_user_can('manage_options')) {
    wp_die(__('Permissions insuffisantes'));
}

// Vérification des permissions pour l'upload
if (!current_user_can('upload_files')) {
    return new WP_Error('insufficient_permissions', __('Vous n\'avez pas les permissions pour uploader des fichiers'));
}
```

## Performance et Optimisation

### Optimisation des Images

Le plugin optimise automatiquement les images uploadées :

**Compression Intelligente :**
```php
private function optimize_image($file_path, $mime_type) {
    $options = get_option('cvp_options', array());
    $quality = $options['compression_quality'] ?? 85;
    
    switch ($mime_type) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($file_path);
            if ($image) {
                imagejpeg($image, $file_path, $quality);
                imagedestroy($image);
            }
            break;
            
        case 'image/png':
            $image = imagecreatefrompng($file_path);
            if ($image) {
                $png_quality = 9 - round(($quality / 100) * 9);
                imagepng($image, $file_path, $png_quality);
                imagedestroy($image);
            }
            break;
    }
}
```

**Génération de Miniatures :**
Le plugin génère automatiquement des miniatures pour améliorer les performances de l'interface d'administration.

### Cache et Performance

**Cache des Requêtes :**
Les requêtes de base de données fréquentes sont mises en cache :

```php
public function get_images($type = 'all') {
    $cache_key = 'cvp_images_' . $type;
    $images = wp_cache_get($cache_key);
    
    if (false === $images) {
        // Requête base de données
        $images = $this->fetch_images_from_db($type);
        wp_cache_set($cache_key, $images, '', 3600); // Cache 1 heure
    }
    
    return $images;
}
```

**Lazy Loading :**
L'interface frontend utilise le lazy loading pour les images :

```html
<img src="<?php echo esc_url($image->file_url); ?>" 
     alt="<?php echo esc_attr($image->alt_text); ?>" 
     loading="lazy">
```

**Minification et Compression :**
Les fichiers CSS et JavaScript sont automatiquement minifiés en production.

### Optimisation de la Base de Données

**Requêtes Optimisées :**
Utilisation d'index appropriés et de requêtes préparées :

```php
$sql = $wpdb->prepare(
    "SELECT * FROM {$this->table_name} 
     WHERE image_type = %s AND is_active = 1 
     ORDER BY sort_order ASC, created_at DESC 
     LIMIT %d OFFSET %d",
    $image_type, $per_page, $offset
);
```

**Nettoyage Automatique :**
Tâches cron pour maintenir les performances :

```php
// Nettoyage quotidien des fichiers temporaires
wp_schedule_event(time(), 'daily', 'cvp_cleanup_temp_files');

// Optimisation hebdomadaire des tables
wp_schedule_event(time(), 'weekly', 'cvp_optimize_database');
```

## Dépannage

### Problèmes Courants

**L'aperçu ne fonctionne pas :**
1. Vérifiez que JavaScript est activé dans le navigateur
2. Contrôlez la console du navigateur pour les erreurs JavaScript
3. Assurez-vous que la bibliothèque html2canvas est chargée
4. Vérifiez les permissions de fichiers dans le dossier d'upload

**Les images ne s'uploadent pas :**
1. Vérifiez les permissions du dossier `/wp-content/uploads/`
2. Contrôlez la taille maximale d'upload dans PHP (`upload_max_filesize`)
3. Vérifiez la limite de mémoire PHP (`memory_limit`)
4. Assurez-vous que l'extension GD ou ImageMagick est installée

**L'interface ne s'affiche pas correctement :**
1. Vérifiez les conflits CSS avec le thème actif
2. Désactivez temporairement les autres plugins pour identifier les conflits
3. Contrôlez que les fichiers CSS et JavaScript se chargent correctement
4. Vérifiez la compatibilité avec la version de WordPress

### Logs et Débogage

**Activation des Logs :**
```php
// Dans wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('CVP_DEBUG', true);
```

**Logs Personnalisés :**
Le plugin écrit des logs détaillés pour faciliter le débogage :

```php
if (defined('CVP_DEBUG') && CVP_DEBUG) {
    error_log('CVP: Upload d\'image - ' . $filename . ' - Taille: ' . $file_size);
}
```

### Outils de Diagnostic

**Page de Diagnostic :**
Le plugin inclut une page de diagnostic accessible depuis l'administration :

- Vérification de la configuration PHP
- Test des permissions de fichiers
- Validation de la structure de base de données
- Contrôle de l'intégrité des fichiers

**Commandes WP-CLI :**
```bash
# Vérifier l'état du plugin
wp cvp status

# Nettoyer les fichiers orphelins
wp cvp cleanup

# Réparer la base de données
wp cvp repair-db

# Exporter les paramètres
wp cvp export-settings
```

## Développement et Personnalisation

### Hooks pour Développeurs

Le plugin offre de nombreux points d'extension pour les développeurs :

**Personnalisation de l'Interface :**
```php
// Ajouter des contrôles personnalisés
add_action('cvp_after_controls', function() {
    echo '<div class="custom-control">Mon contrôle personnalisé</div>';
});

// Modifier les options du canvas
add_filter('cvp_canvas_options', function($options) {
    $options['customOption'] = 'valeur';
    return $options;
});
```

**Intégration avec d'Autres Plugins :**
```php
// Intégration avec WooCommerce
add_action('cvp_composition_saved', function($composition_id, $data, $user_id) {
    if (class_exists('WooCommerce')) {
        // Créer un produit WooCommerce avec la composition
        $product = new WC_Product_Simple();
        $product->set_name('Composition ' . $composition_id);
        $product->save();
    }
});
```

### Création de Thèmes Personnalisés

**Structure d'un Thème :**
```css
/* Thème personnalisé */
.cvp-theme-custom {
    --cvp-primary: #your-color;
    --cvp-secondary: #your-secondary;
    /* Autres variables CSS */
}

.cvp-theme-custom .cvp-controls-panel {
    background: linear-gradient(135deg, #color1, #color2);
}
```

**Enregistrement du Thème :**
```php
add_filter('cvp_available_themes', function($themes) {
    $themes['custom'] = array(
        'name' => 'Mon Thème Personnalisé',
        'css_class' => 'cvp-theme-custom',
        'preview' => 'path/to/preview.png'
    );
    return $themes;
});
```

### API pour Extensions

**Création d'une Extension :**
```php
class CVP_My_Extension {
    public function __construct() {
        add_action('cvp_init', array($this, 'init'));
    }
    
    public function init() {
        // Initialisation de l'extension
        add_filter('cvp_toolbar_buttons', array($this, 'add_toolbar_button'));
    }
    
    public function add_toolbar_button($buttons) {
        $buttons['my_button'] = array(
            'label' => 'Mon Bouton',
            'icon' => 'dashicons-star-filled',
            'callback' => 'myCustomFunction'
        );
        return $buttons;
    }
}

new CVP_My_Extension();
```

### Tests et Qualité

**Tests Unitaires :**
Le plugin inclut une suite de tests PHPUnit :

```bash
# Installer les dépendances de test
composer install --dev

# Exécuter les tests
vendor/bin/phpunit
```

**Standards de Code :**
Le code respecte les standards WordPress Coding Standards :

```bash
# Vérifier le code
vendor/bin/phpcs --standard=WordPress

# Corriger automatiquement
vendor/bin/phpcbf --standard=WordPress
```

Cette documentation technique fournit une base solide pour comprendre, utiliser et étendre le Compositeur Visuel Pro. Pour des questions spécifiques ou des besoins de personnalisation avancée, n'hésitez pas à consulter le code source ou à contacter l'équipe de support.

