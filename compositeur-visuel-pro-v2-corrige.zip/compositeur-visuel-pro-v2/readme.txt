=== Compositeur Visuel Pro ===
Contributors: Your Name
Tags: visual composer, image editor, watermark, drag and drop, responsive
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Créez des compositions visuelles professionnelles avec une interface moderne, élégante et responsive. Ce plugin offre des fonctionnalités avancées de glisser-déposer, de support multi-formats, de contrôle d'opacité, de positionnement précis et une interface d'administration complète pour la personnalisation.

== Description ==

Le Compositeur Visuel Pro est un plugin WordPress puissant qui vous permet de créer des compositions d'images personnalisées directement depuis votre site. Avec une interface intuitive et des fonctionnalités avancées, vous pouvez superposer des images, ajouter des filigranes, ajuster l'opacité, la rotation et la taille, et bien plus encore.

**Fonctionnalités Clés :**

*   **Design Moderne et Élégant :** Une interface utilisateur et une administration repensées pour une expérience utilisateur optimale.
*   **Héritage du Thème WordPress :** Le plugin s'intègre parfaitement à votre thème WordPress existant.
*   **Gestion des Images par Défaut :** Ajoutez et gérez des images d'arrière-plan et de superposition par défaut depuis l'interface d'administration.
*   **Aperçu en Direct :** Visualisez vos modifications en temps réel avant de les sauvegarder.
*   **Glisser-Déposer :** Déplacez et redimensionnez les éléments avec une grande facilité.
*   **Contrôles Avancés :** Ajustez l'opacité, la rotation, la taille et la position de chaque élément.
*   **Support Multi-Formats :** Uploadez des images aux formats JPEG, PNG, GIF et WebP.
*   **Responsive :** L'interface est entièrement responsive et s'adapte à tous les appareils.
*   **Shortcode Flexible :** Utilisez le shortcode `[compositeur-visuel-pro]` pour afficher le compositeur n'importe où sur votre site.

== Installation ==

1.  Uploadez le dossier `compositeur-visuel-pro` dans le répertoire `/wp-content/plugins/`.
2.  Activez le plugin depuis le menu 'Extensions' de WordPress.
3.  Accédez à la page 'Compositeur Visuel Pro' dans le menu d'administration pour configurer le plugin.
4.  Utilisez le shortcode `[compositeur-visuel-pro]` dans vos pages ou articles pour afficher le compositeur.

== Changelog ==

= 2.0.0 =
*   Refactorisation complète du plugin avec un design moderne et élégant.
*   Ajout de l'héritage du thème WordPress.
*   Implémentation de la gestion des images par défaut via l'interface d'administration.
*   Correction de l'aperçu en direct sur le frontend.
*   Amélioration de l'interface d'administration avec des statistiques et des actions rapides.
*   Optimisation du code JavaScript avec des classes ES6.
*   Ajout d'une base de données personnalisée pour la gestion des images et des compositions.

= 1.0.0 =
*   Version initiale du plugin.



